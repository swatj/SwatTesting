use POC;

Go

Create PROCEDURE CreateUsers(@lastname nvarchar(50), @firstname nvarchar(50), @abbreviation nvarchar(80), @username nvarchar(1500)
, @accountlock nvarchar(20), @securityprofilefrid nvarchar(20), @jobrolefrid nvarchar(20))
AS

DECLARE @userfrid nvarchar(20) , @userssid nvarchar(20)
,  @userpersonid nvarchar(20), @usermapid nvarchar(20), @usermapname nvarchar(20), @userrolefrid nvarchar(20), @userfieldfrid nvarchar(20)
,  @linkvalue nvarchar(20)
BEGIN 
			IF NOT EXISTS ( SELECT 1 FROM StaffMember WHERE lastname = @lastname AND firstname = @firstname)

		BEGIN				
					PRINT 'Creating user '+ @lastname + ',' + @firstname + '.'

					SET @userfrid = LEFT(NEWID(), 18)
					SET @userfrid =  REPLACE(@userfrid,'-','')
					SET @userfrid = CONCAT('A',@userfrid)
					

					SET @userssid = LEFT(NEWID(), 18)
					SET @userssid =  REPLACE(@userssid,'-','')
					SET @userssid = CONCAT('A',@userssid)
					

					SET @userpersonid = LEFT(NEWID(), 18)
					SET @userpersonid =  REPLACE(@userpersonid,'-','')
					SET @userpersonid = CONCAT('A',@userpersonid)
					

					SET @usermapid = LEFT(NEWID(), 18)
					SET @usermapid =  REPLACE(@usermapid,'-','')
					SET @usermapid = CONCAT('A',@usermapid)
					

					SET @usermapname = LEFT(NEWID(), 18)
					SET @usermapname =  REPLACE(@usermapname,'-','')
					SET @usermapname = CONCAT('A',@usermapname)
					

					Insert into StaffMember values (@userfrid,@userfrid,'0','0',GETDATE(),@lastname,
					@firstname,NULL,NULL,@abbreviation,@userssid,@userpersonid,@usermapid,@usermapname)

					--select * from JobRole
					insert into StaffJobRoles values (@userfrid,'0', @jobrolefrid) 

					-- 1G0000000002UW5IUB = Folder id for present users
					insert into Document values (@userfrid,@userfrid,'1G0000000002UW5IUB',GETDATE(),'0','0','120004','0',NULL)

					Insert into SYS_DocumentsOfFolder values ('2K00000000000A42OU',@userfrid,'0')
					SET @userrolefrid = LEFT(NEWID(), 18)
					SET @userrolefrid =  REPLACE(@userrolefrid,'-','')
					SET @userrolefrid = CONCAT('A',@userrolefrid)
					


					insert into Document values (@userrolefrid,@userrolefrid,'5000',GETDATE(),'0','0','11','0',NULL);
					insert into SYS_DocumentsOfFolder values ('USER',@userrolefrid,'0');

					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
					

					-- Account Lock
					insert into Field values (@userfieldfrid,@userrolefrid,NULL,'/LCK/',NULL,'5',@accountlock,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
					

					-- Password Change Required
					insert into Field values (@userfieldfrid,@userrolefrid,NULL,'/CNL/',NULL,'5','F',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
					
					insert into Field values (@userfieldfrid,@userrolefrid,NULL,'/STMB/',NULL,'100',NULL,NULL,NULL,NULL,NULL,'2',NULL,@userfrid,NULL)

					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
					

					-- Security Profile 
					-- select * from field where FirstRevID in (select FirstRevID from SYS_DocumentsOfFolder where FolderID = 'USERROLE') and ElementKey = '/A00G/'					
					if(@securityprofilefrid IS NOT NULL)
						BEGIN
						insert into Field values (@userfieldfrid,@userrolefrid,NULL,'/ROLS/1/ROLE/',NULL,'100',NULL,NULL,NULL,NULL,NULL,'4','1',@securityprofilefrid,NULL)
						END
					-- Password
					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
				
					insert into Field values (@userfieldfrid, @userrolefrid,NULL,'/PSWD/',NULL,'0','OHyZtdfyIRyF4fkwXv/6qA==',NULL, NULL, NULL, NULL, '2', NULL, NULL, NULL)

					-- User Name
					SET @userfieldfrid = LEFT(NEWID(), 18)
					SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
					SET @userfieldfrid = CONCAT('A',@userfieldfrid)
					

					insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/LNAM/', NULL,'0',@username,NULL, NULL, NULL, NULL, '2', NULL, NULL, NULL)

					PRINT 'Created user '+ @lastname + ',' + @firstname + ' with username = '+ @username+ ' , account locked = ' 
					
					+ @accountlock + ' , security profile frid = '+ @securityprofilefrid + ' and job role frid = '+ @jobrolefrid  +' successfully.'
		END
		ELSE

		BEGIN
			PRINT 'User '+ @lastname + ',' + @firstname + ' already exists.'
		END


END

Go



Exec CreateUsers 'site','user','Dr one','siteuser','F','1L00000000009D00CB','1LB04CS';

Go
Exec CreateUsers 'userwithlongsitename','userwithlongsitename','Dr two','userwithlongsitename','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'column','user','Dr three','columnuser','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'showhidecolumn','user','Dr four','showhidecolumnuser','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'Protected','Department','Dr five','department','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'localization','localization','Dr six','localization','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'configuration','system','Dr seven','configuration','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'filteruser','filteruser','Dr eight','filteruser','F','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'lockedUser','lockedUser','Dr nine','lockedUser','T','1L00000000009D00CB','1LB04CS';

Go

Exec CreateUsers 'notauthorized','notauthorized','Dr ten','notauthorized','F', NULL,'1LB04CS';

Go

Exec CreateUsers 'Nosite','user','Dr eleven','Nositeuser','F', 'Nositeuserrolefrid','1LB04CS';

Go
Exec CreateUsers 'lastview','lastview','Dr eight','lastview','F','1L00000000009D00CB','1LB04CS';
Go
Exec CreateUsers 'sidepanel','sidepanel','Dr eight','sidepanel','F','1L00000000009D00CB','1LB04CS';
Go
Exec CreateUsers 'unitview','unitview','Dr eight','unitview','F','1L00000000009D00CB','1LB04CS';
Go
Exec CreateUsers 'arrivinglistfilter','arrivinglistfilter','Dr eight','arrivinglistfilter','F','1L00000000009D00CB','1LB04CS';
Go
Exec CreateUsers 'Park','Pick','Dr Pick','Pick','F','1L00000000009D00CB','1LB04CU';
Go
Exec CreateUsers 'Nurse','Zicks','Nurse Zicks','Zicks','F','1L00000000009D00CB','100000000001WX0V93';
Go
Exec CreateUsers 'Nurse','Zick','Nurse Zick','Zick','F','1L00000000009D00CB','53000000000031080F';
Go
DROP PROCEDURE CreateUsers;

Go

