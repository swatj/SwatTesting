USE POC;

GO

CREATE PROCEDURE createRoom(
@deptType NVARCHAR(50), @id NVARCHAR(15), @abbreviation NVARCHAR(80), @name NVARCHAR(35), @mapcode NVARCHAR(50), @mapname NVARCHAR(50), @description NVARCHAR(500)
)

AS 

DECLARE 
	@newFrid					NVARCHAR(20),	
	@creationTime				DATETIME2 (7),
	@departmentTypeFrid			NVARCHAR(50),
	@departmentFolderId			NVARCHAR(50),
	@loginDepartmentFolderId	NVARCHAR(50)


BEGIN
    /* FRID to be used */
	SET @newFrid = LEFT(NEWID(), 18)
	SET @newFrid = REPLACE(@newFrid,'-','')
	SET @newFrid = CONCAT('A',@newFrid)
	
	/* Set the creation time */
	SET @creationTime = CURRENT_TIMESTAMP	
	
	/* Based on the type of department to be created, fetch the department type frid */
	SELECT @departmentTypeFrid = firstrevid from DepartmentType where name = LTRIM(RTRIM(@deptType))
	
	/* Based on the type of department to be created, fetch the department folder id to create the entry under the correct folder in AE */
	SELECT @departmentFolderId = FolderID FROM SYS_Folder WHERE Name = 
						CASE 
							WHEN (LOWER(LTRIM(RTRIM(@deptType))) = 'Preop') THEN 'Preoperative departments'
							WHEN (LOWER(LTRIM(RTRIM(@deptType))) = 'anesthesia') THEN 'Operative departments'
							WHEN (LOWER(LTRIM(RTRIM(@deptType))) = 'Postop') THEN 'Postoperative departments'
							WHEN (LOWER(LTRIM(RTRIM(@deptType))) = 'ICU') THEN 'CARE units'
							WHEN (LOWER(LTRIM(RTRIM(@deptType))) = 'Login') THEN 'Login departments'
						END
	
	/* Fetch the department folder id of the Login department folder for creating shortcuts */	
	SELECT @loginDepartmentFolderId = FolderID FROM SYS_Folder WHERE Name = 'Login departments'

	/* Create the department entry */
	INSERT INTO Department 
	(
		CreationTime, DocumentID, RevisionID, 
		FirstRevID, SessionID, description, 
		mapcode, mapname, abbreviation, 
		name, departmenttypefrid, id
	) 
	VALUES 
	(
		@creationTime, @newFrid, 0,
		@newFrid, '0', @description,
		@mapcode, @mapname, @abbreviation,
		@name, @departmentTypeFrid, @id
	)
	
	/* Insert the corresponding document */
	INSERT INTO Document 
	(
		RevisionID, DocumentID, SessionID, 
		TemplateDocumentID, TemplateID, Status, 
		CreationTime, FirstRevID
	) 
	VALUES 
	(
		0, @newFrid, '0', 
		'1G0000000002QD055M', '1200B5', 0, 
		@creationTime, @newFrid
	) 
	
	/* Create entry under the correct department type folder */
	INSERT INTO SYS_DocumentsOfFolder
	(
		FolderID, FirstRevID, RelationType
	) 
	VALUES 
	(
		@departmentFolderId,@newFrid,0
	) 

	/* Create a shortcut under login department */
	INSERT INTO SYS_DocumentsOfFolder
	(
		FolderID, FirstRevID, RelationType
	) 
	VALUES 
	(
		@loginDepartmentFolderId,@newFrid,1
	)
END

GO

EXEC createDepartment 'anesthesia', 'intra1' , 'intra1' , 'intra1' , 'intra1' , 'intra1' , 'intra1' ;

GO

DROP PROCEDURE createDepartment;

GO

