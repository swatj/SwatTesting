update [Common].[dbo].[SYS_Property] set Value='en_US' where PropKey=13
use POC
go
disable trigger all on caseplan
go
disable trigger all on CancelDetails
go

DECLARE @Today DATE
  SET @Today =  getdate()
  PRINT @Today

  DECLARE @Past DATE
  SET @Past = DateAdd(dd, -4, getdate())
  PRINT @Past
   DECLARE @Future DATE
  SET @Future = DateAdd(dd, 4, getdate())
  PRINT @Future
     DECLARE @Tomorrow  DATE
  SET @Tomorrow  = DateAdd(dd, 1, getdate())
  PRINT @Tomorrow 
     DECLARE @Yesterday DATE
  SET @Yesterday = DateAdd(dd, -1, getdate())
  PRINT @Yesterday

 
update cp set cp.plannedproceduretime = @Today from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in('filter1','filter2','filter3','localization','completed','Configuration','DroppedCase','duplicate','PatientID00000101','PatientID00000102','PatientID00000103','PatientID00000104','PatientID00000501','PatientID00000502','popover1','sowha1','sowha2','sowha3','sowha4','sowha5','sowha6','sowha7','PACUPatientID0012','PACUPatientID0013','PACUPatientID0014','PACUPatientID0015','PACUPatientID0016','PACUPatientID0017','PACUPatientID0018','PACUPatientID0019','PACUPatientID0020','PACUPatientID0021','PACUPatientID0022','PACUPatientID0023','PACUPatientID0024','PACUPatientID0025','PACUPatientID0026','PACUPatientID0027','PACUPatientID0028','PACUPatientID0029','PACUPatientID0030','PACUPatientID0031','PACUPatientID0032','PACUPatientID0033','PACUPatientID0034','PACUPatientID0035')
update cp set cp.plannedproceduretime = @Past from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000201','pendding')


update cp set cp.plannedproceduretime = @Future from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID000001071')

update cp set cp.plannedproceduretime = @Yesterday from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000107','PatientID00000108','PatientID00000109','PatientID00000110','PatientID00000111','PatientID00000112','PatientID00000113')


update cp set cp.plannedproceduretime = @Tomorrow from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000105','PatientID00000106','PatientID00000114','PatientID00000115','PatientID00000116','scheduled') 
use POC
update cd set cd.canceldate = @Today from CancelDetails cd
inner join CaseMain cm on cm.canceldetailsfrid = cd.firstrevid

inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000101','PatientID00000107','PatientID00000114','sowha5') 

update cd set cd.canceldate = @Tomorrow from CancelDetails cd
inner join CaseMain cm on cm.canceldetailsfrid = cd.firstrevid

inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000102','PatientID00000108','PatientID00000112','PatientID00000115') 

update cd set cd.canceldate = @Past from CancelDetails cd
inner join CaseMain cm on cm.canceldetailsfrid = cd.firstrevid

inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000201')

update cd set cd.canceldate = @Yesterday from CancelDetails cd
inner join CaseMain cm on cm.canceldetailsfrid = cd.firstrevid

inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('PatientID00000103','PatientID00000109','PatientID00000116')

go

enable trigger all on caseplan  
go
enable trigger all on CancelDetails


select pc.patientid,cp.plannedproceduretime from caseplan cp 
inner join CasePlanCaseMain cpm on cpm.firstrevid = cp.firstrevid
inner join casemain cm on cm.firstrevid = cpm.casemainfrid
inner join caseclass cc on cc.firstrevid = cm.caseclassfrid
inner join CaseStatus cs on cs.firstrevid = cm.casestatusfrid
inner join SYS_DocumentsOfFolder dof on dof.FirstRevID = cm.firstrevid
inner join SYS_DocumentsOfFolder dof2 on dof2.FolderID = dof.FolderID
inner join Patient_ContactPerson pc on pc.firstrevid = dof2.FirstRevID
where pc.patientid in ('filter1','filter2','filter3','localization','completed','Configuration','DroppedCase','duplicate','PatientID00000101','PatientID00000102','PatientID00000103','PatientID00000104','PatientID00000501','PatientID00000502','popover1','sowha1','sowha2','sowha3','sowha4','sowha5','sowha6','sowha7','PatientID00000201','pendding','PatientID00000201','pendding','PatientID00000107','PatientID00000108','PatientID00000109','PatientID00000110','PatientID00000111','PatientID00000112','PatientID00000113','PatientID00000105','PatientID00000106','PatientID00000114','PatientID00000115','PatientID00000116','scheduled','PatientID000001071','PACUPatientID0012','PACUPatientID0013','PACUPatientID0014','PACUPatientID0015','PACUPatientID0016','PACUPatientID0017','PACUPatientID0018','PACUPatientID0019','PACUPatientID0020','PACUPatientID0021','PACUPatientID0022','PACUPatientID0023','PACUPatientID0024','PACUPatientID0025','PACUPatientID0026','PACUPatientID0027','PACUPatientID0028','PACUPatientID0029','PACUPatientID0030','PACUPatientID0031','PACUPatientID0032','PACUPatientID0033','PACUPatientID0034','PACUPatientID0035') 
