use POC;

Go

DECLARE @userrolefrid nvarchar(20), @userfieldfrid nvarchar(20), @profilename nvarchar(20), 
@patientlistfolderid nvarchar(20), @deptfrid nvarchar(20)

SET @profilename = 'Nosite'
IF NOT EXISTS ( SELECT 1 FROM SYS_DocumentsOfFolder WHERE FolderID = 'USERROLE' AND FirstRevID = 'Nositeuserrolefrid')

BEGIN
			PRINT 'Creating security profile ' + @profilename

			-- This frid is reserverd for no site profile, don't change it.
			SET @userrolefrid = 'Nositeuserrolefrid'

			insert into Document values (@userrolefrid, @userrolefrid, '5000', GETDATE(), '0','0','30','0',NULL)
			insert into SYS_DocumentsOfFolder values ('USERROLE',@userrolefrid,'0')

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			-- Profile Name
			insert into Field values (@userfieldfrid, @userrolefrid,NULL,'/A00G/',NULL,'0',@profilename,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			-- Access to applications
			SET @patientlistfolderid = (select FolderID from SYS_Folder where Name = 'Patient List')
			insert into SYS_FolderAccess values  (@patientlistfolderid, '1', @userrolefrid)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			-- Access to departments
			SET @deptfrid = (select firstrevid from Department where name = 'Temp')
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/DPTS/1/DPT/', NULL, '100', NULL, NULL, NULL, NULL, NULL,'4','1',@deptfrid, NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			
			-- can modify patient data
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/WA/', NULL, '5', 'T', NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			-- can modify end cases and visits
			insert into Field values (@userfieldfrid, @userrolefrid,NULL,'/WACC/',NULL,'5','T',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			--can delete patient registrations and patient cases
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/DR/',NULL,'5','T',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			-- can restore cases from the warehouse
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/OA/',NULL,'5','T',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			
			--can manage drug and fluid orders
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/MO/',NULL,'5','T',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			

			--can record drugs and fluids without order
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/DA/',NULL,'5','T',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			SET @userfieldfrid = LEFT(NEWID(), 18)
			SET @userfieldfrid =  REPLACE(@userfieldfrid,'-','')
			
			-- Profile description
			insert into Field values (@userfieldfrid, @userrolefrid, NULL, '/A00J/', NULL,'0','Profile description',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL)

			PRINT 'Created security profile ' + @profilename + ' successfully.'

END

ELSE

BEGIN

			PRINT 'Security profile '+ @profilename + ' already exists'

END

go
