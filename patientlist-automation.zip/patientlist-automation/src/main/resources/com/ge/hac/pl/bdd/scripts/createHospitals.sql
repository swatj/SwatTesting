USE POC;

GO

CREATE PROCEDURE createHospitals(
	@name NVARCHAR(50), @abbreviation NVARCHAR(80), @description NVARCHAR(500), @mapcode NVARCHAR(50), @mapname NVARCHAR(50), @id NVARCHAR(15), 
	@code NVARCHAR(30), @departmentList NVARCHAR(MAX)  
)

AS

DECLARE 
	@newFrid					NVARCHAR(20),	
	@creationTime				DATETIME2 (7),
	@index						INT,
	@delimeter					NVARCHAR(10),
	@departmentFrid				NVARCHAR(50),
	@deptName					NVARCHAR(100),
	@elementID					INT

BEGIN

    /* FRID to be used */
	SET @newFrid = LEFT(NEWID(), 18)
	SET @newFrid = REPLACE(@newFrid,'-','')
	SET @newFrid = CONCAT('A',@newFrid)
	
	/* Set the creation time */
	SET @creationTime = CURRENT_TIMESTAMP	


	INSERT INTO Hospital 
	(
		SessionID, RevisionID, FirstRevID, 
		DocumentID, CreationTime, id, 
		mapname, code, abbreviation, 
		description, mapcode, name
	) 
	VALUES 
	(
		'0', 0, @newFrid, 
		@newFrid, @creationTime, @id, 
		@mapname, @code, @abbreviation, 
		@description, @mapcode, @name
	) 

	
	/* Insert the corresponding document */
	INSERT INTO Document 
	(
		RevisionID, DocumentID, SessionID, 
		TemplateDocumentID, TemplateID, Status, 
		CreationTime, FirstRevID
	) 
	VALUES 
	(
		0, @newFrid, '0', 
		'1G0000000002QD05BG', '3P0157', 0, 
		@creationTime, @newFrid
	)

	INSERT INTO SYS_DocumentsOfFolder
	(
		FolderID, FirstRevID, RelationType
	)
	VALUES
	(
		'1Q901I7', @newFrid, 0
	)

	/* Find the input department names and insert into Hospital Departments */

	SET @elementID = 0

	SET @delimeter = ','
	SET @index = CHARINDEX(@delimeter, @departmentList)
	
	IF((@index != 0) AND (@departmentList IS NOT NULL))/* Enter only when more than one department has been supplied */
	BEGIN
		WHILE (@index != 0)
		BEGIN
			SET @deptName = LTRIM(RTRIM(SUBSTRING(@departmentList, 0, @index)))
			SELECT @departmentFrid = firstrevid FROM Department WHERE name = @deptName 
			INSERT INTO HospitalDepartments 
			(
				ElementID, FirstRevID, departmentfrid
			) 
			VALUES 
			(
				@elementID, @newFrid, @departmentFrid
			) 
					
			SET @departmentList = SUBSTRING(@departmentList, @index+1, LEN(@departmentList)+1)
			SET @index = CHARINDEX(@delimeter, @departmentList)
			SET @elementID=@elementID+1
			
		END
	END

	IF (@departmentList IS NOT NULL AND (LEN(LTRIM(RTRIM(@departmentList))) != 0))
	BEGIN
		SET @deptName = LTRIM(RTRIM(@departmentList))
		SELECT @departmentFrid = firstrevid FROM Department WHERE name = @deptName
			INSERT INTO HospitalDepartments 
			(
				ElementID, FirstRevID, departmentfrid
			) 
			VALUES 
			(
				@elementID, @newFrid, @departmentFrid
			) 
	END
END

GO


EXEC createHospitals 'Hospital-10', 'Hospital-10', 'Hospital-10', 'Hospital-10', 'Hospital-10', 'Hospital-10','Hospital-10', 'Main theater,Minor surgery,PACU general'

GO


DROP PROCEDURE createHospitals

GO

