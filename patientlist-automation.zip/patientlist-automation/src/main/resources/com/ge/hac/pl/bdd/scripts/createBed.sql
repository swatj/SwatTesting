USE POC;

GO

CREATE PROCEDURE createBeds(
	@name NVARCHAR(50), @abbreviation NVARCHAR(80), @description NVARCHAR(500), @mapcode NVARCHAR(50), @mapname NVARCHAR(50), @id NVARCHAR(15), 
	@isManagingDevices bit  
)

	
AS

DECLARE 
	@newFrid					NVARCHAR(20),	
	@creationTime				DATETIME2 (7)

BEGIN

	/* FRID to be used */
	SET @newFrid = LEFT(NEWID(), 18)
	SET @newFrid = REPLACE(@newFrid,'-','')
	SET @newFrid = CONCAT('A',@newFrid)
	
	/* Set the creation time */
	SET @creationTime = CURRENT_TIMESTAMP

	/* Insert into room table -ICU Type */
	INSERT INTO [dbo].[Bed]
	(
	[firstrevid],[documentid],[revisionid],[SessionID],[creationtime],[bedtypefrid],[id],[abbreviation],[name],[description],[mapcode],[mapname],[IsManagingDevices]
	)
	VALUES 
	(
	@newFrid,@newFrid,0,'0',@creationTime,null,@id,@abbreviation,@name,@description,@mapcode,@mapname, @isManagingDevices
	)

	/* Insert the corresponding document */
	INSERT INTO Document 
	(
		RevisionID, DocumentID, SessionID,TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID
	) 
	VALUES 
	(
		0, @newFrid, '0','1G0000000002QD04Z7', '1200BM', 0, @creationTime, @newFrid
	)

	/* Insert entry under beds folder */
	INSERT INTO SYS_DocumentsOfFolder
	(
		FolderID, FirstRevID, RelationType
	)
	VALUES
	(
		'1Q902KW', @newFrid, 0
	)

END

GO

EXEC createBeds 'ICUBed 10', 'ICUBed10', 'ICUBed10', 'ICUBed10', 'ICUBed10', 'ICUBed10', 1
EXEC createBeds 'ICUBed 11', 'ICUBed11', 'ICUBed11', 'ICUBed11', 'ICUBed11', 'ICUBed11', 1
EXEC createBeds 'ICUBed 12', 'ICUBed12', 'ICUBed12', 'ICUBed12', 'ICUBed12', 'ICUBed12', 1
EXEC createBeds 'ICUBed 13', 'ICUBed13', 'ICUBed13', 'ICUBed13', 'ICUBed13', 'ICUBed13', 1
EXEC createBeds 'ICUBed 14', 'ICUBed14', 'ICUBed14', 'ICUBed14', 'ICUBed14', 'ICUBed14', 1
EXEC createBeds 'ICUBed 15', 'ICUBed15', 'ICUBed15', 'ICUBed15', 'ICUBed15', 'ICUBed15', 1
EXEC createBeds 'ICUBed 16', 'ICUBed16', 'ICUBed16', 'ICUBed16', 'ICUBed16', 'ICUBed16', 1
EXEC createBeds 'ICUBed 17', 'ICUBed17', 'ICUBed17', 'ICUBed17', 'ICUBed17', 'ICUBed17', 1
EXEC createBeds 'ICUBed 18', 'ICUBed18', 'ICUBed18', 'ICUBed18', 'ICUBed18', 'ICUBed18', 1
EXEC createBeds 'ICUBed 19', 'ICUBed19', 'ICUBed19', 'ICUBed19', 'ICUBed19', 'ICUBed19', 1
EXEC createBeds 'ICUBed 20', 'ICUBed20', 'ICUBed20', 'ICUBed20', 'ICUBed20', 'ICUBed20', 1
EXEC createBeds 'ICUBed 21', 'ICUBed21', 'ICUBed21', 'ICUBed21', 'ICUBed21', 'ICUBed21', 1
EXEC createBeds 'ICUBed 22', 'ICUBed22', 'ICUBed22', 'ICUBed22', 'ICUBed22', 'ICUBed22', 1
EXEC createBeds 'ICUBed 23', 'ICUBed23', 'ICUBed23', 'ICUBed23', 'ICUBed23', 'ICUBed23', 1 
EXEC createBeds 'PACUBed 1-3-1', 'PACUBed1-3-1', 'PACUBed1-3-1', 'PACUBed1-3-1', 'PACUBed1-3-1', 'PACUBed1-3-1', 1
EXEC createBeds 'PACUBed 1-3-2', 'PACUBed1-3-2', 'PACUBed1-3-2', 'PACUBed1-3-2', 'PACUBed1-3-2', 'PACUBed1-3-2', 1
EXEC createBeds 'PACUBed 1-3-3', 'PACUBed1-3-3', 'PACUBed1-3-3', 'PACUBed1-3-3', 'PACUBed1-3-3', 'PACUBed1-3-3', 1
EXEC createBeds 'PACUBed 1-3-4', 'PACUBed1-3-4', 'PACUBed1-3-4', 'PACUBed1-3-4', 'PACUBed1-3-4', 'PACUBed1-3-4', 1
EXEC createBeds 'PACUBed 1-3-5', 'PACUBed1-3-5', 'PACUBed1-3-5', 'PACUBed1-3-5', 'PACUBed1-3-5', 'PACUBed1-3-5', 1
EXEC createBeds 'PACUBed 1-3-6', 'PACUBed1-3-6', 'PACUBed1-3-6', 'PACUBed1-3-6', 'PACUBed1-3-6', 'PACUBed1-3-6', 1
EXEC createBeds 'PACUBed 1-3-7', 'PACUBed1-3-7', 'PACUBed1-3-7', 'PACUBed1-3-7', 'PACUBed1-3-7', 'PACUBed1-3-7', 1
EXEC createBeds 'PACUBed 1-3-8', 'PACUBed1-3-8', 'PACUBed1-3-8', 'PACUBed1-3-8', 'PACUBed1-3-8', 'PACUBed1-3-8', 1
EXEC createBeds 'PACUBed 1-3-9', 'PACUBed1-3-9', 'PACUBed1-3-9', 'PACUBed1-3-9', 'PACUBed1-3-9', 'PACUBed1-3-9', 1
EXEC createBeds 'PACUBed 1-3-10', 'PACUBed1-3-10', 'PACUBed1-3-10', 'PACUBed1-3-10', 'PACUBed1-3-10', 'PACUBed1-3-10', 1
EXEC createBeds 'PACUBed 1-4-1', 'PACUBed1-4-1', 'PACUBed1-4-1', 'PACUBed1-4-1', 'PACUBed1-4-1', 'PACUBed1-4-1', 1



GO


DROP PROCEDURE createBeds

GO

