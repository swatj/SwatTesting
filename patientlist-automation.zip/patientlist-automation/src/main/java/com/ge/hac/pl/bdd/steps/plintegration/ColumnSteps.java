package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Column;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

public class ColumnSteps
{

    int columnWidthAfterDecrease, columnWidthBeforeDecrease, columnWidthBeforeIncrease, columnWidthAfterIncrease,
            columnPositionBefore, columnPositionAfter;

    @When("the user clicks on configuration setting icon")
    public void clickOnColumnConfig()
            throws IOException, InterruptedException
    {
        Column.getInstance().clickOnColumnConfig();
    }

    @Then("the user clicks on configuration setting icon")
    public void clickOnColumnConfiguration()
            throws IOException, InterruptedException
    {
        Column.getInstance().clickOnColumnConfig();
    }

    @Then("the column pool drop down shows list of configured columns:$dataTable")
    public void verifyDefaultColumnConfigurationSetting(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        Column.getInstance().verifyDefaultSettings(dataTable);
        Column.getInstance().clickOnColumnConfig();
    }

    @Then("the user is able to check the <Column> checkbox")
    public void selectColumnConfigurationSetting(@Named("Column") String columnName)
            throws Exception
    {
        PatientList.getInstance().addColumnToColumnList(columnName);

    }

    @Then("the user is able to view the <Column> on the patient grid")
    public void verifyVisibleColumnOnPatientList(@Named("Column") String columnName)
            throws Exception
    {
        boolean columnDisplayed = PatientList.getInstance().verifyColumnDisplay(columnName);
        Assert.assertEquals("user is able to view the added column=" + columnName + " on Patient List grid", true,
                columnDisplayed);

    }

    @Then("the user is able to uncheck the column checkbox")
    public void deselectColumnConfigurationSetting(@Named("Column") String columnName)
            throws Exception
    {
        PatientList.getInstance().removeColumnFromColumnList(columnName);

    }

    @Then("the column is removed from the patient list grid")
    public void verifyInvisableColumnOnPatientList(@Named("Column") String columnName)
            throws Exception
    {
        boolean columnDisplayed = PatientList.getInstance().verifyColumnDisplay(columnName);
        Assert.assertEquals("user is not able to view the removed column=" + columnName + " on Patient List grid",
                false, columnDisplayed);
    }

    @When("the user resizes the column by increasing its width")
    public void verifyIncWidth(@Named("ColumnName") String column)
            throws Exception
    {
        PatientList.getInstance().addColumnToColumnList(column);
        Column.getInstance().clickIncWidthColumn(column);
    }

    @Then("the column size is increased in patient list grid")
    public void verifyColumnResizeForWidthIncrease(@Named("ColumnName") String column)
            throws IOException, Exception
    {
        PatientList.getInstance().addColumnToColumnList(column);
        Column.getInstance().verifyColumnIncWidth(column);
    }

    @When("the user resizes the column by decreasing its width")
    public void decreasesColumnWidth(@Named("ColumnName") String column)
            throws IOException, Exception
    {
        PatientList.getInstance().addColumnToColumnList(column);
        Column.getInstance().clickDecWidthColumn(column);
    }

    @Then("the column size is decreased in patient list grid")
    public void verifyColumnResizeForWidthDecrease(@Named("ColumnName") String column)
            throws IOException, Exception
    {
        Column.getInstance().verifyColumnDecWidth(column);
    }

    @When("the user selects the reorder button")
    public void clickReorderButton()
            throws IOException, InterruptedException
    {
        Column.getInstance().clickOnColumnReOrderConfig();
    }

    @When("the user selects the icon to move the column to the right side")
    public void selectTheColumnToRightReorder(@Named("ColumnName") String sortingColumn)
            throws IOException, Exception
    {
        PatientList.getInstance().addColumnToColumnList(sortingColumn);
        Column.getInstance().selectTheColumnToRightReorder(sortingColumn);

    }

    @When("the user selects the icon to move the column to the left side")
    public void selectTheColumnToLeftReorder(@Named("ColumnName") String sortingColumn)
            throws IOException, Exception
    {
        PatientList.getInstance().addColumnToColumnList(sortingColumn);
        Column.getInstance().selectTheColumnToLeftReorder(sortingColumn);

    }

    @Then("the column should move to the right side in patient list grid")
    public void verifycolumnReOrder_Right(@Named("ColumnName") String sortingColumn)
            throws IOException, Exception
    {

        Column.getInstance().verifyColumnReOrder_Right(sortingColumn);
    }

    @Then("the column should move to the left side in patient list grid")
    public void verifycolumnReOrder_Left(@Named("ColumnName") String sortingColumn)
            throws IOException, Exception
    {

        Column.getInstance().verifyColumnReOrder_Left(sortingColumn);

    }

    @Then("remember the position for <ColumnName> column")
    public void setAllcolumnsOrder(@Named("ColumnName") String ColumnName)
            throws InterruptedException, IOException

    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(ColumnName);

        columnPositionBefore = PatientListData.getInstance().getColumnPosition(headerNames, ColumnName);

    }

    @Then("Verify that the <ColumnName> column position is same as before relogin position")
    public void verifycolumnsOrder(@Named("ColumnName") String ColumnName)
            throws IOException, Exception
    {

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(ColumnName);

        columnPositionAfter = PatientListData.getInstance().getColumnPosition(headerNames, ColumnName);

        Assert.assertEquals("verify " + ColumnName + " column position", columnPositionBefore, columnPositionAfter);

    }

    @Then("Verify that the <ColumnName> column position is not same as before relogin position")
    public void verifycolumnsOrderNotSame(@Named("ColumnName") String ColumnName)
            throws IOException, Exception
    {

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(ColumnName);

        columnPositionAfter = PatientListData.getInstance().getColumnPosition(headerNames, ColumnName);

        Assert.assertFalse("Verify " + ColumnName + " column position is different after login before ="
                + columnPositionBefore + "  after=" + columnPositionAfter,
                !(columnPositionBefore == columnPositionAfter));

    }

    @When("the user clicks on any column header")
    public void clickOnColumnHeader()
            throws Exception
    {
        Column.getInstance().clickOnColumnHeader(Constants.OR_COLUMN);
    }
}
