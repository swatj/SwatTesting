package com.ge.hac.pl.bdd.functions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ge.hac.pl.bdd.utility.Constants;

public class UpdateDate
{
    private static Logger     logger   = Logger.getLogger(UpdateDate.class);
    private static UpdateDate instance = null;

    private UpdateDate()
    {

    }

    public static UpdateDate getInstance()
    {
        if ( instance == null )
        {
            instance = new UpdateDate();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    public void updateXML(String timeEvent, String XmlFileName, String time)
    {

        try
        {
            String sourceFile = Constants.TEST_DATA_DIR;
            String destFile = Constants.CA_INTERFACE_DIR;

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            for (File file : new File(sourceFile).listFiles())
            {
                Document doc = docBuilder.parse(file.getAbsolutePath());
                String fileName = file.getName();
                if ( fileName.equalsIgnoreCase(XmlFileName) )
                {
                    XPath xpath = XPathFactory.newInstance().newXPath();
                    Element e = (Element) xpath.evaluate("/casim/body/patient/caseData/intraopCase/observation/code",
                            doc, XPathConstants.NODE);
                    if ( e != null ) e.setTextContent(timeEvent);
                    e = (Element) xpath.evaluate(
                            "/casim/body/patient/caseData/intraopCase/observation/observationValue/valueTime", doc,
                            XPathConstants.NODE);
                    if ( e != null )
                        e.setTextContent((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).format(new Date())
                                .replaceAll("/", "-").replaceAll(" ", "T"));
                    e = (Element) xpath.evaluate(
                            "/casim/body/patient/caseData/intraopCase/observation/observationValue/value", doc,
                            XPathConstants.NODE);
                    if ( e != null )
                        e.setTextContent((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).format(new Date())
                                .replaceAll("/", "-").replaceAll(" ", "T"));
                    e = (Element) xpath.evaluate("/casim/body/patient/caseData/casePlan/plannedProcedureDate", doc,
                            XPathConstants.NODE);
                    if ( e != null )
                    {
                        if ( time.equalsIgnoreCase("CurrentDate") )
                            e.setTextContent((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).format(new Date())
                                    .replaceAll("/", "-").replaceAll(" ", "T"));
                        else if ( time.equalsIgnoreCase("FutureDate") )
                            e.setTextContent((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"))
                                    .format(new Date(System.currentTimeMillis() + (1000 * 60 * 60 * 24)))
                                    .replaceAll("/", "-").replaceAll(" ", "T"));
                        else if ( time.equalsIgnoreCase("PastDate") )
                            e.setTextContent((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"))
                                    .format(new Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24)))
                                    .replaceAll("/", "-").replaceAll(" ", "T"));
                    }

                    Transformer transformer = TransformerFactory.newInstance().newTransformer();
                    transformer.transform(new DOMSource(doc), new StreamResult(new File(destFile + "\\" + fileName)));
                    transformer.transform(new DOMSource(doc), new StreamResult(new File(sourceFile + "\\" + fileName)));
                    break;
                }

            }
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.UpdateDate.updateXML(String, String, String)", e);
        }
    }

}
