/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class PatientListData
{
    private static Logger          logger   = Logger.getLogger(PatientListData.class);
    private SeleniumUtility        selUtility;
    private static PatientListData instance = null;

    private PatientListData()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("PatientListData() - error initializing web browser.", e);
        }

    }

    public static PatientListData getInstance()
    {
        if ( instance == null )
        {
            instance = new PatientListData();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    // make required column visible
    public void makeColumnVisible(List<String> patientListColumnHeaderList)
            throws Exception
    {
        for (int i = 0; i < patientListColumnHeaderList.size(); i++)
        {
            String columnName = patientListColumnHeaderList.get(i);
            // verify given columnName is visible on screen or not.
            boolean visible = PatientList.getInstance().verifyColumnDisplay(columnName);
            logger.debug("PatientListColumn:makeColumnVisible:make " + columnName + " visible");
            if ( visible == false )
            {
                // if columnName is not visible then add that column from configuration button
                PatientList.getInstance().addColumnToColumnList(columnName);
                boolean isColumnVisible = PatientList.getInstance().verifyColumnDisplay(columnName);
                Assert.assertEquals("After adding column verify column " + columnName + " is displayed on screen",
                        true, isColumnVisible);
            }
        }
    }

    // this function gives row number depending upon passed row value
    public int getRowNumber(String patientID, Map<String, Integer> patientListColumnHeaderList)
            throws IOException, InterruptedException
    {
        int patientIdRowNum = 0;
        // get column position from hash map
        int patientIDColumnPosition = patientListColumnHeaderList.get(Constants.PATIENT_ID_COLUMN);
        // create xpath by using column number
        String xpath = "//td[" + patientIDColumnPosition + "]";
        List<WebElement> allRows = selUtility.findElements("allRows");
        for (int i = 0; i < allRows.size(); i++)
        {
            List<WebElement> patientIDColumnData = selUtility.findElementsUsingDynamicPath("allRows", xpath);

            // find row number by checking expected and actual values
            if ( patientID.equals((patientIDColumnData.get(i).getText())) )
            {
                // Highlight the row in patient list
                patientIDColumnData.get(i).click();
                patientIdRowNum = i + 1;
                break;
            }
        }

        logger.debug("PatientList:getRowNumber: row number of " + patientID + " is " + patientIdRowNum);
        return patientIdRowNum;
    }

    // this function retrieve value of cell by using row number and column
    public String getCellValue(int rowNumber, int columnNumber)
            throws IOException
    {
        // create xpath by using rowNumber and columnNumber and retrive element
        String cellValueXpath = "[" + rowNumber + "]//td[" + columnNumber + "]";
        List<WebElement> cellData = selUtility.findElementsUsingDynamicPath("allRows", cellValueXpath);
        logger.debug("PatientList:getCellValue: value of cell[" + rowNumber + "][" + columnNumber + "]="
                + cellData.get(0).getText());
        return cellData.get(0).getText();
    }

    // this function retrieve color code of cell by using row number and column
    public String getCellColorCodeValue(int rowNumber, int columnNumber)
            throws IOException
    {
        // create xpath by using rowNumber and columnNumber and retrive element
        String cellValueXpath = "[" + rowNumber + "]//td[" + columnNumber + "]//div//div//div";
        List<WebElement> cellData = selUtility.findElementsUsingDynamicPath("allRows", cellValueXpath);
        logger.debug("PatientList:getCellValue: CSS value of cell[" + rowNumber + "][" + columnNumber + "]="
                + cellData.get(0).getCssValue("background-image"));
        return cellData.get(0).getCssValue("background-image") + cellData.get(0).getCssValue("background");

    }

    // this function retrieve Care Phase status value of cell by using row number and column
    public String getCellCarePhaseValue(int rowNumber, int columnNumber)
            throws IOException
    {
        String cellValueXpath = "[" + rowNumber + "]//td[" + columnNumber + "]//div//div";
        List<WebElement> cellData = selUtility.findElementsUsingDynamicPath("allRows", cellValueXpath);
        logger.debug("PatientList:getCellValue: CSS value of cell[" + rowNumber + "][" + columnNumber + "]="
                + cellData.get(0).getText());
        return cellData.get(0).getText();
    }

    // this function retrieve color of cell by using row number and column
    public String getCellColorValue(int rowNumber, int columnNumber, String expectedColor)
            throws IOException
    {
        // create xpath by using rowNumber and columnNumber and retrive element
        String cellValueXpath = "[" + rowNumber + "]//td[" + columnNumber + "]//div//div//div";
        List<WebElement> cellData = selUtility.findElementsUsingDynamicPath("allRows", cellValueXpath);
        logger.debug("PatientList:getCellValue: CSS value of cell[" + rowNumber + "][" + columnNumber + "]="
                + cellData.get(0).getCssValue("color"));
        return cellData.get(0).getCssValue("color");
    }

    // this function is used to get column position
    public Map<String, Integer> getPatientListColumnsPosition(List<String> patientListColumnHeaderList)
            throws IOException, InterruptedException
    {

        Map<String, Integer> patientListColumnsHeaderIndexMap = new HashMap<String, Integer>();
        for (int expectedColumn = 0; expectedColumn < patientListColumnHeaderList.size(); expectedColumn++)
        {
            String columnName = patientListColumnHeaderList.get(expectedColumn);
            List<WebElement> allColumns = selUtility.findElements("allColumns");

            for (int actualColumn = 0; actualColumn < allColumns.size(); actualColumn++)
            {
                if ( columnName.equalsIgnoreCase(allColumns.get(actualColumn).getText()) )
                {
                    patientListColumnsHeaderIndexMap.put(columnName, actualColumn + 1);
                    // if column found then exit the search
                    break;
                }
            }

        }
        logger.debug("PatientList:getColumnPosition: get map of column name with theire position "
                + patientListColumnsHeaderIndexMap);
        return patientListColumnsHeaderIndexMap;
    }

    // get row which is having specified patientID
    public int getPatientIDRow(List<String> patientListColumnHeaderList, String patientIDValue)
            throws IOException, InterruptedException
    {
        Map<String, Integer> patientListColumnsHeaderIndexMap = getPatientListColumnsPosition(patientListColumnHeaderList);
        logger.debug("PatientListColumn:getPatientIDRow:get row of PatientId=" + patientIDValue);
        // get row in which PatientID is present
        return getRowNumber(patientIDValue, patientListColumnsHeaderIndexMap);

    }

    // verify value in care phase column
    public void verifyCarePhase(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedCarePhaseValue)
            throws IOException, InterruptedException
    {
        int carePhaseColPosition = getColumnPosition(patientListColumnHeaderList, Constants.CARE_PHASE_COLUMN);
        String actCarePhaseValue = getCellValue(patientIDRowNumber, carePhaseColPosition);
        Assert.assertEquals("Verify Care phase column displays value=" + expectedCarePhaseValue + " at row number="
                + patientIDRowNumber + " and column number=" + carePhaseColPosition, expectedCarePhaseValue,
                actCarePhaseValue);
    }

    // verify value in Care Phase value of care phase column
    public void verifyCarePhaseValue(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedCarePahseValue)
            throws IOException, InterruptedException
    {
        int carePhaseColPosition = getColumnPosition(patientListColumnHeaderList, Constants.CARE_PHASE_COLUMN);
        String actualCarePahseValue = getCellCarePhaseValue(patientIDRowNumber, carePhaseColPosition);
        Assert.assertEquals("Verify Care phase column displays value=" + expectedCarePahseValue + " at row number="
                + patientIDRowNumber + " and column number=" + carePhaseColPosition, expectedCarePahseValue,
                actualCarePahseValue);
    }

    // verify value in color code of care phase column
    public void verifyColorCode(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedColorCode, String carePahseValue)
            throws IOException, InterruptedException
    {
        expectedColorCode = expectedColorCode.toLowerCase();
        int carePhaseColPosition = getColumnPosition(patientListColumnHeaderList, Constants.CARE_PHASE_COLUMN);
        String actualColorCode = getCellColorCodeValue(patientIDRowNumber, carePhaseColPosition).toLowerCase();
        if ( (carePahseValue.equals(Constants.CARE_PHASE_NOT_ARRIVED) || carePahseValue
                .equals(Constants.CARE_PHASE_DISCHARGED)) )
        {
            Assert.assertFalse("Care Phase column contains color code",
                    actualColorCode.matches(".*(" + expectedColorCode + ").*"));
        }
        else
        {
            Assert.assertTrue("Care Phase column dosen't contains color code",
                    actualColorCode.matches(".*(" + expectedColorCode + ").*"));
        }
    }

    // verify value in color of care phase column
    public void verifyColor(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedColor)
            throws IOException, InterruptedException
    {
        int carePhaseColPosition = getColumnPosition(patientListColumnHeaderList, Constants.CARE_PHASE_COLUMN);
        String actColor = getCellColorValue(patientIDRowNumber, carePhaseColPosition, expectedColor);
        Assert.assertEquals("Verify Care phase column displays value=" + expectedColor + " at row number="
                + patientIDRowNumber + " and column number=" + carePhaseColPosition, expectedColor, actColor);
    }

    // verify value in surgeon column
    public void verifyMultipleSurgeon(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedSurgeonValue)
            throws IOException, InterruptedException
    {
        int surgeonColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SURGEON_COLUMN);
        String actSurgeonValue = getCellValue(patientIDRowNumber, surgeonColPosition);
        // check surgeon name is displayed on new line
        if ( actSurgeonValue.contains(Constants.NEWLINE_SEPERATOR) )
        {
            actSurgeonValue = actSurgeonValue.replace(Constants.NEWLINE_SEPERATOR,
                    Constants.COMMA_SEPERATOR);
        }
        else
        {
            Assert.fail("Multiple surgeon should display new line character but was" + actSurgeonValue);
        }
        Assert.assertEquals("Verify Surgeon column displays value=" + expectedSurgeonValue + " at row number="
                + patientIDRowNumber + " and column number=" + surgeonColPosition, expectedSurgeonValue,
                actSurgeonValue);
    }

    // verify single value in surgeon column
    public void verifySurgeon(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedSurgeonValue)
            throws IOException, InterruptedException
    {
        int surgeonColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SURGEON_COLUMN);
        String actSurgeonValue = getCellValue(patientIDRowNumber, surgeonColPosition);
        actSurgeonValue = actSurgeonValue.replace(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Surgeon column displays value=" + expectedSurgeonValue + " at row number="
                + patientIDRowNumber + " and column number=" + surgeonColPosition, expectedSurgeonValue,
                actSurgeonValue);
    }

    // verify value in PostOp column
    public void verifyPostop(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedPostopValue)
            throws IOException, InterruptedException
    {
        int postopColPosition = getColumnPosition(patientListColumnHeaderList, Constants.POST_OP_COLUMN);
        String actPostopValue = getCellValue(patientIDRowNumber, postopColPosition);
        if ( actPostopValue.contains(Constants.NEWLINE_SEPERATOR) )
        {
            actPostopValue = actPostopValue.replace(Constants.NEWLINE_SEPERATOR,
                    Constants.COMMA_SEPERATOR);
        }
        Assert.assertEquals("Verify Postop column displays value=" + expectedPostopValue + " at row number="
                + patientIDRowNumber + " and column number=" + postopColPosition, expectedPostopValue, actPostopValue);
    }

    // verify value in current location column
    public void verifyCurrentLocation(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedCurrentLocation)
            throws IOException, InterruptedException
    {
        int currentLocationColPosition = getColumnPosition(patientListColumnHeaderList,
                Constants.CURRENT_LOCATION_COLUMN);
        String actCurrentLocation = getCellValue(patientIDRowNumber, currentLocationColPosition);
        Assert.assertEquals("Verify Current location column displays value=" + expectedCurrentLocation
                + " at row number=" + patientIDRowNumber + " and column number=" + currentLocationColPosition,
                expectedCurrentLocation, actCurrentLocation);
    }

    // verify value in Case ID column
    public void verifyCaseID(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedCaseIDValue)
            throws IOException, InterruptedException
    {
        int caseIDColPosition = getColumnPosition(patientListColumnHeaderList, Constants.CASE_ID_COLUMN);
        String actCaseIDValue = getCellValue(patientIDRowNumber, caseIDColPosition);
        Assert.assertEquals("Verify Care ID column displays value=" + expectedCaseIDValue + " at row number="
                + patientIDRowNumber + " and column number=" + caseIDColPosition, expectedCaseIDValue, actCaseIDValue);
    }

    // verify value in OR column
    public void verifyOR(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedORValue)
            throws IOException, InterruptedException
    {
        int ORColPosition = getColumnPosition(patientListColumnHeaderList, Constants.OR_COLUMN);
        String actORValue = getCellValue(patientIDRowNumber, ORColPosition);
        actORValue = actORValue.replaceAll(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify OR column displays value=" + expectedORValue + " at row number="
                + patientIDRowNumber + " and column number=" + ORColPosition, expectedORValue, actORValue);
    }

    // verify value in Sched time column
    public void verifySchedTime(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedSchedTimeValue)
            throws Exception
    {
        int schedTimeColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SCHED_TIME_COLUMN);
        String actSchedTimeValue = getCellValue(patientIDRowNumber, schedTimeColPosition);
        // from feature file instead of passing actual date, we will be passing Today,Past,Future keywords
        // otherwise every time before running feature file we need to change sched time manually
        // and while verifying actual sched time with expected sched time we are converting these keyword with expected date values with respective current date
        // e.g Today -08/26/2015 Past -08/20/2015 Future -08/30/2015
        if ( expectedSchedTimeValue.contains("Today") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Today", PatientList.getInstance()
                    .getCurrentPastFutureDate("current"));
        }
        else if ( expectedSchedTimeValue.contains("Past") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Past", PatientList.getInstance()
                    .getCurrentPastFutureDate("past"));
        }
        else if ( expectedSchedTimeValue.contains("Future") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Future", PatientList.getInstance()
                    .getCurrentPastFutureDate("future"));
        }
        else if ( expectedSchedTimeValue.contains("Yesterday") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Yesterday", PatientList.getInstance()
                    .getCurrentPastFutureDate("Yesterday"));
        }
        else if ( expectedSchedTimeValue.contains("Tomorrow") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Tomorrow", PatientList.getInstance()
                    .getCurrentPastFutureDate("Tomorrow"));
        }
        Assert.assertEquals("Verify Sched time column displays value=" + expectedSchedTimeValue + " at row number="
                + patientIDRowNumber + " and column number=" + schedTimeColPosition, expectedSchedTimeValue,
                actSchedTimeValue);
    }

    // verify value in Patient column
    public void verifyPatient(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedPatientValue)
            throws IOException, InterruptedException
    {
        int patientColPosition = getColumnPosition(patientListColumnHeaderList, Constants.PATIENT_COLUMN);
        String actPatientValue = getCellValue(patientIDRowNumber, patientColPosition);
        actPatientValue = actPatientValue.replaceAll(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Patient column displays value=" + expectedPatientValue + " at row number="
                + patientIDRowNumber + " and column number=" + patientColPosition, expectedPatientValue,
                actPatientValue);
    }

    // verify value in Visit ID column
    public void verifyVisitID(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedVisitID)
            throws IOException, InterruptedException
    {
        int visitIDColPosition = getColumnPosition(patientListColumnHeaderList, Constants.VISIT_ID_COLUMN);
        String actVisitIDValue = getCellValue(patientIDRowNumber, visitIDColPosition);
        Assert.assertEquals("Verify Visit ID column displays value=" + expectedVisitID + " at row number="
                + patientIDRowNumber + " and column number=" + visitIDColPosition, expectedVisitID, actVisitIDValue);
    }

    // verify value in Procedure column
    public void verifyProcedure(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedProcedure)
            throws IOException, InterruptedException
    {
        int procedureColPosition = getColumnPosition(patientListColumnHeaderList, Constants.PROCEDURE_COLUMN);
        String actProcedureValue = getCellValue(patientIDRowNumber, procedureColPosition);
        actProcedureValue = actProcedureValue
                .replace(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Procedure column displays value=" + expectedProcedure + " at row number="
                + patientIDRowNumber + " and column number=" + procedureColPosition, expectedProcedure,
                actProcedureValue);
    }

    // verify value in Anesthesia column
    public void verifyAnesthesia(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedAnesthesia)
            throws IOException, InterruptedException
    {
        int anesthesiaColPosition = getColumnPosition(patientListColumnHeaderList, Constants.ANESTHESIA_COLUMN);
        String actAnesthesiaValue = getCellValue(patientIDRowNumber, anesthesiaColPosition);
        actAnesthesiaValue = actAnesthesiaValue.replace(Constants.NEWLINE_SEPERATOR,
                Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Anesthesia column displays value=" + expectedAnesthesia + " at row number="
                + patientIDRowNumber + " and column number=" + anesthesiaColPosition, expectedAnesthesia,
                actAnesthesiaValue);
    }

    // verify value in Status/LOS column
    public void verifyStatusLOS(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedStatusLOS)
            throws IOException, InterruptedException
    {
        int statusLOSColPosition = getColumnPosition(patientListColumnHeaderList, Constants.STATUS_LOS_COLUMN);
        String actStatusLOSValue = getCellValue(patientIDRowNumber, statusLOSColPosition);
        Assert.assertEquals("Verify Status/Los column displays value=" + expectedStatusLOS + " at row number="
                + patientIDRowNumber + " and column number=" + statusLOSColPosition, expectedStatusLOS,
                actStatusLOSValue);
    }

    // verify value in From/To column
    public void verifyFromTo(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedFromTo)
            throws IOException, InterruptedException
    {
        int fromToColPosition = getColumnPosition(patientListColumnHeaderList, Constants.FROM_TO_COLUMN);
        String actFromToValue = getCellValue(patientIDRowNumber, fromToColPosition);
        Assert.assertEquals("Verify From/To column displays value=" + expectedFromTo + " at row number="
                + patientIDRowNumber + " and column number=" + fromToColPosition, expectedFromTo, actFromToValue);
    }

    // verify value in ASA column
    public void verifyASA(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedASA)
            throws IOException, InterruptedException
    {
        int ASAColPosition = getColumnPosition(patientListColumnHeaderList, Constants.ASA_COLUMN);
        String actASAValue = getCellValue(patientIDRowNumber, ASAColPosition);
        Assert.assertEquals("Verify ASA column displays value=" + expectedASA + " at row number=" + patientIDRowNumber
                + " and column number=" + ASAColPosition, expectedASA, actASAValue);
    }

    // verify value in Specialty column
    public void verifySpecialty(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedSpecialty)
            throws IOException, InterruptedException
    {
        int specialtyColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SPECIALTY_COLUMN);
        String actSpecialtyValue = getCellValue(patientIDRowNumber, specialtyColPosition);
        Assert.assertEquals("Verify Specialty column displays value=" + expectedSpecialty + " at row number="
                + patientIDRowNumber + " and column number=" + specialtyColPosition, expectedSpecialty,
                actSpecialtyValue);
    }

    // verify value in Diagnosis column
    public void verifyDiagnosis(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedDiagnosis)
            throws IOException, InterruptedException
    {
        int diagnosisColPosition = getColumnPosition(patientListColumnHeaderList, Constants.DIAGNOSIS_COLUMN);
        String actDiagnosisValue = getCellValue(patientIDRowNumber, diagnosisColPosition);
        actDiagnosisValue = actDiagnosisValue
                .replace(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Diagnosis column displays value=" + expectedDiagnosis + " at row number="
                + patientIDRowNumber + " and column number=" + diagnosisColPosition, expectedDiagnosis,
                actDiagnosisValue);
    }

    // verify value in Nurse column
    public void verifyNurse(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedNurse)
            throws IOException, InterruptedException
    {
        int nurseColPosition = getColumnPosition(patientListColumnHeaderList, Constants.NURSE_COLUMN);
        String actNurseValue = getCellValue(patientIDRowNumber, nurseColPosition);
        actNurseValue = actNurseValue.replace(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Nurse column displays value=" + expectedNurse + " at row number="
                + patientIDRowNumber + " and column number=" + nurseColPosition, expectedNurse, actNurseValue);
    }

    // verify value in Anes technique column
    public void verifyAnesTechnique(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedAnesTechnique)
            throws IOException, InterruptedException
    {
        int anesTechniqueColPosition = getColumnPosition(patientListColumnHeaderList,
                Constants.ANES_TECHNIQUE_COLUMN);
        String actAnesTechniqueValue = getCellValue(patientIDRowNumber, anesTechniqueColPosition);
        Assert.assertEquals("Verify Anes technique column displays value=" + expectedAnesTechnique + " at row number="
                + patientIDRowNumber + " and column number=" + anesTechniqueColPosition, expectedAnesTechnique,
                actAnesTechniqueValue);
    }

    // verify value in SSN column
    public void verifySSN(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedSSN)
            throws IOException, InterruptedException
    {
        int SSNColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SSN_COLUMN);
        String actSSNValue = getCellValue(patientIDRowNumber, SSNColPosition);
        Assert.assertEquals("Verify SSN column displays value=" + expectedSSN + " at row number=" + patientIDRowNumber
                + " and column number=" + SSNColPosition, expectedSSN, actSSNValue);
    }

    // verify value in Map code column
    public void verifyMapCode(int patientIDRowNumber, List<String> patientListColumnHeaderList, String expectedMapCode)
            throws IOException, InterruptedException
    {
        int mapCodeColPosition = getColumnPosition(patientListColumnHeaderList, Constants.SSN_COLUMN);
        String actMapCodeValue = getCellValue(patientIDRowNumber, mapCodeColPosition);
        Assert.assertEquals("Verify Map code column displays value=" + expectedMapCode + " at row number="
                + patientIDRowNumber + " and column number=" + mapCodeColPosition, expectedMapCode, actMapCodeValue);
    }

    public int getColumnPosition(List<String> patientListColumnHeaderList, String columnName)
            throws IOException, InterruptedException
    {

        Map<String, Integer> patientListColumnsHeaderIndexMap = getPatientListColumnsPosition(patientListColumnHeaderList);
        return patientListColumnsHeaderIndexMap.get(columnName);

    }

    // get patient LOS
    public String getPatientLOS()
            throws IOException, InterruptedException
    {
        String patientLOS = "Elapsed duration not calculated";
        List<WebElement> patientLOSList = selUtility.findElements("patientLOS");
        for (int i = 0; i <= patientLOSList.size() - 1; i++)
        {
            // look for Patient LOS and ignore PACU LOS
            if ( patientLOSList.get(i).getAttribute("data-ng-bind-html").startsWith("patient.los") )
            {
                patientLOS = patientLOSList.get(i).getText();
                break;
            }
        }
        return patientLOS;

    }

}
