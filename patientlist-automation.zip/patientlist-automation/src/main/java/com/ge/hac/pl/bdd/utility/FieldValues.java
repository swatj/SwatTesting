/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class FieldValues
{
    private String FieldID;
    private String FirstRevID;
    private String ValueRefID;
    private String ElementKey;
    private String ValueTime;
    private String ValueType;
    private String StringValue;
    private String NumValue;
    private String DatetimeValue;
    private String BinaryValue;
    private String UnitID;
    private String ElementKeySize;
    private String CollectionID;
    private String LinkValue;
    private String DocumentLinkType;

    /**
     * 
     */
    public FieldValues()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param fieldID
     * @param firstRevID
     * @param valueRefID
     * @param elementKey
     * @param valueTime
     * @param valueType
     * @param stringValue
     * @param numValue
     * @param datetimeValue
     * @param binaryValue
     * @param unitID
     * @param elementKeySize
     * @param collectionID
     * @param linkValue
     * @param documentLinkType
     */
    public FieldValues(String fieldID, String firstRevID, String valueRefID, String elementKey, String valueTime,
            String valueType, String stringValue, String numValue, String datetimeValue, String binaryValue,
            String unitID, String elementKeySize, String collectionID, String linkValue, String documentLinkType)
    {
        super();
        FieldID = fieldID;
        FirstRevID = firstRevID;
        ValueRefID = valueRefID;
        ElementKey = elementKey;
        ValueTime = valueTime;
        ValueType = valueType;
        StringValue = stringValue;
        NumValue = numValue;
        DatetimeValue = datetimeValue;
        BinaryValue = binaryValue;
        UnitID = unitID;
        ElementKeySize = elementKeySize;
        CollectionID = collectionID;
        LinkValue = linkValue;
        DocumentLinkType = documentLinkType;
    }

    /**
     * @return the fieldID
     */
    public String getFieldID()
    {
        return this.FieldID;
    }

    /**
     * @param fieldID the fieldID to set
     */
    public void setFieldID(String fieldID)
    {
        FieldID = fieldID;
    }

    /**
     * @return the firstRevID
     */
    public String getFirstRevID()
    {
        return this.FirstRevID;
    }

    /**
     * @param firstRevID the firstRevID to set
     */
    public void setFirstRevID(String firstRevID)
    {
        FirstRevID = firstRevID;
    }

    /**
     * @return the valueRefID
     */
    public String getValueRefID()
    {
        return this.ValueRefID;
    }

    /**
     * @param valueRefID the valueRefID to set
     */
    public void setValueRefID(String valueRefID)
    {
        ValueRefID = valueRefID;
    }

    /**
     * @return the elementKey
     */
    public String getElementKey()
    {
        return this.ElementKey;
    }

    /**
     * @param elementKey the elementKey to set
     */
    public void setElementKey(String elementKey)
    {
        ElementKey = elementKey;
    }

    /**
     * @return the valueTime
     */
    public String getValueTime()
    {
        return this.ValueTime;
    }

    /**
     * @param valueTime the valueTime to set
     */
    public void setValueTime(String valueTime)
    {
        ValueTime = valueTime;
    }

    /**
     * @return the valueType
     */
    public String getValueType()
    {
        return this.ValueType;
    }

    /**
     * @param valueType the valueType to set
     */
    public void setValueType(String valueType)
    {
        ValueType = valueType;
    }

    /**
     * @return the stringValue
     */
    public String getStringValue()
    {
        return this.StringValue;
    }

    /**
     * @param stringValue the stringValue to set
     */
    public void setStringValue(String stringValue)
    {
        StringValue = stringValue;
    }

    /**
     * @return the numValue
     */
    public String getNumValue()
    {
        return this.NumValue;
    }

    /**
     * @param numValue the numValue to set
     */
    public void setNumValue(String numValue)
    {
        NumValue = numValue;
    }

    /**
     * @return the datetimeValue
     */
    public String getDatetimeValue()
    {
        return this.DatetimeValue;
    }

    /**
     * @param datetimeValue the datetimeValue to set
     */
    public void setDatetimeValue(String datetimeValue)
    {
        DatetimeValue = datetimeValue;
    }

    /**
     * @return the binaryValue
     */
    public String getBinaryValue()
    {
        return this.BinaryValue;
    }

    /**
     * @param binaryValue the binaryValue to set
     */
    public void setBinaryValue(String binaryValue)
    {
        BinaryValue = binaryValue;
    }

    /**
     * @return the unitID
     */
    public String getUnitID()
    {
        return this.UnitID;
    }

    /**
     * @param unitID the unitID to set
     */
    public void setUnitID(String unitID)
    {
        UnitID = unitID;
    }

    /**
     * @return the elementKeySize
     */
    public String getElementKeySize()
    {
        return this.ElementKeySize;
    }

    /**
     * @param elementKeySize the elementKeySize to set
     */
    public void setElementKeySize(String elementKeySize)
    {
        ElementKeySize = elementKeySize;
    }

    /**
     * @return the collectionID
     */
    public String getCollectionID()
    {
        return this.CollectionID;
    }

    /**
     * @param collectionID the collectionID to set
     */
    public void setCollectionID(String collectionID)
    {
        CollectionID = collectionID;
    }

    /**
     * @return the linkValue
     */
    public String getLinkValue()
    {
        return this.LinkValue;
    }

    /**
     * @param linkValue the linkValue to set
     */
    public void setLinkValue(String linkValue)
    {
        LinkValue = linkValue;
    }

    /**
     * @return the documentLinkType
     */
    public String getDocumentLinkType()
    {
        return this.DocumentLinkType;
    }

    /**
     * @param documentLinkType the documentLinkType to set
     */
    public void setDocumentLinkType(String documentLinkType)
    {
        DocumentLinkType = documentLinkType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "FieldValues [FieldID=" + FieldID + ", FirstRevID=" + FirstRevID + ", ValueRefID=" + ValueRefID
                + ", ElementKey=" + ElementKey + ", ValueTime=" + ValueTime + ", ValueType=" + ValueType
                + ", StringValue=" + StringValue + ", NumValue=" + NumValue + ", DatetimeValue=" + DatetimeValue
                + ", BinaryValue=" + BinaryValue + ", UnitID=" + UnitID + ", ElementKeySize=" + ElementKeySize
                + ", CollectionID=" + CollectionID + ", LinkValue=" + LinkValue + ", DocumentLinkType="
                + DocumentLinkType + "]";
    }

}
