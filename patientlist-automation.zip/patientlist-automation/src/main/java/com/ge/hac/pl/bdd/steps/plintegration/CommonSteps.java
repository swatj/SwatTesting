/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.UnreachableBrowserException;

import com.ge.hac.pl.bdd.functions.AboutBox;
import com.ge.hac.pl.bdd.functions.Column;
import com.ge.hac.pl.bdd.functions.DbAndServiceExecutor;
import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.GridPanel;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.functions.Popover;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.functions.Sorting;
import com.ge.hac.pl.bdd.functions.UpdateDate;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class CommonSteps
{
    private static final String String = null;
	private static Logger logger             = Logger.getLogger(CommonSteps.class);
    private String        DisableLoginButton = "true";

    @Given("that Patient list url is launched")
    public void loginToPatientList()
            throws IOException, Exception
    {

        /**
         * To Avoid the Certificate Error navigation screen while launching the
         * webpage in IE 11
         */

        String browserType = PropertyFileHelper.getProjectProperty("BrowserType");
        PatientList.getInstance().launchPatientListURL("url");
        if ( browserType.equals("IEExplorer") )
        {

            PatientList.getInstance().clicktoContinue();

        }

    }

    @Then("the user navigates to Patient List url")
    public void navigateToPatientListUrl()
            throws IOException, Exception
    {

        PatientList.getInstance().launchPatientListURL("url");
    }

    @When("the user navigates to Patient List <url>")
    public void launchPatientListUrl(@Named("url") String url)
            throws IOException, Exception
    {

        /**
         * To Avoid the Certificate Error navigation screen while launching the
         * webpage in IE 11
         */

        String browserType = PropertyFileHelper.getProjectProperty("BrowserType");
        if ( browserType.equals("IEExplorer") )
        {
            /** Launch the webpage */
            url = PropertyFileHelper.getProjectProperty("Url");
            PatientList.getInstance().openURL(url);
            PatientList.getInstance().clicktoContinue();

        }
        else
        {
            /** Launch the webpage */
            url = PropertyFileHelper.getProjectProperty("Url");
            PatientList.getInstance().openURL(url);
        }
    }

    // TODO
    @Given("that User is logged")
    public void checkHomePage()
            throws InterruptedException
    {
        PatientList.getInstance().checkHomePage();

    }

    @Then("the user enters <username> and <password>")
    public void EnterCredentials(@Named("username") String userName, @Named("password") String password)
            throws Exception
    {
        PatientList.getInstance().enterCredentials(userName, password);
    }

    @Then("the user clicks on Sign in to login")
    public void signIn(@Named("username") String userName, @Named("password") String password)
            throws Exception
    {
        PatientList.getInstance().clickOnlogin();
    }

    @Then("the user will not be able to click on Sign in button")
    public void disablesignIn(@Named("username") String userName, @Named("password") String password)
            throws Exception
    {
        String present = PatientList.getInstance().verifySigninButtonEnabled();

        Assert.assertEquals("Unable To click Sign in button, it is disabled", present, DisableLoginButton);
        logger.debug(
                "PatientList:verifySigninButtonEnabled: the user will not be able to click on Sign in button, as userid/password fields were empty");

    }

    @Then("Patient list displays <LoggedIn_UserName>")
    public void verifyLoggedinUserName(@Named("LoggedIn_UserName") String loggedIn_UserName)
            throws Exception
    {
        PatientList.getInstance().waitForElementToAppear("loggedinUserName", loggedIn_UserName, Constants.HIGH_TIMEOUT);
        String loggedInUserName = PatientList.getInstance().getloggedinUserName();
        Assert.assertEquals("The login is successfull ", loggedIn_UserName, loggedInUserName.trim());
        Thread.sleep(6000);
    }

    @When("Logout and re-login with $userName and $password")
    public void logoutReLogin(@Named("userName") String userName, @Named("password") String password)
            throws IOException, Exception
    {
        PatientList.getInstance().clickOnlogout();
        PatientList.getInstance().waitForElementToAppear("signin", Constants.SIGNIN_BUTTON_LABEL,
                Constants.HIGH_TIMEOUT);
        PatientList.getInstance().enterCredentials(userName, password);
        PatientList.getInstance().clickOnlogin();
        Thread.sleep(6000);
    }

    @Then("the user selects a <site> from the site dropdown")
    public void selectSite(@Named("site") String site)
            throws IOException, InterruptedException
    {
        boolean bStatus = Site.getInstance().verifyActiveSite(site);
        if ( !bStatus )
        {
            Site.getInstance().clickAddSite();
            bStatus = Site.getInstance().AddSite(site);
            Thread.sleep(6000);
            PatientList.getInstance().waitForElementToAppear("add_site", site, Constants.HIGH_TIMEOUT);
        }

        bStatus = Site.getInstance().verifyActiveSite(site);
        Assert.assertEquals("select Site From Add Site dropdown = " + site, true, bStatus);
    }

    @When("the user selects a <site> from the site dropdown")
    public void chooseSite(@Named("site") String site)
            throws IOException, InterruptedException
    {
        boolean bStatus = Site.getInstance().verifyActiveSite(site);
        if ( !bStatus )
        {
            Site.getInstance().clickAddSite();
            bStatus = Site.getInstance().AddSite(site);
            Thread.sleep(6000);
            PatientList.getInstance().waitForElementToAppear("add_site", site, Constants.HIGH_TIMEOUT);
        }
        bStatus = Site.getInstance().verifyActiveSite(site);
        Assert.assertEquals("select Site From Add Site dropdown = " + site, true, bStatus);
    }

    @Then("the user clicks logout to log out from application")
    public void logout()
            throws Exception
    {
        PatientList.getInstance().clickOnlogout();
    }

    @Then("the user connects to the DB and executes <delete> <update> query on the table <table> and verifies updated <columnName> in the DB")
    public void ConnectDBndUpdate(@Named("table") String table, @Named("delete") String delete,
            @Named("update") String update, @Named("columnName") String columnName)
                    throws IOException, InterruptedException, ClassNotFoundException, SQLException
    {

        DbAndServiceExecutor.dbchanges(table, delete, update, columnName);

    }

    @Then("restart the server")
    public void RestartServer()
            throws IOException, InterruptedException, ClassNotFoundException, SQLException
    {

        DbAndServiceExecutor.RemoteC();

    }

    @Then("the user is able to view the Patient List grid")
    public void verifyPatientListGridDisplayed()
            throws IOException

    {
        boolean gridDisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("datagrid");
        Assert.assertEquals("user is able to view the Patient List grid", true, gridDisplayed);
    }

    @Then("the Patient List will display data for the selected date range")
    public void verifyCurrentViewData(@Named("Care phase") String carePhaseValue, @Named("OR") String ORValue,
            @Named("Patient ID") String patientIDValue, @Named("Patient") String patientValue,
            @Named("Sched time") String schedTimeValue)
                    throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        headerNames.add(Constants.OR_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            PatientListData.getInstance().verifyOR(patientIDRowNumber, headerNames, ORValue);
            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
            PatientListData.getInstance().verifyCarePhase(patientIDRowNumber, headerNames, carePhaseValue);
            PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);
        }
    }

    @Then("the Patient List will not display data for the selected date range")
    public void verifyCurrentViewDataNotDisplayed(@Named("Care phase") String carePhaseValue,
            @Named("OR") String ORValue, @Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("Sched time") String schedTimeValue)
                    throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        headerNames.add(Constants.OR_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        Assert.assertTrue("Verify that patient details not displayed for patient id =" + patientIDValue,
                patientIDRowNumber == 0);

    }

    @Then("department protected flag set to false")
    public void setDepartmentProtectedFlagTofalse()
            throws IOException, ConfigurationException
    {
        String security_properties_path = PropertyFileHelper.getProjectProperty("security_properties_path");
        PropertiesConfiguration config = new PropertiesConfiguration(security_properties_path);
        System.out.println(config.getProperty("DepartmentProtected"));
        String DepartmentProtected = (String) config.getProperty("DepartmentProtected");

        if ( "true".equalsIgnoreCase(DepartmentProtected) )
        {
            config.setProperty("DepartmentProtected", "FALSE");

            config.save();
            System.out.println(config.getProperty("DepartmentProtected"));
            DbAndServiceExecutor.RemoteC();
        }
    }

    @Then("department protected flag set to true")
    public void setDepartmentProtectedFlagTotrue()
            throws IOException, ConfigurationException
    {
        String security_properties_path = PropertyFileHelper.getProjectProperty("security_properties_path");
        PropertiesConfiguration config = new PropertiesConfiguration(security_properties_path);
        System.out.println(config.getProperty("DepartmentProtected"));
        String DepartmentProtected = (String) config.getProperty("DepartmentProtected");

        if ( "false".equalsIgnoreCase(DepartmentProtected) )
        {
            config.setProperty("DepartmentProtected", "TRUE");
            config.save();
            System.out.println(config.getProperty("DepartmentProtected"));
            DbAndServiceExecutor.RemoteC();
        }
    }

    @Then("Verify that patient list should display data as per new configuration")
    public void verifyDataAfterNewConfiguration(@Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("Sched time") String schedTimeValue,
            @Named("Surgeon") String Surgeon)
                    throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        headerNames.add(Constants.SURGEON_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {

            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
            PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);
            PatientListData.getInstance().verifySurgeon(patientIDRowNumber, headerNames, Surgeon);
        }
    }

    @Then("Verify that patient list should not display completed cases")
    public void verifyCompletedCasesNotDisplayed(@Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        Assert.assertTrue("Verify that patient details not displayed for completed patient id =" + patientIDValue,
                patientIDRowNumber == 0);

    }

    @Then("the Patient List will display patient ID for selected date range")
    public void verifyCurrentViewData1(@Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
    }

    @Then("the Patient List will not display patient ID for selected date range")
    public void verifyCurrentViewData2(@Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( !(patientIDRowNumber == 0) )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
    }

    @Then("the user changes  following properties to new values and restart the application server:$datatable")
    public void setProperty(ExamplesTable datatable)
            throws IOException, ConfigurationException
    {
        String patient_list_properties_filepath = PropertyFileHelper
                .getProjectProperty("patient-list_properties_filepath");
        PropertiesConfiguration config = new PropertiesConfiguration(patient_list_properties_filepath);
        List<Map<String, String>> dtRows = datatable.getRows();

        for (Map<String, String> row : dtRows)
        {

            String propertyname = row.get("propertyname");
            String propertyvalue = row.get("propertyvalue");
            System.out.println("Before =property value for " + propertyname + " in patient-list.properties = "
                    + config.getProperty(propertyname));
            config.setProperty(propertyname, propertyvalue);

            config.save();
            System.out.println("After =property value for " + propertyname + " in patient-list.properties = "
                    + config.getProperty(propertyname));
        }
        DbAndServiceExecutor.RemoteC();

    }

    @Then("the last viewed department is selected")
    public void lastViewedDepartment(@Named("activeDepartment") String activeDepartment)
            throws IOException, InterruptedException
    {
        boolean actualActiveDepartment = Site.getInstance().verifyActiveDepartment(activeDepartment);
        Assert.assertEquals("Verify active department on department tab :" + activeDepartment + " expected=true"
                + " actual =" + actualActiveDepartment, true, actualActiveDepartment);
    }

    @Given("the user selects <site>, <department> and sets the fromdate to blank and gets date error <message>")
    public void produceDateErrorMessage(@Named("site") String site, @Named("department") String department,
            @Named("message") String message)
                    throws Exception
    {
        boolean bStatus = Site.getInstance().verifyActiveSite(site);
        if ( !bStatus )
        {
            Site.getInstance().clickAddSite();
            bStatus = Site.getInstance().AddSite(site);
            PatientList.getInstance().waitForElementToAppear("add_site", site, Constants.HIGH_TIMEOUT);
        }

        bStatus = Site.getInstance().verifyActiveSite(site);
        Assert.assertEquals("select Site From Add Site dropdown = " + site, true, bStatus);
        Site.getInstance().selectDepartment(department);
        PatientList.getInstance().setDateCalender("from", "blank");
        String errorMsg = PatientList.getInstance().getDateErrorMessage(message);

        Assert.assertEquals("Verify the error message for invalid date", errorMsg, message);
    }

    @Then("date error message should disappear")
    public void verifyDateErrorMessageDisappears(@Named("message") String message)
            throws UnreachableBrowserException, WebDriverException, IOException, InterruptedException
    {

        //boolean berrorMsgDisplayed = SeleniumUtility.getInstance().getElementByXPath("warningMessage").isDisplayed();
        boolean berrorMsgDisplayed = SeleniumUtility.getInstance().iSelementPresentXpath("warningMessage");
        Assert.assertEquals("Date Error message was disappeared", false, berrorMsgDisplayed);
        
    }

    @AfterStory
    public void AfterStory()
            throws Exception
    {
        PatientList.getInstance().closePatientListBrowser();
        PatientList.closeInstance();
        AboutBox.closeInstance();
        GridPanel.closeInstance();
        Sorting.closeInstance();
        Site.closeInstance();
        Column.closeInstance();
        PatientListData.closeInstance();
        Filter.closeInstance();
        Popover.closeInstance();
        UpdateDate.closeInstance();
        Sorting.closeInstance();
        AboutBox.closeInstance();
        SeleniumUtility.closeInstance();

    }

    @BeforeStory
    public void BeforeStory()
            throws Exception
    {
        clearBrowserCache();
        boolean isBrowerOpend = openBrowser();
        int numOfAttempt = 5;
        int alreadyAttempted = 0;
        while (alreadyAttempted <= numOfAttempt)
        {
            if ( !isBrowerOpend )
            {
                alreadyAttempted++;
                isBrowerOpend = openBrowser();
            }
            else
            {
                break;
            }
        }
    }

    @SuppressWarnings("finally")
    public boolean openBrowser()
    {
        boolean isBrowerOpend = false;
        try
        {
            SeleniumUtility.getInstance();
            isBrowerOpend = true;
        }
        catch (org.openqa.selenium.remote.UnreachableBrowserException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.steps.plintegration.CommonSteps.openBrowser()", e);
            isBrowerOpend = false;
        }
        catch (org.openqa.selenium.WebDriverException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.steps.plintegration.CommonSteps.openBrowser()", e);
            isBrowerOpend = false;
        }
        finally
        {
            return isBrowerOpend;
        }
    }

    public void clearBrowserCache()
    {
        try
        {
            SeleniumUtility.getInstance().deleteBrowserAllCookies();
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.steps.plintegration.CommonSteps.clearBrowserCache()", e);
        }
    }

}
