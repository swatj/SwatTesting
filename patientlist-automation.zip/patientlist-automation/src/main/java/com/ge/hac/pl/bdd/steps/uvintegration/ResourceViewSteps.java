package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;
import java.util.Map;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.ArrivingListCard;
import com.ge.hac.pl.bdd.functions.Card;
import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PopoverCard;
import com.ge.hac.pl.bdd.functions.ResourceView;
import com.ge.hac.pl.bdd.functions.SidePanel;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class ResourceViewSteps
{
    @Then("the user is able to view the unit view")
    public void VerifyThatUnitViewIsDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that Resource view was displayed.", true, ResourceView.isResourceViewDisplayed());
    }

    @When("the user switches <view>")
    @Then("the user switches <view>")
    public void switchToView(@Named("view") String viewName)
            throws IOException
    {
        switchView(viewName);
    }

    @When("the user switches <listView>")
    public void switchToListView(@Named("listView") String viewName)
            throws IOException
    {
        switchView(viewName);
    }

    private void switchView(String viewName)
            throws IOException
    {
        if ( Constants.UNIT_VIEW_NAME.equalsIgnoreCase(viewName) )
        {
            // check that unit view is not displayed then click on toggle button
            if ( Constants.RESOURCE_VIEW_ICON.equalsIgnoreCase(Site.getInstance().geToggleViewButtonIconName()) )
            {
                Site.getInstance().clickOnToggleViewButton();
            }
        }
        else if ( Constants.PATIENTLIST_VIEW_NAME.equalsIgnoreCase(viewName) )
        {
            // check that patient list is not displayed then click on toggle button
            if ( Constants.PATIENTLIST_VIEW_ICON.equalsIgnoreCase(Site.getInstance().geToggleViewButtonIconName()) )
                if ( Constants.PATIENTLIST_VIEW_ICON.equalsIgnoreCase(Site.getInstance().geToggleViewButtonIconName()) )
                    if ( Constants.PATIENTLIST_VIEW_ICON
                            .equalsIgnoreCase(Site.getInstance().geToggleViewButtonIconName()) )
                    {
                    {
                    Site.getInstance().clickOnToggleViewButton();
                    }
                    }
        }
    }

    @Then("message should displayed indicating layout is not configured")
    public void verifyBedLayoutNotConfiguredErrorMessage()
            throws Exception
    {
        String actErrorMsg = ResourceView.getBedLayoutNotConfiguredErrorMessage();
        Assert.assertTrue(
                "Verify the error message for missing bed layout configuration" + " expected="
                        + Constants.BED_LAYOUT_MISSING + " actual=" + actErrorMsg,
                Constants.BED_LAYOUT_MISSING.equalsIgnoreCase(actErrorMsg));
    }

    @Then("bed layout should be blank")
    public void verifyBlankBedLayout()
            throws Exception
    {
        boolean bedlayoutdisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("BedLayoutDisplay");
        Assert.assertEquals("bed layout should be blank", false, bedlayoutdisplayed);

    }

    @Then("Layout has not been configured for this department message should not display")
    public void verifyErrorMessageNotDisplayed()
            throws Exception
    {

        boolean berrorMsgDisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("warningMessage");
        Assert.assertEquals("Bed Layout Configuration Error message was disappeared", false, berrorMsgDisplayed);
    }

    @Then("Ellipsis button to navigate to documentation should not display on card at right bottom corner")
    public void verifyPopupDisabled(@Named("rowno") int RowNumber, @Named("colno") int ColNumber)
            throws Exception
    {
        Card card = new Card(RowNumber, ColNumber);

        boolean popupDisplayed = card.isEllipsisButton();
        Assert.assertEquals(
                "Ellipsis button to navigate to documentation should not display on card at right bottom corner", false,
                popupDisplayed);

    }

    @Then("Ellipsis button to navigate to documentation should not display on arriving card at right bottom corner")
    public void verifyArrivingListPopupDisabled()
            throws Exception
    {
        ArrivingListCard card = new ArrivingListCard(1);
        boolean popupDisplayed = card.isEllipsisButton();
        Assert.assertEquals(
                "Ellipsis button to navigate to documentation should not display on card at right bottom corner", false,
                popupDisplayed);
    }

    @Then("staff on card should display in order as Surgeon, anesthesiologist, PACU Nurse with pipe separator")
    public void verifyStaffOrderOnBed(@Named("rowno") int RowNumber, @Named("colno") int ColNumber,
            @Named("staff") String expStaff)
    {
        Card card = new Card(RowNumber, ColNumber);
        expStaff = expStaff.replace(",", "|");
        String actStaff = card.getAllStaff();
        Assert.assertTrue(
                "staff on card should display in order as Surgeon, anesthesiologist, PACU Nurse with pipe separator"
                        + " expected=" + expStaff + " ,actual=" + actStaff,
                expStaff.equalsIgnoreCase(actStaff));
    }

    @Then("staff on card should display in order as Surgeon, ICU Nurse and Intesivist with pipe separator")
    public void verifyStaffOrderOnICUBed(@Named("rowno") int RowNumber, @Named("colno") int ColNumber,
            @Named("staff") String expStaff)
    {
        Card card = new Card(RowNumber, ColNumber);
        expStaff = expStaff.replace(",", "|");
        String actStaff = card.getAllStaff();
        Assert.assertTrue(
                "staff on card should display in order as Surgeon, ICU Nurse and Intesivist with pipe separator"
                        + " expected=" + expStaff + " ,actual=" + actStaff,
                expStaff.equalsIgnoreCase(actStaff));
    }

    @Then("staff on arriving card should display in order as Surgeon, anesthesiologist with pipe separator")
    public void verifyStaffOrderOnArrivingCard(@Named("position") int position, @Named("staff") String expStaff,
            @Named("patientid") String patientid)
            throws IOException, InterruptedException
    {
        Filter.getInstance().setArrivingListFilter(patientid);
        ArrivingListCard card = new ArrivingListCard(position);
        expStaff = expStaff.replace(",", "|");
        String actStaff = card.getAllStaff();
        Assert.assertTrue(
                "staff on arriving card should display in order as Surgeon, anesthesiologist, PACU Nurse with pipe separator"
                        + " expected=" + expStaff + " ,actual=" + actStaff,
                expStaff.equalsIgnoreCase(actStaff));
    }

    @Then("arriving list should displayed")
    public void verifyArrivinglistDisplayed()
            throws IOException
    {
        Assert.assertEquals("on right hand side of bed layout, side panel should display by default in expanded mode.",
                true, SidePanel.isSidePanelExpanded());
    }

    @Then("patient data should display on icu bed")
    public void VerifyICUBedData(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String Bedname, @Named("patientid") String Patientid,
            @Named("patientname") String Patientname, @Named("dob") String Dob, @Named("age") String Age,
            @Named("staff") String Staff, @Named("isolation") boolean Isolation, @Named("gender") String Gender,
            @Named("admissionreason") String Admissionreason, @Named("similarname") boolean Similarname,
            @Named("procedure") String Procedure)
            throws IOException
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actBedname = Bed.getBedName();
        String actPatientid = Bed.getPatientId();
        String actPatientname = Bed.getPatientName();
        String actDob = Bed.getDateOfBirth();
        String actAge = Bed.getAge();
        String actStaff = Bed.getAllStaff();
        boolean actIsolation = Bed.isPatientIsolated();
        String actGender = Bed.getGender();
        String actAdmissionreason = Bed.getAdmissionReason();
        boolean actSimilarname = Bed.isPatientSimilar();
        String actProcedure = Bed.getProcedure();
        Assert.assertTrue("Verify bed name on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Bedname + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Patientid + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Patientname + "; actual=" + actPatientname,
                actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue("Verify Dob on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + Dob
                + "; actual=" + actDob, actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + Age
                + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue(
                "Verify Staff on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                        + Staff.replace(",", "|") + "; actual=" + actStaff,
                actStaff.equalsIgnoreCase(Staff.replace(",", "|")));
        Assert.assertTrue("Verify Isolation icon on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Isolation + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Gender + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue(
                "Verify Admission reason on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                        + Admissionreason + "; actual=" + actAdmissionreason,
                actAdmissionreason.equalsIgnoreCase(Admissionreason));
        Assert.assertTrue("Verify Similar name icon on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Procedure + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));
    }

    @Then("patient data should display on pacu bed")
    public void VerifyPACUBedData(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String Bedname, @Named("patientid") String Patientid,
            @Named("patientname") String Patientname, @Named("dob") String Dob, @Named("age") String Age,
            @Named("staff") String Staff, @Named("isolation") boolean Isolation, @Named("gender") String Gender,
            @Named("similarname") boolean Similarname, @Named("procedure") String Procedure)
            throws IOException
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actBedname = Bed.getBedName();
        String actPatientid = Bed.getPatientId();
        String actPatientname = Bed.getPatientName();
        String actDob = Bed.getDateOfBirth();
        String actAge = Bed.getAge();
        String actStaff = Bed.getAllStaff();
        boolean actIsolation = Bed.isPatientIsolated();
        String actGender = Bed.getGender();
        boolean actSimilarname = Bed.isPatientSimilar();
        String actProcedure = Bed.getProcedure();
        Assert.assertTrue("Verify bed name on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Bedname + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Patientid + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Patientname + "; actual=" + actPatientname,
                actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue("Verify Dob on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + Dob
                + "; actual=" + actDob, actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + Age
                + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue(
                "Verify Staff on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                        + Staff.replace(",", "|") + "; actual=" + actStaff,
                actStaff.equalsIgnoreCase(Staff.replace(",", "|")));
        Assert.assertTrue("Verify Isolation icon on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Isolation + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Gender + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue("Verify Similar name icon on card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Procedure + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));

    }

    @Then("patient data should display on icu arriving list")
    public void VerifyICUArrivingData(@Named("position") int Position, @Named("bedname") String Bedname,
            @Named("patientid") String Patientid, @Named("patientname") String Patientname, @Named("dob") String Dob,
            @Named("age") String Age, @Named("staff") String Staff, @Named("isolation") boolean Isolation,
            @Named("gender") String Gender, @Named("admissionreason") String Admissionreason,
            @Named("similarname") boolean Similarname, @Named("procedure") String Procedure,
            @Named("lasttimeevent") String LastTimeEvent)
            throws IOException
    {
        ArrivingListCard ArrivingListCard = new ArrivingListCard(Position);
        String actBedname = ArrivingListCard.getBedName();
        String actPatientid = ArrivingListCard.getPatientId();
        String actPatientname = ArrivingListCard.getPatientName();
        String actDob = ArrivingListCard.getDateOfBirth();
        String actAge = ArrivingListCard.getAge();
        String actStaff = ArrivingListCard.getAllStaff();
        boolean actIsolation = ArrivingListCard.isPatientIsolated();
        String actGender = ArrivingListCard.getGender();
        boolean actSimilarname = ArrivingListCard.isPatientSimilar();
        String actProcedure = ArrivingListCard.getProcedure();
        String actAdmissionreason = ArrivingListCard.getAdmissionReason();
        String actLastTimeEvent = ArrivingListCard.getLastTimeEvent();
        Assert.assertTrue("Verify bed name on ICU arriving list at position =" + Position + " expected=" + Bedname
                + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on ICU arriving list at position =" + Position + " expected=" + Patientid
                + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on ICU arriving list at position =" + Position + " expected="
                + Patientname + "; actual=" + actPatientname, actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue(
                "Verify Dob on ICU arriving list at position =" + Position + " expected=" + Dob + "; actual=" + actDob,
                actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on on ICU arriving list at position =" + Position + " expected=" + Age
                + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Staff on ICU arriving list at position =" + Position + " expected="
                + Staff.replace(",", "|") + "; actual=" + actStaff, actStaff.equalsIgnoreCase(Staff.replace(",", "|")));
        Assert.assertTrue(
                "Verify Isolation icon on card at =" + Position + " expected=" + Isolation + "; actual=" + actIsolation,
                actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on ICU arriving list at position =" + Position + " expected=" + Gender
                + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue("Verify Similar name icon on ICU arriving list at position =" + Position + " expected="
                + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on ICU arriving list at position" + Position + " expected=" + Procedure
                + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue("Verify Admission reason on ICU arriving list at position =" + Position + " expected="
                + Admissionreason + "; actual=" + actAdmissionreason,
                actAdmissionreason.equalsIgnoreCase(Admissionreason));
        Assert.assertTrue("Verify Last Time Event on ICU arriving list at position =" + Position + " expected="
                + LastTimeEvent + "; actual=" + actLastTimeEvent, actLastTimeEvent.contains(LastTimeEvent));
    }

    @Then("patient data should display on pacu arriving list")
    public void VerifyPACUArrivingData(@Named("position") int Position, @Named("bedname") String Bedname,
            @Named("patientid") String Patientid, @Named("patientname") String Patientname, @Named("dob") String Dob,
            @Named("age") String Age, @Named("staff") String Staff, @Named("isolation") boolean Isolation,
            @Named("gender") String Gender, @Named("similarname") boolean Similarname,
            @Named("procedure") String Procedure, @Named("lasttimeevent") String LastTimeEvent)
            throws IOException
    {
        ArrivingListCard ArrivingListCard = new ArrivingListCard(Position);
        String actBedname = ArrivingListCard.getBedName();
        String actPatientid = ArrivingListCard.getPatientId();
        String actPatientname = ArrivingListCard.getPatientName();
        String actDob = ArrivingListCard.getDateOfBirth();
        String actAge = ArrivingListCard.getAge();
        String actStaff = ArrivingListCard.getAllStaff();
        boolean actIsolation = ArrivingListCard.isPatientIsolated();
        String actGender = ArrivingListCard.getGender();
        boolean actSimilarname = ArrivingListCard.isPatientSimilar();
        String actProcedure = ArrivingListCard.getProcedure();
        String actLastTimeEvent = ArrivingListCard.getLastTimeEvent();
        Assert.assertTrue("Verify bed name on PACU arriving list at position =" + Position + " expected=" + Bedname
                + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on PACU arriving list at position =" + Position + " expected=" + Patientid
                + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on PACU arriving list at position =" + Position + " expected="
                + Patientname + "; actual=" + actPatientname, actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue(
                "Verify Dob on PACU arriving list at position =" + Position + " expected=" + Dob + "; actual=" + actDob,
                actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on on PACU arriving list at position =" + Position + " expected=" + Age
                + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Staff on PACU arriving list at position =" + Position + " expected="
                + Staff.replace(",", "|") + "; actual=" + actStaff, actStaff.equalsIgnoreCase(Staff.replace(",", "|")));
        Assert.assertTrue(
                "Verify Isolation icon on card at =" + Position + " expected=" + Isolation + "; actual=" + actIsolation,
                actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on PACU arriving list at position =" + Position + " expected=" + Gender
                + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue("Verify Similar name icon on PACU arriving list at position =" + Position + " expected="
                + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on PACU arriving list at position=" + Position + " expected=" + Procedure
                + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue("Verify Last Time Event   on ICU arriving list at position =" + Position + " expected="
                + LastTimeEvent + "; actual=" + actLastTimeEvent, actLastTimeEvent.contains(LastTimeEvent));
    }

    @When("user clicks on bed")
    public void clickOnPopoverButton(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
            throws Exception
    {
        Card card = new Card(RowNumber, ColumnNumber);
        card.clickOnCard();

    }

    @When("user clicks on arriving list card")
    public void arrivingListCardPopoverClick(@Named("Position") int Position)
            throws Exception
    {
        Thread.sleep(2000);
        ArrivingListCard card = new ArrivingListCard(Position);
        card.clickOnCard();

    }

    @Then("the user search for the case in Bed Layout")
    public void bedCardPatientId(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("patientid") String Patientid)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actPatientid = Bed.getPatientId();
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Patientid + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
    }

    @Then("the user verifies staff's data in PACU Bed card")
    public void bedPACUStaffDetails(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("Anestheologist") String Anestheologist, @Named("Surgeon") String Surgeon,
            @Named("PACU RN") String PACURN)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actAnestheologist = Bed.getAnesthesiologists();
        String actSurgeon = Bed.getSurgeon();
        String actPacuNurse = Bed.getPacuNurse();
        Assert.assertTrue(
                "Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                        + Anestheologist + "; actual=" + actAnestheologist,
                actAnestheologist.equalsIgnoreCase(Anestheologist));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Surgeon + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + PACURN + "; actual=" + actPacuNurse, actPacuNurse.equalsIgnoreCase(PACURN));
    }

    @Then("the user verifies staff's data in ICU Bed card")
    public void bedICUStaffDetails(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("Intensivists") String Intensivists, @Named("Surgeon") String Surgeon,
            @Named("ICUNurse") String ICUNurse)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actSurgeon = Bed.getSurgeon();
        String actIntensivists = Bed.getIntensivists();
        String actICUNurse = Bed.getIcuNurse();
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Intensivists + "; actual=" + actIntensivists, actIntensivists.equalsIgnoreCase(Intensivists));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Surgeon + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue("Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + ICUNurse + "; actual=" + actICUNurse, actICUNurse.equalsIgnoreCase(ICUNurse));
    }

    @Then("the user verifies procedure data in ICU Bed card")
    public void bedProcedureDetails(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("SurgicalProcedure") String SurgicalProcedure)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        String actSurgicalProcedure = Bed.getProcedure();
        Assert.assertTrue(
                "Verify Patientid on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                        + SurgicalProcedure + "; actual=" + actSurgicalProcedure,
                actSurgicalProcedure.equalsIgnoreCase(SurgicalProcedure));
    }

    @Then("Bed conflict indication should be display")
    public void bedConflictExists(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        Assert.assertEquals("Verify that Bed conflict indication should be display", true, Bed.isBedConflicts());

    }

    @Then("Bed conflict indication should not display")
    public void bedConflictNotExists(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);
        Assert.assertEquals("Verify that Bed conflict indication should not display", false, Bed.isBedConflicts());

    }

    @Then("popover should display with all conflict patients data on bed: $dataTable")
    public void verifyConflictcases(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        // verify message
        PopoverCard BedPopOver = new PopoverCard();
        Assert.assertEquals("Verify that Bed conflict message in popover", Constants.BED_CONFLICT_MESSAGE_IN_POPOVER,
                BedPopOver.getBedConfictMessage());
        // verify headers
        Assert.assertEquals("Verify conflict cases table headers", Constants.BED_CONFLICT_TABLE_HEADERS_IN_POPOVER,
                BedPopOver.getBedConfictTableHeaders());
        // verify case detials

        int dataRowIndex = 0;

        String[][] conflictCaseData = BedPopOver.getBedConfictCaseData();
        for (Map<String, String> row : dataTable.getRows())
        {
            int dataColIndex = 0;
            String Patient_Name = row.get("patient_name");
            String Patient_ID = row.get("patient_id");
            Assert.assertEquals("Verify that conflict case patient name at position=" + dataRowIndex, Patient_Name,
                    conflictCaseData[dataRowIndex][dataColIndex]);
            Assert.assertEquals("Verify that conflict case patient id at position=" + dataRowIndex, Patient_ID,
                    conflictCaseData[dataRowIndex][dataColIndex + 1]);
            dataRowIndex++;
        }

    }

    @When("user switch to resource view and back to patient list view")
    public void toggleView()
            throws IOException
    {
        switchView(Constants.UNIT_VIEW_NAME);
        switchView(Constants.PATIENTLIST_VIEW_NAME);
    }
}
