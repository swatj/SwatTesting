/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     30-Mar-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class AboutBoxHelper
{
    private static Logger          LOGGER     = Logger.getLogger(AboutBoxHelper.class);

    private static SeleniumUtility selUtility = SeleniumUtility.getInstance();          ;

    // function is used to click on logged in user name button
    
    /**
     * 
     * @throws IOException
     */
    public static void clickOnLoggedInUserName()
            throws IOException
    {
        selUtility.elementClick("loggedinUserName");
        LOGGER.debug("About:clickloggedinUserName: click on loggedinUserName");
    }

    // returns text of about link
    public static String getAboutText()
            throws IOException
    {
        String aboutText = selUtility.getElementByXPath("aboutPL").getText().trim();
        LOGGER.debug("About:getAboutText: get the about text");
        return aboutText;
    }

    // returns text of about link
    public static String getProductName()
            throws IOException
    {
        String aboutText = selUtility.getElementByXPath("productName").getText().trim();
        LOGGER.debug("About:getProductName: get the product name");
        return aboutText;
    }

    // click on about link
    public static void clickAboutLink()
            throws IOException
    {
        selUtility.elementClick("aboutPL");
        LOGGER.debug("About:clickAboutLink: click on About link");
    }

    // verify about dialog box is displayed or not
    // returns hidden property=true if abot box is not displayed and false if box is displayed
    public static String verifyAboutDialogDisplay()
            throws IOException, InterruptedException
    {
        WebElement aboutDialog = selUtility.getElementByXPath("aboutDialog");
        return aboutDialog.getAttribute("aria-hidden");

    }

    // return software version
    public static String getSoftwareVersion()
            throws IOException
    {
        return selUtility.get_text("PLversion");
    }

    // return CA version
    public static String getCAVersion()
            throws IOException
    {
        return selUtility.get_text("CArelease");
    }

    // return GE image
    public static String getGELogoImagePath()
            throws IOException
    {
        return selUtility.getElementByXPath("aboutDialogImage").getAttribute("src");
    }

    // return manufacturer address
    public static String getManufacturerAddress()
            throws IOException
    {
        return selUtility.get_text("address1");
    }

    // return EuropeanAddress address
    public static String getEuropeanAddress()
            throws IOException
    {
        return selUtility.get_text("address2");
    }

    // return AsiaHeadquarterAddress address
    public static String getAsiaHeadquarterAddress()
            throws IOException
    {
        return selUtility.get_text("address3");
    }

    // close about dialog box
    public static void closeAboutDialog()
            throws IOException
    {
        selUtility.elementClick("closeAboutBox");
    }
}
