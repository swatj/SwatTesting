package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.util.Arrays;

import javax.ws.rs.core.Response;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.ge.hac.ca.web.resourceview.model.UnitViewData;
import com.ge.hac.ca.bdd.common.CAHelper;
import com.ge.hac.ca.common.objectmapping.PolymorphicDtoMixIn;
import com.ge.hac.ca.common.objectmapping.PolymorphicEntityChangeMixIn;
import com.ge.hac.common.ea.dto.DataTransferObject;
import com.ge.hac.common.ea.dto.configuration.DepartmentLayoutConfiguration;
import com.ge.hac.common.ea.dto.reference.hospital.Department;
import com.ge.hac.common.ea.dto.reference.hospital.Hospital;
import com.ge.hac.common.ea.synchronization.DataChange;


public class ServiceTesting {
	String entity = null;
// To Get the Build Number
	public void BuildGetService() {
		System.setProperty(javax.naming.Context.PROVIDER_URL,
				"remote://localhost:4899");
		Response res = CAHelper
				.httpGet("/service/configuration/version/implementation?metainfpath=/deployments/hac-ca.ear/META-INF/&manifestfilename=MANIFEST.MF");
		System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
	}
//To Get the Configurator Details
	public void GetDepartmentLayout() throws JsonParseException,
			JsonMappingException, IOException {
		System.setProperty(javax.naming.Context.PROVIDER_URL,
				"remote://localhost:4899");
		Response res = CAHelper.httpGet("/service/configuration/rv/layout");
		System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
		ObjectMapper mapper = getMapperObject();
		DepartmentLayoutConfiguration d = mapper.readValue(stringResponse,
				DepartmentLayoutConfiguration.class);
		System.out.println(d.getDeptLayout().get(0).getRooms().get(0).getBeds().get(0).getId());
		System.out.println(d.getDeptLayout().get(0).getRooms().get(0).getBeds().get(0).getCol());
		System.out.println(d.getDeptLayout().get(0).getRooms().get(0).getBeds().get(0).getRow());
		System.out.println(d.getDeptLayout().get(0).getRooms().get(0).getId());
		
		if (d.getDeptLayout().get(0).getRooms().get(0).getId().equals("5300000000000900M0")) {
			System.out.println("Bed Name is Similar---Passed");
		} else {
			System.out.println("Bed Name is Different---Failed");
		}

	}
// To Get the Sites(Hospital)
	public void GetServiceLocation() throws Exception {
		System.setProperty(javax.naming.Context.PROVIDER_URL,
				"remote://localhost:4899");
		Response res = CAHelper.httpGet("service/location/user/hospital");
		System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
		ObjectMapper mapper = getMapperObject();
		Hospital[] hospital = mapper.readValue(stringResponse, Hospital[].class);
		java.util.List<Hospital> hospitalList = Arrays.asList(hospital);
        String actHospitals = "";
        // get all hospital
        for (Hospital eachHospital : hospitalList)
        {
            actHospitals = actHospitals + "," + eachHospital.getName();
            System.out.println(eachHospital.getName());
        }
	
	}
	//Get ICU Patients arrriving List
	public void GetServiceICUArrived() throws Exception {
		System.setProperty(javax.naming.Context.PROVIDER_URL,
				"remote://localhost:4899");
		Response res = CAHelper.httpGet("service/rv/1QH000I/arriving");
				System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
		ObjectMapper mapper = getMapperObject();
		UnitViewData d = mapper.readValue(stringResponse, UnitViewData.class);
		int Size=d.getArrivingList().size();
		//To Get all Arriving list patient name and Sex
		for(int i=0;i<Size;i++)
		{
			d.getArrivingList();
			System.out.println(+i+" Arriving Patient's FName : "+d.getArrivingList().get(i).getPatient().getFirstname());
			System.out.println(+i+" Arriving Patient's Sex : "+d.getArrivingList().get(i).getPatient().getGender());
			System.out.println(+i+" Arriving Patient's LName : "+d.getArrivingList().get(i).getPatient().getLastname());
		}

	}
	//Get Departments details
	public void GetServiceDepartment() throws Exception {
		System.setProperty(javax.naming.Context.PROVIDER_URL,
				"remote://localhost:4899");
		Response res = CAHelper.httpGet("service/location/departments");
				System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
		ObjectMapper mapper = getMapperObject();
		Department[] department = mapper.readValue(stringResponse, Department[].class);
		java.util.List<Department> departmentList = Arrays.asList(department);
        String actDepartments = "";
        // get all Departments
        for (Department eachDepartment : departmentList)
        {
        	actDepartments = actDepartments + "," + eachDepartment.getName();
            System.out.println(eachDepartment.getName());
        }

	}
// To Post Configurator Service
	public void PostService() throws JsonParseException, JsonMappingException,
			IOException {
		System.setProperty(javax.naming.Context.PROVIDER_URL,"remote://localhost:4899");
		String jo = "{\"deptLayout\":[{\"name\":\"NewDepartment\",\"frid\":\"1234000000000003007P\",\"rows\":\"4\",\"columns\":\"4\",\"bedData\":[{\"frid\":\"1234000000000003007M\",\"name\":\"NewBed\",\"roomFrid\":\"1234000000000003007O\",\"roomName\":\"NewRoom\",\"rowPos\":\"20\",\"colPos\":\"20\"}]}],\"derivedFrom\":1}";
		Response res = CAHelper.httpPost("service/configuration/rv/layout", jo);
		System.out.println(res.getStatus());
		String stringResponse = res.readEntity(String.class);
		System.out.println(stringResponse);
	}

	private static ObjectMapper getMapperObject() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.getDeserializationConfig().addMixInAnnotations(
				DataTransferObject.class, PolymorphicDtoMixIn.class);
		mapper.getSerializationConfig().addMixInAnnotations(
				DataTransferObject.class, PolymorphicDtoMixIn.class);

		mapper.getSerializationConfig().addMixInAnnotations(DataChange.class,
				PolymorphicEntityChangeMixIn.class);
		mapper.getDeserializationConfig().addMixInAnnotations(DataChange.class,
				PolymorphicEntityChangeMixIn.class);
		return mapper;

	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ServiceTesting ST = new ServiceTesting();
		//ST.BuildGetService();
		//ST.GetDepartmentLayout();
		//ST.GetServiceLocation();
		//ST.GetServiceICUArrived();
		ST.GetServiceDepartment();
		//ST.PostService();
	}

}
