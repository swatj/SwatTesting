/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.config;

import static org.jbehave.core.io.CodeLocations.codeLocationFromClass;
import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.TXT;
import static org.jbehave.core.reporters.Format.XML;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.parsers.gherkin.GherkinStoryParser;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterControls;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ParameterConverters.DateConverter;
import org.jbehave.core.steps.ParameterConverters.ExamplesTableConverter;

import com.ge.hac.pl.bdd.steps.commonservices.DatabaseDataCreationSteps;
import com.ge.hac.pl.bdd.steps.commonservices.StaticTestDataCreation;
import com.ge.hac.pl.bdd.steps.plintegration.AboutBoxSteps;
import com.ge.hac.pl.bdd.steps.plintegration.AuthenticationSteps;
import com.ge.hac.pl.bdd.steps.plintegration.AutoRefreshStep;
import com.ge.hac.pl.bdd.steps.plintegration.ColorCodeSteps;
import com.ge.hac.pl.bdd.steps.plintegration.ColumnSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CommonSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CurrentDateWorkflowSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CurrentLocationSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CurrentViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DateLabelSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DefaultSortingSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DepartmentAssignedSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DepartmentSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FilterSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FilteringAndSortingSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FutureViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.LocalizationSteps;
import com.ge.hac.pl.bdd.steps.plintegration.NewColumnsSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PastViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PatientListCSSSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PatientListDataSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PopoverSteps;
import com.ge.hac.pl.bdd.steps.plintegration.SiteSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.ConfiguratorSettingsSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.ConfiguratorSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.GridPanelSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.ResourceViewSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.SidePanelSteps;
import com.ge.hac.pl.bdd.steps.uvintegration.UnitviewPopoverSteps;
import com.ge.hac.pl.bdd.steps.uvservices.ConfigurationServiceSteps;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;

/**
 * <p>
 * {@link Embeddable} class to run multiple textual stories via JUnit using Guice Dependency Injection to compose the steps classes.
 * </p>
 * <p>
 * Stories are specified in classpath and correspondingly the {@link LoadFromClasspath} story loader is configured.
 * </p>
 */

public class BatchRunner extends JUnitStories
{

    private String[] storyListToRun;
    private String[] excludeStoryList;

    public BatchRunner()
    {

        // includedFeaturesList: Comma separated list of feature files to be run.
        // excludedFeaturesList: Comma separated list of feature files to be excluded from run.
        // Examples:
        // Run BDD2323_en_US & BDD2323_en_AU feature files : "**/BDD2323_en_US.feature, **/BDD2323_en_AU.feature"
        // Run all feature files : "**/*.feature"
        // Run a single BDD2062 feature file : "**/BDD2062.feature"

        String includedFeaturesList = "";
        String excludedFeaturesList = "";

        init(includedFeaturesList, excludedFeaturesList);

    }

    /**
     * Populate the list of features to be run and the list of features to be excluded.
     * 
     * 
     */
    private void init(String includedFeaturesList, String excludedFeaturesList)
    {

        configuredEmbedder().embedderControls().doGenerateViewAfterStories(true).doIgnoreFailureInStories(false)
                .doIgnoreFailureInView(false).useThreads(1).useStoryTimeoutInSecs(15000);

        if ( null != includedFeaturesList && !includedFeaturesList.isEmpty() )
        {
            storyListToRun = includedFeaturesList.split(",");
        }
        else
        {
            storyListToRun = PropertyFileHelper.getProjectProperty("strFeatureFilesToRun").split(",");
        }

        if ( null != excludedFeaturesList && !excludedFeaturesList.isEmpty() )
        {
            excludeStoryList = excludedFeaturesList.split(",");
        }
        else
        {

            excludeStoryList = PropertyFileHelper.getProjectProperty("strFeatureFilesToExclude").split(",");
        }
    }

    @Override
    public Configuration configuration()
    {

        Properties viewResources = new Properties();
        viewResources.put("decorateNonHtml", "true");
        Class<? extends Embeddable> embeddableClass = this.getClass();
        // Start from default ParameterConverters instance
        ParameterConverters parameterConverters = new ParameterConverters();
        // factory to allow parameter conversion and loading from external
        ExamplesTableFactory examplesTableFactory = new ExamplesTableFactory(new LocalizedKeywords(),
                new LoadFromClasspath(embeddableClass), parameterConverters);
        // add custom converters
        parameterConverters.addConverters(new DateConverter(new SimpleDateFormat("yyyy-MM-dd")),
                new ExamplesTableConverter(examplesTableFactory));

        return new MostUsefulConfiguration().useStoryLoader(new LoadFromClasspath(embeddableClass))
                .useStoryParser(new GherkinStoryParser())
                .useStoryReporterBuilder(new StoryReporterBuilder()
                        .withCodeLocation(CodeLocations.codeLocationFromClass(embeddableClass)).withDefaultFormats()
                        .withFormats(CONSOLE, TXT, CustomWebDriverHtmlOutput.MY_WEB_DRIVER_HTML, XML)
                        .withViewResources(viewResources).withFailureTrace(true)
                        .withReporters(new CustomStoryReporter()))
                .useParameterConverters(parameterConverters)
                .useParameterControls(new ParameterControls().useDelimiterNamedParameters(true));
    }

    @Override
    public InjectableStepsFactory stepsFactory()
    {
        // change me
        return new InstanceStepsFactory(configuration(), new CommonSteps(), new SiteSteps(), new DateLabelSteps(),
                new DepartmentSteps(), new PatientListCSSSteps(), new ColumnSteps(), new CurrentViewSteps(),
                new FutureViewSteps(), new PastViewSteps(), new PatientListDataSteps(), new NewColumnsSteps(),
                new FilterSteps(), new CurrentLocationSteps(), new DepartmentAssignedSteps(),
                new FilteringAndSortingSteps(), new DefaultSortingSteps(), new PopoverSteps(), new ColorCodeSteps(),
                new LocalizationSteps(), new AutoRefreshStep(), new CurrentDateWorkflowSteps(), new AboutBoxSteps(),
                new ResourceViewSteps(), new SidePanelSteps(), new ConfigurationServiceSteps(), new ConfiguratorSteps(),
                new GridPanelSteps(), new StaticTestDataCreation(), new AuthenticationSteps(),
                new UnitviewPopoverSteps(), new DatabaseDataCreationSteps(), new ConfiguratorSettingsSteps());
    }

    @Override
    protected List<String> storyPaths()
    {

        return new StoryFinder().findPaths(

                codeLocationFromClass(this.getClass()), Arrays.asList(storyListToRun), Arrays.asList(excludeStoryList));
    }
}
