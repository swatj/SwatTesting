/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class Bed
{
    private static Logger logger = Logger.getLogger(Bed.class);
    private String        Xpath;

    protected void initializeBed(String xpath)
    {
        this.Xpath = xpath;
    }

    /**
     * getters for the card contents
     */

    public String getBedName()
    {
        return getText("[@id='bedName']");
    }

    public String getPatientId()
    {
        return getText("[@id='patientId']");
    }

    public String getGender()
    {
        return getText("[@id='patientGender']");
    }

    public String getDateOfBirth()
    {
        return getText("[@id='patientDOB']");
    }

    public String getAge()
    {
        return getText("[@id='patientAge']");
    }

    public String getProcedure()
    {
        return getText("[@id='procedure']");
    }

    public String getSurgeon()
    {
        return getText("[@id='surgeon']");
    }

    public String getIntensivists()
    {
        return getText("[@id='intensivists'] ");
    }

    public String getAnesthesiologists()
    {
        return getText("[@id='anesthesiologists'] ");
    }

    public String getPacuNurse()
    {
        return getText("[@id='pacuNurse']");
    }

    public String getIcuNurse()
    {
        return getText("[@id='icuNurse']");
    }

    public String getPatientName()
    {
        return getText("[@id='patientFullName']");
    }

    public String getLos()
    {
        return getText("[@id='los']");
    }

    public String getAdmissionReason()
    {
        return getText("[@id='admissionReason']");
    }

    public String getLastTimeEvent()
    {
        return getText("[@id='lastTimeEvent']");
    }

    public String getStaffColor()
    {
        return getDeptColor("[@class='logged-in-user-indicator']");
    }

    /**
     * Boolean Flags for the Card contents
     */

    public boolean isPatientonVentilation()
    {

        return isDisplayed("[@id='ventilated']");

    }

    public boolean isPatientIsolated()
    {

        return isDisplayed("[@id='isolation']");
    }

    public boolean isPatientInfected()
    {

        return isDisplayed("[@id='infections']");

    }

    public boolean isBelongsToLoggedInUser()
    {

        return isDisplayed("[contains(@class,'logged-in-user-indicator')]");

    }

    public boolean isPatientSimilar()
    {

        return isDisplayed("[contains(@class,'patient-same-name-img')]");

    }

    public boolean isReadyForDischarge()
    {

        return isDisplayed("[@id='readyForDischarge']");
    }

    /**
     * Returns True if Ellipsis button is displayed
     */
    public boolean isEllipsisButton()
    {

        return isDisplayed("[contains(@class,'ellipsis dropdown-toggle')]");
    }

    /**
     * Returns True if popOver is displayed
     */

    public boolean isPopOverDisplayed()
    {

        String xPath = PropertyFileHelper.getObjectIdentifier("Bed_Popover");
        try
        {
            WebElement element = SeleniumUtility.getInstance().findElementbyXpath(xPath);

            if ( element != null && element.isDisplayed() )
            {
                return true;
            }
            else
                return false;
        }

        catch (NoSuchElementException e)
        {
            return false;
        }

    }

    /**
     * Returns Text of the cardItem
     */
    private String getText(String cardItem)
    {
        String xPathofCardItem = this.Xpath + cardItem;
        try
        {
            WebElement element = SeleniumUtility.getInstance().findElementbyXpath(xPathofCardItem);
            if ( element != null && element.isDisplayed() )
            {
                return element.getText();
            }
            else
            {
                return "";
            }
        }

        catch (NoSuchElementException e)
        {
            logger.debug("NoSuchElementException occured in:com.ge.hac.pl.bdd.functions:Bed:getText()   " + "xPath"
                    + xPathofCardItem);
            return "";
        }
    }

    /**
     * Returns True if cardItem is displayed
     */

    protected boolean isDisplayed(String cardItem)
    {

        String xPathofCardItem = this.Xpath + cardItem;

        try
        {
            WebElement element = SeleniumUtility.getInstance().findElementbyXpath(xPathofCardItem);
            if ( element != null && element.isDisplayed() )
            {
                return true;
            }
            else
                return false;
        }

        catch (NoSuchElementException e)
        {
            return false;
        }

    }

    public String getAllStaff()
    {
        String xPathofStaff = this.Xpath + "[@class='clearfix']/div[1]//span";
        String staffNames = "";
        List<WebElement> allStaff = SeleniumUtility.getInstance().findElementsByXpath(xPathofStaff);
        for (WebElement staff : allStaff)
        {
            if ( "".equalsIgnoreCase(staffNames) )
            {
                staffNames = staff.getText();
            }
            else
            {

                staffNames = staffNames + staff.getText();
            }

        }
        return staffNames;
    }

    /**
     * @return Isolation icon's Text
     */
    public String getIsolationText()
    {
        return getText("[@id='isolation-text']");
    }

    /**
     * @return Similar name icon's Text
     */
    public String getSimilarnameText()
    {

        return getText("[@id='similarPatient-text']");
    }

    /**
     * @return
     */
    public String getPatientNameFieldText()
    {

        return getText("[@id='patientFullName']/parent::div//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getPatientIdFieldText()
    {
        return getText("[@id='patientId']/parent::td/preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getDateOfBirthFieldText()
    {
        return getText("[@id='patientDOB']//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getAgeFieldText()
    {
        return getText("[@id='patientGender']//parent::div//parent::td//preceding-sibling::td//span[2]");
    }

    /**
     * @return
     */
    public String getSurgeonFieldText()
    {
        return getText("[@id='surgeon']//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getAnesthesiologistsFieldText()
    {
        return getText("[@id='anesthesiologists']//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getPacuNurseFieldText()
    {
        return getText("[@id='pacuNurse']//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getGenderFieldText()
    {
        return getText("[@id='patientGender']/parent::div//parent::td//preceding-sibling::td//span[1]");
    }

    /**
     * @return
     */
    public String getProcedureFieldText()
    {
        return getText("[@id='procedure']//parent::td//preceding-sibling::td");
    }

    /**
     * @return
     */
    public String getLosFieldText()
    {
        return getText("[@id='los-text']");
    }

    public String getLastTimeEventText()
    {
        return getText("[@id='lastTimeEvent']//parent::td//preceding-sibling::td");
    }

    public String getIntensivistsText()
    {
        return getText("[@id='intensivists']//parent::td//preceding-sibling::td");
    }

    public String getIcuNurseText()
    {
        return getText("[@id='icuNurse']//parent::td//preceding-sibling::td");
    }

    public String getAdmissionReasontext()
    {
        return getText("[@id='admissionReason']//parent::td//preceding-sibling::td");
    }

    // return text color of passed element
    public String getDeptColor(String colorCodeXpath)
    {

        String xPathofStaffColor = this.Xpath + colorCodeXpath;

        try
        {
            WebElement element = SeleniumUtility.getInstance().findElementbyXpath(xPathofStaffColor);
            // get text color in rgba format
            String textColor = element.getCssValue("background-color");
            // convert text value into hexadecimal value
            String[] hexValue = textColor.replace("rgba(", "").replace(")", "").split(",");
            int hexValueR = Integer.parseInt(hexValue[0].trim());
            int hexValueG = Integer.parseInt(hexValue[1].trim());
            int hexValueB = Integer.parseInt(hexValue[2].trim());
            // convert into string
            return String.format(Constants.COLOR_FORMAT, hexValueR, hexValueG, hexValueB);
        }

        catch (NoSuchElementException e)
        {
            logger.debug("NoSuchElementException occured in:com.ge.hac.pl.bdd.functions:Bed:getText()   " + "xPath"
                    + xPathofStaffColor);
            return "";
        }

    }

    public boolean isBedConflicts()
    {
        return isDisplayed("[contains(@class,'conflict-border')]");

    }

    public String getBedConfictMessage()
    {

        try
        {
            return SeleniumUtility.getInstance().getElementByXPath("conflict_message").getText().trim();
        }

        catch (IOException e)
        {
            e.printStackTrace();
            return "";
        }
    }

    public String getBedConfictTableHeaders()
            throws IOException, InterruptedException
    {
        String Headers = "";
        List<WebElement> elements = SeleniumUtility.getInstance().findElements("bed_conflict_table_Header");
        for (WebElement header : elements)
        {
            if ( Headers.equalsIgnoreCase("") )
            {
                Headers = header.getText();
            }
            else
            {
                Headers = Headers + ";" + header.getText();
            }

        }
        return Headers;
    }

    /**
     * @return
     */
    public String[][] getBedConfictCaseData()
            throws IOException, InterruptedException
    {

        List<WebElement> elements = SeleniumUtility.getInstance().findElements("bed_conflict_casedata");
        String[][] caseData = new String[elements.size() / 3][3];
        int j = 0;
        for (int i = 0; i <= elements.size() / 3 + 1; i = i + 3)
        {
            caseData[j][0] = elements.get(i).getText();
            caseData[j][1] = elements.get(i + 1).getText();
            caseData[j][2] = elements.get(i + 2).getText();
            j++;

        }
        return caseData;
    }
}
