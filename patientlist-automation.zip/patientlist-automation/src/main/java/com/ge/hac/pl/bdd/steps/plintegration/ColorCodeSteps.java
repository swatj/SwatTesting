package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

public class ColorCodeSteps
{

    @Then("verify the Care Phase state displayed in Care Phase column for 'PreOp' case and also verify the color code displayed")
    @Aliases(values =
    {
            "verify the Care Phase state displayed in Care Phase column for 'IntrOp' case and also verify the color code displayed",
            "verify the Care Phase state displayed in Care Phase column for 'Postop' case and also verify the color code displayed",
            "verify the Care Phase state displayed in Care Phase column for 'PACU Phase 2' case and also verify the color code displayed",
            "verify the Care Phase state displayed in Care Phase column for 'Not Arrived' case and also verify the no color code displayed",
            "verify the Care Phase state displayed in Care Phase column for 'Discharged' case and also verify the no color code displayed"
    })
    public void verifyColorCodeForPreOp(@Named("ColorCodeImage") String colorCodeImage,
            @Named("Patient ID") String patientIDValue, @Named("Care phase") String carePahseValue)
            throws Exception
    {

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);

        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.CARE_PHASE_COLUMN, carePahseValue);
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);
        int carePhaseColPosition = PatientListData.getInstance().getColumnPosition(headerNames,
                Constants.CARE_PHASE_COLUMN);
        System.out.println("RowID and PatientID " + patientIDRowNumber + " " + carePhaseColPosition);
        PatientListData.getInstance().verifyCarePhaseValue(patientIDRowNumber, headerNames, carePahseValue);
        PatientListData.getInstance().verifyColorCode(patientIDRowNumber, headerNames, colorCodeImage, carePahseValue);

    }

    @Then("verify the color code displayed in Care Phase column for Cancelled")
    public void verifyColorCodeForCancelled(@Named("ColorCodeImage") String colorCodeImage,
            @Named("Patient ID") String patientIDValue, @Named("Care phase") String carePahseValue)
            throws Exception
    {

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);

        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.CARE_PHASE_COLUMN, carePahseValue);
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);
        int carePhaseColPosition = PatientListData.getInstance().getColumnPosition(headerNames,
                Constants.CARE_PHASE_COLUMN);
        System.out.println("RowID and PatientID " + patientIDRowNumber + " " + carePhaseColPosition);
        PatientListData.getInstance().verifyCarePhaseValue(patientIDRowNumber, headerNames, carePahseValue);
        PatientListData.getInstance().verifyColor(patientIDRowNumber, headerNames, colorCodeImage);

    }

}
