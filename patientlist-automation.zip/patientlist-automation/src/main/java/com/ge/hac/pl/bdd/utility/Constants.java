/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class Constants
{
    private Constants()
    {

    }

    public enum DeptFolderNames
    {
        PREOP("Preop", "Preoperative departments"), ANESTHESIA("anesthesia", "Operative departments"), POSTOP("Postop",
                "Postoperative departments"), ICU("ICU", "CARE units"), LOGIN("Login", "Login departments");

        private String deptFolderName;
        private String deptKeyInFeature;

        DeptFolderNames(String deptKeyInFeature, String deptFolderName)
        {
            this.deptKeyInFeature = deptKeyInFeature;
            this.deptFolderName = deptFolderName;
        }

        /**
         * @return the deptFolderName
         */
        public String getDeptFolderName()
        {
            return this.deptFolderName;
        }

        /**
         * @param deptFolderName the deptFolderName to set
         */
        public void setDeptFolderName(String deptFolderName)
        {
            this.deptFolderName = deptFolderName;
        }

        /**
         * @return the deptKeyInFeature
         */
        public String getDeptKeyInFeature()
        {
            return this.deptKeyInFeature;
        }

        /**
         * @param deptKeyInFeature the deptKeyInFeature to set
         */
        public void setDeptKeyInFeature(String deptKeyInFeature)
        {
            this.deptKeyInFeature = deptKeyInFeature;
        }

    }

    // Configurator tool
    public enum ConfigToolTabs
    {
        SETTINGS("Settings", "Settings"), UNITVIEWLAYOUT("UnitViewLayout", "Unit View Layout"), SUMMARY("Summary",
                "Summary"), CONFIGURATON("Configuration", "Configuration");

        private String tabName;
        private String tabIdInFeature;

        ConfigToolTabs(String tabIdInFeature, String tabName)
        {
            this.setTabName(tabName);
            this.setTabIdInFeature(tabIdInFeature);
        }

        /**
         * @return the tabName
         */
        public String getTabName()
        {
            return this.tabName;
        }

        /**
         * @param tabName the tabName to set
         */
        public void setTabName(String tabName)
        {
            this.tabName = tabName;
        }

        /**
         * @return the tabIdInFeature
         */
        public String getTabIdInFeature()
        {
            return this.tabIdInFeature;
        }

        /**
         * @param tabIdInFeature the tabIdInFeature to set
         */
        public void setTabIdInFeature(String tabIdInFeature)
        {
            this.tabIdInFeature = tabIdInFeature;
        }

    }

    public static final String BROWSERTITLE                          = "Centricity High Acuity Cockpit";
    public static final String HELPTITLE                             = "User's Reference Manual";
    public static final String INVALIDCREDENTIALMESSAGE              = "Invalid Username or Password";
    public static final int    LEVEL_INFO                            = 0;
    public static final int    LEVEL_SEVERE                          = 1;
    public static final int    LEVEL_FINEST                          = 2;
    public static final int    LEVEL_WARNING                         = 3;
    public static final int    LEVEL_CONFIG                          = 4;
    public static final int    HIGH_TIMEOUT                          = 60;
    public static final int    AUTO_REFRESH_INTERVAL                 = 30000;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 // wait

    public static final int    ERROR_STATUS                          = 0;
    public static final String GRANT_TYPE                            = "password";
    public static final String CLIENT_ID                             = "ca";
    public static final String CLIENT_SECRET                         = "ca";
    public static final String USERNAME                              = "administrator";
    public static final String PASSWORD                              = "healthcare";
    public static final String SCOPE                                 = "5100000000000W000K";
    public static final String PATIENT_LIST_FOLDER_ID                = "5100000000000W000K";
    // 30
    // seconds
    public static final String FROM_TO_DATE_VALIDATION               = "From date must be before To date. Select a new date range.";
    public static final String NO_SITES                              = "User is not authorized to access any site.";
    public static final String ADDSITE_DROPDOWN_TEXT                 = "Add a site";
    public static final String WHITE_COLOR                           = "#ffffff";
    public static final String GRAY_COLOR                            = "#dcdcdc";
    public static final String LIGHTBLUE_COLOR                       = "#12aceb";
    public static final String INACTIVE_SITE_BGCOLOR                 = "#dcdcdc";
    public static final String INACTIVE_SITE_TEXTCOLOR               = "#797979";
    public static final String DEPARTMENT_WIDTH                      = "100px";
    public static final String DEPARTMENT_TEXTALIGN                  = "center";
    public static final String SITE_DEPARTMENT_CONTAINER             = "primary-navbar patient-list-primary-nav";
    public static final String DATE_SEARCH_CONTAINER                 = "nav-divider calendar-pos";
    public static final String BUTTON_CONTAINER                      = "input-group patient-grid-conf";
    public static final String DEPARTMENT_CONTAINER                  = "gridModule module";
    public static final String COLOR_FORMAT                          = "#%02x%02x%02x";
    public static final String INVALID_DATE_VALIDATION               = "Please enter date in correct date format: MM/dd/yyyy";
    public static final String BLANK_DATE_VALIDATION                 = "Both From and To dates are required.";
    public static final String CARE_PHASE_NOT_ARRIVED                = "Not Arrived";
    public static final String CARE_PHASE_DISCHARGED                 = "Discharged";
    public static final String PERIOP_DEPTS_INDICATOR_COLOR          = "anesthesia-dept-indicator";
    public static final String ICU_DEPTS_INDICATOR_COLOR             = "icu-dept-indicator";

    // patient list columns name constance
    public static final String CARE_PHASE_COLUMN                     = "Care phase";
    public static final String PATIENT_ID_COLUMN                     = "Patient ID";
    public static final String SURGEON_COLUMN                        = "Surgeon";
    public static final String CURRENT_LOCATION_COLUMN               = "Current location";
    public static final String CASE_ID_COLUMN                        = "Case ID";
    public static final String OR_COLUMN                             = "OR";
    public static final String SCHED_TIME_COLUMN                     = "Sched time";
    public static final String PATIENT_COLUMN                        = "Patient";
    public static final String VISIT_ID_COLUMN                       = "Visit ID";
    public static final String PROCEDURE_COLUMN                      = "Procedure";
    public static final String ANESTHESIA_COLUMN                     = "Anesthesiologist";
    public static final String STATUS_LOS_COLUMN                     = "Status / Duration";
    public static final String FROM_TO_COLUMN                        = "From / To";
    public static final String ASA_COLUMN                            = "ASA";
    public static final String SPECIALTY_COLUMN                      = "Specialty";
    public static final String DIAGNOSIS_COLUMN                      = "Diagnosis";
    public static final String NURSE_COLUMN                          = "Nurse";
    public static final String ANES_TECHNIQUE_COLUMN                 = "Anes technique";
    public static final String SSN_COLUMN                            = "SSN";
    public static final String OPEARABILITY_CODE_COLUMN              = "Operability";
    public static final String FILTERED_COLUMN_BGCOLOR               = "#bae3f4";
    public static final String NAME_COLUMN                           = "Name";
    public static final String GENDER_COLUMN                         = "Gender";
    public static final String DOB_COLUMN                            = "DOB";
    public static final String AGE_COLUMN                            = "Age";
    public static final String WEIGHT_COLUMN                         = "Weight (kg)";
    public static final String HEIGHT_COLUMN                         = "Height (cm)";
    public static final String POST_OP_COLUMN                        = "Postop";
    public static final String TEST_DATA_DIR                         = "\\\\3.204.35.145\\\\Source";
    public static final String CA_INTERFACE_DIR                      = "\\\\3.204.35.145\\\\GE-Healthcare\\\\CA\\\\caXML_from_ES";
    public static final String ASC_SORT                              = "asc";
    public static final String DESC_SORT                             = "desc";
    public static final String SINGLE_SPACE                          = " ";
    public static final String COMMA_SEPERATOR                       = ",";
    public static final String NEWLINE_SEPERATOR                     = "\n";
    public static final String SIGNIN_BUTTON_LABEL                   = "Sign In";

    public static final String POC_DB_NAME                           = "POC";
    public static final String COMMON_DB_NAME                        = "Common";

    public static final String MAIN_TITTLE                           = "There is a problem with this website’s security certificate.";
    public static final String COLUMN_NAME_LOCALE                    = "weightkgs.columndata.item.name,patient.location.column.name,care.phase.column.name,patient.or.column.name,scheduled.procedure.date.column.name,periopcaseid.column.name,patient.column.name,patientid.column.name,visitid.column.name,ssn.column.name,asaclassification.column.name,procedure.column.name,diagnosis.column.name,specialty.column.name,anesthesiatype.column.name,surgeon.column.name,anesthesiologist.column.name,nurse.column.name,periopstatuslos.column.name,coming.discharge.column.name,preop.readiness.column.name,patient.postop.column.name,name.columndata.item.name,gender.columndata.item.name,dob.columndata.item.name,age.columndata.item.name,heightcms.columndata.item.name";
    public static final String ABOUT_LINK                            = "About Patient List";
    public static final String MANUFACTURE_ADDRESS                   = "GE Healthcare540 W. Northwest HighwayBarrington, IL 60010 USATel: +1 847-277-5000Fax: +1 847-277-5240gehealthcare.com";
    public static final String GELOGO_IMAGE                          = "mono";
    public static final String ASIAHEADQUARTER_ADDRESS               = "GE Healthcare1 BLD-3FNo.1 Hua Tuo RoadZhang Jiang Hi-Tech ParkShanghai 201203 ChinaTel: +8621-38777888Fax: +8621-38777499";
    public static final String STEP_STATUS_PASS                      = "Pass";
    public static final String STEP_STATUS_NOTPERFORMED              = "NotPerformed";
    public static final String STEP_STATUS_PENDING                   = "Pending";
    public static final String STEP_STATUS_FAILED                    = "Failed";
    public static final String STEP_STATUS_IGNORABLE                 = "Ignorable";
    public static final String RESOURCE_VIEW_ICON                    = "ico-resource-view";
    public static final String PATIENTLIST_VIEW_ICON                 = "ico-patient-list";
    public static final String CONFIGURATOR_USER                     = "administrator";
    public static final String CONFIGURATOR_USER_PWD                 = "healthcare";
    public static final String CONFIGURATOR_FIRST_TAB_NAME           = "Settings";
    public static final String CONFIGURATOR_SECOND_TAB_NAME          = "Unit View Layout";
    public static final String UNIT_VIEW_NAME                        = "unit view";
    public static final String PATIENTLIST_VIEW_NAME                 = "patient list";
    public static final String BED_LAYOUT_MISSING                    = "Layout view is not configured for this department";

    public static final String TASKLIST                              = "tasklist";
    public static final String KILL                                  = "taskkill /F /IM ";
    public static final String CHROME_DRIVER_PROCESS_NAME            = "chromedriver.exe";
    public static final String IE_DRIVER_PROCESS_NAME                = "IEDriverServer.exe";
    public static final String ALL_TAB_NAME                          = "All Periop";
    public static final String ARRIVING_FILTERED_BGCOLOR             = "#d9f0f9";
    public static final String SQL_DRIVER_CLASS                      = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static final Object BED_CONFLICT_MESSAGE_IN_POPOVER       = "The following patients are assigned to the same location:";
    public static final Object BED_CONFLICT_TABLE_HEADERS_IN_POPOVER = "Patient name;Patient ID;Admission time";

}
