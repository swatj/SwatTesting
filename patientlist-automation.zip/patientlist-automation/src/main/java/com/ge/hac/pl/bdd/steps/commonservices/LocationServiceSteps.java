/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.commonservices;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.junit.Assert;

import com.ge.hac.common.ea.dto.configuration.DepartmentLayoutConfiguration;
import com.ge.hac.common.ea.dto.configuration.DeptLayout;
import com.ge.hac.common.ea.dto.reference.hospital.Department;
import com.ge.hac.common.ea.dto.reference.hospital.DepartmentExt;
import com.ge.hac.common.ea.dto.reference.hospital.HospitalExt;
import com.ge.hac.pl.bdd.steps.uvservices.ConfigurationServiceSteps;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.RestParams;
import com.ge.hac.pl.bdd.utility.ServiceHandler;

/**
 * @author 305014106
 *
 */
@SuppressWarnings("unchecked")
public class LocationServiceSteps
{
    private static Logger            logger = Logger.getLogger(LocationServiceSteps.class);

    private static int               allLoginServiceResponse;
    private static String            allLoginResponseString;
    private static List<Department>  allLoginResponseEntity;

    private static int               userHospitalsServiceResponse;
    private static String            userHospitalsResponseString;
    private static List<HospitalExt> userHospitalsResponseEntity;

    @When("the service.allLoginDepartments url is invoked:$dataTable")
    public static void invokeGetRestEndpoint(ExamplesTable dataTable)
    {
        RestParams rp = ServiceHandler.extractRestParamsFromTable(dataTable);
        Response response = ServiceHandler.invokeAndGetResponse(rp.getRequestType(), rp.getRestEndpoint(),
                rp.getQueryParams(), null);

        LocationServiceSteps.allLoginResponseString = response.readEntity(String.class);
        LocationServiceSteps.allLoginServiceResponse = response.getStatus();
        LocationServiceSteps.allLoginResponseEntity = (List<Department>) CommonUtility.getObjectListFromJson(
                CommonUtility.getMapperObject(), allLoginResponseString, List.class, Department.class);

        Assert.assertEquals("Response is OK", HttpResponseCodes.SC_OK, LocationServiceSteps.allLoginServiceResponse);
    }

    @Then("verify that service.allLoginDepartments returns $departmentCount departments")
    public static void verifyDepartmentCount(String departmentCount)
    {
        logger.debug("Number of departments = " + LocationServiceSteps.allLoginResponseEntity.size());
        Assert.assertEquals("Department count matches", Integer.parseInt(departmentCount),
                LocationServiceSteps.allLoginResponseEntity.size());
    }

    @Then("verify that service.allLoginDepartments returns expected data: $dataTable")
    public static void verifyGetAllLoginDepartmentsServiceresponse(ExamplesTable dataTable)
    {
        int iter = 0;
        List<Department> dl = LocationServiceSteps.allLoginResponseEntity;
        for (Map<String, String> row : dataTable.getRows())
        {
            DepartmentExt de = (DepartmentExt) dl.get(iter);
            Assert.assertTrue("Department name assertion", row.get("deptName").equalsIgnoreCase(de.getName()));
            Assert.assertTrue("Department id assertion", row.get("deptId").equalsIgnoreCase(de.getId()));
            Assert.assertTrue("Department type assertion", row.get("deptType").equalsIgnoreCase(de.getType()));
            Assert.assertEquals("Room count assertion", Integer.parseInt(row.get("roomCount")), de.getRooms().size());

            iter += 1;
        }
    }

    @When("the service.userHospitals url is invoked: $dataTable")
    public static void invokeGetUserHospitals(ExamplesTable dataTable)
    {
        RestParams rp = ServiceHandler.extractRestParamsFromTable(dataTable);
        Response response = ServiceHandler.invokeAndGetResponse(rp.getRequestType(), rp.getRestEndpoint(),
                rp.getQueryParams(), null);

        LocationServiceSteps.userHospitalsResponseString = response.readEntity(String.class);
        LocationServiceSteps.userHospitalsServiceResponse = response.getStatus();
        LocationServiceSteps.userHospitalsResponseEntity = (List<HospitalExt>) CommonUtility.getObjectListFromJson(
                CommonUtility.getMapperObject(), userHospitalsResponseString, List.class, HospitalExt.class);

        Assert.assertEquals("Response is OK", HttpResponseCodes.SC_OK, userHospitalsServiceResponse);
    }
    
    @Then("the service.userHospitals returns $hospitalCount sites")
    public static void verifyHospitalCount(String hospitalCount)
    {
        logger.debug("Number of sites = " + LocationServiceSteps.userHospitalsResponseEntity.size());
        Assert.assertEquals("Site count matches", Integer.parseInt(hospitalCount),
                LocationServiceSteps.userHospitalsResponseEntity.size());
    }
    @Then("verify that service.userHospitals returns Hospitals Details: $dataTable")
    public static void verifyDeaprtmentAttributes(ExamplesTable dataTable)
    {
        int iter = 0;
        List<HospitalExt> d = LocationServiceSteps.userHospitalsResponseEntity;
        for (Map<String, String> row : dataTable.getRows())
		{
			HospitalExt de = (HospitalExt) d.get(iter);
            Assert.assertTrue("Department name assertion", row.get("sitename").equalsIgnoreCase(de.getName()));
            iter += 1;
		}

        
    }
}
