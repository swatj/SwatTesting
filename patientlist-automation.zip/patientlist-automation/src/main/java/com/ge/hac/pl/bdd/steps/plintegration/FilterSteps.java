/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Column;
import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

public class FilterSteps
{
    int columnPositionBeforeReorder, columnPositionAfterReorder;
    int filterTextboxWidthOfcolumnBefore, filterTextboxWidthOfcolumnAfter;

    @Then("Filter text box should be present for all displayed columns")
    public void verifyFilterTextBoxDisplay()
            throws IOException, InterruptedException
    {
        boolean filterTextBox;
        String columnName;
        List<String> visibleColumnList = Filter.getInstance().getVisibleColumnList();
        for (int i = 0; i < visibleColumnList.size(); i++)
        {
            columnName = visibleColumnList.get(i).toString();
            filterTextBox = Filter.getInstance().isFilterTextBoxPresent(columnName);
            Assert.assertEquals("Filter Textbox should be present for " + columnName + " column", true, filterTextBox);
        }
    }

    @When("the user adds <addColumn> column from column pool")
    public void addColumn(@Named("addColumn") String columnToAdd)
            throws Exception
    {
        if ( !(PatientList.getInstance().verifyColumnDisplay(columnToAdd)) )
        {
            PatientList.getInstance().addColumnToColumnList(columnToAdd);
        }
        boolean isColumnVisible = PatientList.getInstance().verifyColumnDisplay(columnToAdd);
        Assert.assertEquals("After adding column verify column " + columnToAdd + " is displayed on PL header", true,
                isColumnVisible);
    }

    @Then("the filter textbox is visible for the column")
    public void verifyFilterTextBoxForColumn(@Named("Column") String columnName)
            throws IOException, InterruptedException
    {
        boolean filterTextBox;
        filterTextBox = Filter.getInstance().isFilterTextBoxPresent(columnName);
        Assert.assertEquals("Filter Textbox should be present for " + columnName + " column", true, filterTextBox);
    }

    @When("the user enters text in the filter textbox for <column> column")
    public void applyFilter(@Named("column") String columnName, @Named("filterValue") String filterValue)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        String[] columnNameList = columnName.split(",");
        String[] filterValues = filterValue.split(",");
        for (int i = 0; i < columnNameList.length; i++)
        {
            if ( !(PatientList.getInstance().verifyColumnDisplay(columnNameList[i])) )
            {
                PatientList.getInstance().addColumnToColumnList(columnNameList[i]);
            }
            Filter.getInstance().setFilter(columnNameList[i], filterValues[i]);
        }

    }

    @Then("apply filter as <filterValue> on <column> column")
    public void applyFiltertext(@Named("column") String columnName, @Named("filterValue") String filterValue)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        String[] columnNameList = columnName.split(",");
        String[] filterValues = filterValue.split(",");
        for (int i = 0; i < columnNameList.length; i++)
        {
            if ( !(PatientList.getInstance().verifyColumnDisplay(columnNameList[i])) )
            {
                PatientList.getInstance().addColumnToColumnList(columnNameList[i]);
            }
            Filter.getInstance().setFilter(columnNameList[i], filterValues[i]);
        }

    }

    @Then("the clear button should be displayed at the end of filter textbox of <column> column")
    public void verifyClearButtonDisplay(@Named("column") String columnName)
            throws IOException, InterruptedException
    {
        boolean filterClearButton = Filter.getInstance().isFilterClearButtonPresent(columnName);
        Assert.assertEquals("Filter clear button should be present for " + columnName + " column", true,
                filterClearButton);
    }

    @When("the user clicks on clear button of filter text box of <column> column")
    public void clickClearButton(@Named("column") String columnName)
            throws IOException
    {
        Filter.getInstance().clearFilter(columnName);
    }

    @Then("filter data should be cleared and filter text box should be blank")
    public void verifyFilterTextBoxBlank(@Named("column") String columnName)
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Filter textbox should be blank for column " + columnName, "",
                Filter.getInstance().getFilterTextBoxText(columnName));
        boolean filterClearButton = Filter.getInstance().isFilterClearButtonPresent(columnName);
        Assert.assertEquals("Filter clear button should not be present for " + columnName + " column", false,
                filterClearButton);
    }

    @When("the user removes <column> column from Patient List")
    public void removeColumn(@Named("column") String columnName)
            throws Exception
    {
        PatientList.getInstance().removeColumnFromColumnList(columnName);
    }

    @Then("<column> column should be removed from patient list along with filter textbox")
    public void verifyColumnRemoved(@Named("column") String columnName)
            throws Exception
    {
        boolean isColumnVisible = PatientList.getInstance().verifyColumnDisplay(columnName);
        Assert.assertEquals("After removing column verify column " + columnName + " is not displayed on screen", false,
                isColumnVisible);
        boolean isTextBoxVisible = Filter.getInstance().isFilterTextBoxPresent(columnName);
        Assert.assertEquals("After removing column " + columnName + " filter text box is not displayed on screen",
                false, isTextBoxVisible);
    }

    @Then("filtered columns should be displayed with light blue color")
    public void verifyFilteredColumnBGColor(@Named("column") String columnName)
            throws IOException, InterruptedException
    {
        String[] columnList = columnName.split(",");
        for (int i = 0; i < columnList.length; i++)
        {
            String actBGColor = Filter.getInstance().getFilteredColumnBackgroundColor(columnList[i]);
            Assert.assertEquals("verify background color of " + columnList[i] + " column",
                    Constants.FILTERED_COLUMN_BGCOLOR, actBGColor);
        }
    }

    @Then("Patient list should display error message when filter data doesnot present")
    public void verifyNoFilterErrorMessage()
            throws IOException, InterruptedException
    {
        Filter.getInstance().verifyNoFilterErrorMessage();
    }

    @Then("PatientList should display filtered data based on filtered value")
    public void verifyFilteredDataDisplayed(@Named("column") String columnName,
            @Named("filterValue") String filterValues)
            throws Exception
    {

        String[] columnNameList = columnName.split(",");
        String[] filterValueList = filterValues.split(",");
        for (int i = 0; i < columnNameList.length; i++)
        {
            boolean filtered = Filter.getInstance().verifyFilteredData(columnNameList[i], filterValueList[i]);
            Assert.assertEquals("verify data should be present for filtered value " + filterValueList[i], true,
                    filtered);
        }
    }

    @When("the user enters text in the filter textbox for <column> column and the filtered data is displayed")
    public void applyVerifyFilter(@Named("column") String column, @Named("filterValue") String filterValue)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        if ( !(PatientList.getInstance().verifyColumnDisplay(column)) )
        {
            PatientList.getInstance().addColumnToColumnList(column);
        }
        Filter.getInstance().setFilter(column, filterValue);
        boolean filtered = Filter.getInstance().verifyFilteredData(column, filterValue);
        Assert.assertEquals("verify data should be present for filtered value" + filterValue, true, filtered);
    }

    @Then("PatientList should display all data(not filtered)")
    public void verifyNonFilteredDataDisplay(@Named("column") String column, @Named("filterValue") String filterValue)
            throws IOException, InterruptedException
    {
        Filter.getInstance().verifyAllDataPresent();

    }

    @Then("PatientList should display all data(not filtered) after changing site")
    @Alias("PatientList should display all data(not filtered) after relogin")
    public void verifyNonFilteredDataDisplayAfterChangingSite(@Named("column") String column,
            @Named("filterValue") String filterValue)
            throws Exception
    {
        Thread.sleep(3000);
        boolean filtered = Filter.getInstance().verifyFilteredData(column, filterValue);
        Assert.assertEquals("verify All data should be present(not filtered)", false, filtered);
    }

    @Then("Patient list should highlight the matching search text in patient data with a color")
    public void verifyMatchingTextHighlighted(@Named("filterValue") String filterValue)
            throws IOException, InterruptedException
    {
        Filter.getInstance().verifyMatchingTextHighlighted(filterValue);
    }

    @When("wait till auto refresh")
    public void waitForAutoRefresh()
            throws InterruptedException
    {
        Thread.sleep(6000);
    }

    @When("the user resizes <ColumnName> column in patient list grid")
    public void resizeColumn(@Named("ColumnName") String columnName)
            throws IOException, InterruptedException
    {
        filterTextboxWidthOfcolumnBefore = Filter.getInstance().getFilterTextBoxWidth(columnName);
        Column.getInstance().clickIncWidthColumn(columnName);
    }

    @Then("the column should be resized along with filter textbox in patient list grid")
    public void veridyColumnResize(@Named("ColumnName") String columnName)
            throws IOException, InterruptedException
    {
        Column.getInstance().verifyColumnIncWidth(columnName);
        filterTextboxWidthOfcolumnAfter = Filter.getInstance().getFilterTextBoxWidth(columnName);

        Assert.assertFalse(columnName + "   column should be resized along with filter textbox in patient grid",
                filterTextboxWidthOfcolumnAfter == filterTextboxWidthOfcolumnBefore);
    }

    @When("the user re-orders <ColumnName> column in patient list grid")
    public void reorderColumn(@Named("ColumnName") String columnName)
            throws Exception
    {
        List<String> columnList = new ArrayList<String>();
        if ( !(PatientList.getInstance().verifyColumnDisplay(columnName)) )
        {
            PatientList.getInstance().addColumnToColumnList(columnName);
        }
        columnList.add(columnName);
        columnPositionBeforeReorder = PatientListData.getInstance().getColumnPosition(columnList, columnName);
        Filter.getInstance().clickReorderButton();
        Column.getInstance().columnReorderLeft(columnName);
    }

    @Then("the column should be re-ordered along with filter textbox in patient list grid")
    public void verifyColumnReorderedWithFilterTextBox(@Named("ColumnName") String columnName)
            throws InterruptedException, IOException
    {
        List<String> columnList = new ArrayList<String>();
        Map<String, Integer> filterTextBoxIndexMap = new HashMap<String, Integer>();
        columnList.add(columnName);
        columnPositionAfterReorder = PatientListData.getInstance().getColumnPosition(columnList, columnName);
        // verify column reordered
        Assert.assertTrue("verify " + columnName + " column is reordered",
                columnPositionAfterReorder < columnPositionBeforeReorder);
        // check filter textbox and column position
        filterTextBoxIndexMap = Filter.getInstance().getFilterTextBoxesPosition();
        int filterTextBoxPosition = filterTextBoxIndexMap.get(columnName);
        Assert.assertEquals("verify position of " + columnName + " column and its filtered text box",
                columnPositionAfterReorder, filterTextBoxPosition);

    }

    @When("the user removes text in the filter textbox for <remove column> column")
    public void removeFilter(@Named("remove column") String columnName)
            throws IOException, InterruptedException
    {
        Filter.getInstance().clearFilter(columnName);
    }

    @Then("List panel shows filter text box")
    public void verifyArrivingListFilterTextBoxDisplay()
            throws IOException, InterruptedException
    {
        boolean arrivingListFilterTextBox = Filter.getInstance().isArrivingListFilterTextBoxPresent();
        Assert.assertEquals("Arriving List Filter Textbox should be present.", true, arrivingListFilterTextBox);
    }

    @When("the user enters text in the arriving list filter textbox")
    public void applyFilterToArrivingList(@Named("filtertext") String filtertext)
            throws Exception
    {

        boolean checkfiltertextavailability = Filter.getInstance().isArrivingListFilterTextBoxPresent();
        String[] filtertexts = filtertext.split(",");
        for (int i = 0; i < filtertexts.length; i++)
        {
            Filter.getInstance().setArrivingListFilter(filtertexts[i]);

        }

    }

    @Then("the clear button should be displayed at the end of the arriving list filter textbox")
    public void clickOnArrivingListFilterClearButton()
            throws IOException, InterruptedException
    {

        boolean arrivingListfilterClearButton = Filter.getInstance().isArrivingListFilterClearButtonPresent();
        Assert.assertEquals("ArrivingList Filter clear button should be present", true, arrivingListfilterClearButton);
    }

    @Then("Arriving list should display cards based on filter text")
    @When("Arriving list should display cards based on filter text")
    public void verifyArrivingListFilteredCards(@Named("filtertext") String filtertext)
            throws Exception
    {
        Thread.sleep(5000);
        boolean arrivingListFilteredCards = Filter.getInstance().isArrivingListFiltered(filtertext);
        System.out.println();
        Assert.assertEquals("Arrivingpatient list should display filtered cards based on filter text", true,
                arrivingListFilteredCards);
    }

    @Then("Arriving list should highlight the matching text on cards with a color")
    public void verifyMatchingTextHighlightedOnCards(@Named("filtertext") String filtertext)
            throws IOException, InterruptedException
    {
        Filter.getInstance().verifyMatchingTextHighlighted(filtertext);
    }

    @When("the user clicks on clear button of arriving list filter textbox")
    public void clearArrivingListFilter()
            throws IOException
    {

        Filter.getInstance().clearArrivingListFilter();
    }

    @Then("Arriving list filter textbox should be blank")
    public void verifyFilterTextBoxBlank()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Filter textbox should be blank", "",
                Filter.getInstance().getArrivingListFilterTextBoxText());

    }

    @Then("Arriving list should display all cards")
    public void verfyArrivingListDisplayAllCards(@Named("filtertext") String filtertext)
            throws IOException, InterruptedException
    {

        Filter.getInstance().verifyAllCardsPresent();
    }

    @When("the user enters text in the arriving list filter textbox, the filtered cards are displayed")
    public void applyVerifyFilter(@Named("filtertext") String filtertext)
            throws Exception
    {

        String[] filtertexts = filtertext.split(",");
        for (int i = 0; i < filtertexts.length; i++)
        {
            Filter.getInstance().setArrivingListFilter(filtertexts[i]);
        }
        boolean filtered = Filter.getInstance().isArrivingListFiltered(filtertext);
        Assert.assertEquals("verify data should be present for filtered text" + filtertext, true, filtered);

    }

    @Then("the filter text is not available in the card")
    public void verifyCardsDoNotHaveFilterText()
            throws IOException, InterruptedException
    {
        // TODO
    }

    @Then("Arriving list should display message indicating to refine filters")
    public void verifyNoFilterErrorMessageForArrivingListFilter()
            throws IOException, InterruptedException
    {
        Filter.getInstance().noFilterErrorMessageForArrivingListFilter();
    }
}
