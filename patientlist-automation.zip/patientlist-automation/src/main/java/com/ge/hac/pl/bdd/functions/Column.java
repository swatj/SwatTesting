package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class Column
{
    private static Logger   logger   = Logger.getLogger(Column.class);
    private SeleniumUtility selUtility;
    int                     columnWidthAfterDecrease;
    int                     columnWidthBeforeDecrease;
    int                     columnWidthBeforeIncrease;
    int                     columnWidthAfterIncrease;
    public static Column    instance = null;
    int                     columnPositionBeforeReOrder;

    private Column()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance();
        }
        catch (Exception e)
        {
            logger.error("Column() - error initializing web browser : ", e);
        }
    }

    public static Column getInstance()
    {
        if ( instance == null )
        {
            instance = new Column();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    public void reLoginPatientList(String userName, String password)
            throws IOException, InterruptedException
    {
        selUtility.elementClick("useroption");
        selUtility.elementClick("logout");
        Thread.sleep(3000);
        selUtility.navigateTo("Url");
        Thread.sleep(3000);
        selUtility.sendKeys("Username", userName);
        selUtility.sendKeys("Password", password);
        selUtility.elementClick("signin");
        Thread.sleep(5000);
    }

    public void columnReorderLeft(String sortingColumn)
            throws InterruptedException, IOException
    {
        Thread.sleep(2000);
        String columnName = null;
        String[] cannotSort =
        {
                "PACU bed (room)", "Patient", "Flags"
        };
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        Thread.sleep(5000);
        if ( !Arrays.asList(cannotSort).contains(sortingColumn) )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( columnName.equals(sortingColumn) )
                {
                    logger.debug("Column Name : " + columnName);
                    logger.debug("Column Postion: " + i);
                    int columnPositionBeforeReOrder = i;
                    WebElement ele = columnsTabList.get(i).findElement(By.tagName("div"));
                    String str = ele.getAttribute("id");
                    logger.debug("Column ID: " + str);
                    if ( columnPositionBeforeReOrder > 2 && columnPositionBeforeReOrder < 18 )
                    {
                        selUtility.findElementbyXpath("//*[@id='" + str + "']/span[1]/span/span/a/span/i").click();
                        // browser.findElement(By.xpath("//*[@id='" + str + "']/span[1]/span/span/a/span/i")).click();
                        Thread.sleep(3000);
                    }
                    else
                    {
                        logger.debug("User can't perform left order for this column at this posotion");
                    }

                    Thread.sleep(3000);
                }

            }
        }
        else
        {

            logger.debug("User can't perform re- order for this column");

        }
    }

    public void columnReorderRight(String sortingColumn)
            throws InterruptedException, IOException
    {
        Thread.sleep(5000);
        String columnName = null;
        String[] cannotSort =
        {
                "PACU bed (room)", "Patient", "Flags"
        };
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        Thread.sleep(3000);
        if ( !Arrays.asList(cannotSort).contains(sortingColumn) )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( columnName.equals(sortingColumn) )
                {
                    logger.debug("Column Name : " + columnName);
                    logger.debug("Column Postion before reorder : " + i);
                    int reOrderedColumnPosition = i;
                    WebElement ele = columnsTabList.get(i).findElement(By.tagName("div"));
                    String str = ele.getAttribute("id");
                    logger.debug("Column ID: " + str);
                    if ( reOrderedColumnPosition > 1 && reOrderedColumnPosition < 26 )
                    {
                        selUtility.findElementbyXpath("//*[@id='" + str + "']/span[4]/span/span/a/span/i").click();
                    }
                    else
                    {
                        logger.debug("User can't perform right order for this column at this posotion");
                    }

                    Thread.sleep(3000);
                }
            }
        }
        else
        {

            logger.debug("User can't perform re- order for this column");

        }
    }

    public void verifyDefaultSettings(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {

        List<WebElement> elestate = selUtility.findElements("radiobuttons");
        List<WebElement> column_name_in_columnpool = selUtility.findElements("column_name_in_columnpool");
        Map<String, String> ColumnNames = new HashMap<String, String>();

        for (int i = 0; i < elestate.size(); i++)
        {
            String checkStatus = "";

            String columnname = column_name_in_columnpool.get(i).getText().trim();
            if ( !("".equalsIgnoreCase(columnname)) )
            {

                if ( "dropdownitems icon-ico_circle_blank_sm".equalsIgnoreCase(elestate.get(i).getAttribute("class")
                        .toString()) )
                {
                    checkStatus = "UNCHECKED";
                }
                else
                {
                    checkStatus = "CHECKED";

                }

                ColumnNames.put(columnname, checkStatus);
            }
        }

        String column_name = null;
        String column_Status = null;
        for (Map<String, String> row : dataTable.getRows())
        {
            column_name = row.get("ColumnName");
            column_Status = row.get("status");

            if ( ColumnNames.containsKey(column_name) )
            {
                Assert.assertEquals("column name found", column_name, column_name);
                Assert.assertEquals(column_name + " column status matched", column_Status, ColumnNames.get(column_name));

            }
            else
            {
                Assert.assertEquals(column_name + " column name not found", column_name, ColumnNames.toString());
            }
        }
    }

    public void clickOnColumnConfig()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("togglebutton");

    }

    public void clickOnColumnReOrderConfig()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("reorderbutton");

    }

    public void selectDeselectColumnConfigurationSetting(ExamplesTable dataTable)
            throws IOException, InterruptedException

    {
        List<WebElement> elestate = selUtility.findElements("radiobuttons");
        List<WebElement> column_name_in_columnpool = selUtility.findElements("column_name_in_columnpool");
        Map<String, String> ColumnNames = new HashMap<String, String>();
        Map<String, WebElement> eleColumnNames = new HashMap<String, WebElement>();
        String checkStatus = "";
        for (int i = 0; i < elestate.size(); i++)
        {

            String columnname = column_name_in_columnpool.get(i).getText().trim();
            // System.out.println("Column name :"+columnname);
            if ( "dropdownitems icon-ico_circle_blank_sm".equalsIgnoreCase(elestate.get(i).getAttribute("class")
                    .toString()) )
            {
                checkStatus = "UNCHECKED";
            }
            else
            {
                checkStatus = "CHECKED";

            }

            ColumnNames.put(columnname, checkStatus);
            eleColumnNames.put(columnname, elestate.get(i));
        }

        String column_name = null;
        String column_Status = null;
        for (Map<String, String> row : dataTable.getRows())
        {
            column_name = row.get("ColumnName");
            column_Status = row.get("status");
            // System.out.println("Column name1 :"+column_name);
            // System.out.println("column_Status :"+column_Status);

            // check that actual column is found in column collection

            if ( ColumnNames.containsKey(column_name) )
            {
                Assert.assertEquals("column name found", column_name, column_name);

                if ( column_Status.equalsIgnoreCase(ColumnNames.get(column_name)) )
                {
                    // if column actual and expected status is same then do nothing
                }
                else
                {
                    // if column given and expected status is not same then click on element to change the status
                    eleColumnNames.get(column_name).click();
                    // after changing the state of column verify actual with expected
                    if ( "dropdownitems icon-ico_circle_blank_sm".equalsIgnoreCase(eleColumnNames.get(column_name)
                            .getAttribute("class").toString()) )
                    {
                        checkStatus = "UNCHECKED";
                    }
                    else
                    {
                        checkStatus = "CHECKED";

                    }
                    Assert.assertEquals(column_name + " column was ", column_Status, checkStatus);
                }
            }
            // given column does not found in column collection
            else
            {
                Assert.assertEquals(column_name + " column name not found", column_name, ColumnNames.toString());
            }
        }
    }

    public void clickOnEntireSiteConfigList()
            throws IOException, InterruptedException
    {
        selUtility.elementClick("radiobuttons");

    }

    public void verifyVisiblecolumn(ExamplesTable dataTable)
            throws IOException, InterruptedException

    {
        List<WebElement> eleTableHeader = selUtility.findElements("visibleColumns");
        Map<String, Integer> ColumnNames = new HashMap<String, Integer>();
        for (int i = 0; i < eleTableHeader.size(); i++)
        {
            String columnname = eleTableHeader.get(i).getText().trim();
            ColumnNames.put(columnname, i);
        }
        for (Map<String, String> row : dataTable.getRows())
        {
            String column_name = row.get("ColumnName");
            if ( ColumnNames.containsKey(column_name) )
            {
                Assert.assertEquals("column name found", column_name, column_name);
                Assert.assertEquals(column_name + " column is visible", "visible", "visible");

            }
            else
            {
                Assert.assertEquals(column_name + " column is not visible", "visible", "invisible");
            }
        }
    }

    public void verifyInvisableColumn(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        List<WebElement> eleTableHeader = selUtility.findElements("visibleColumns");
        Map<String, Integer> ColumnNames = new HashMap<String, Integer>();
        for (int i = 0; i < eleTableHeader.size(); i++)
        {
            String columnname = eleTableHeader.get(i).getText().trim();
            ColumnNames.put(columnname, i);
        }
        for (Map<String, String> row : dataTable.getRows())
        {
            String column_name = row.get("ColumnName");
            if ( ColumnNames.containsKey(column_name) )
            {

                Assert.assertEquals(column_name + " column is visible", "invisible", "visible");

            }
            else
            {
                Assert.assertEquals(column_name + " column is not visible", "invisible", "invisible");
            }
        }
    }

    public void clickIncWidthColumn(String column)
            throws IOException, InterruptedException
    {
        Thread.sleep(5000);
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        String columnName = null;
        if ( columnsTabList.size() > 0 )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( column.equals(columnName.trim()) )
                {
                    logger.debug("Column Name : " + columnName);
                    int columnWidthBeforeIncrease = Integer.parseInt(columnsTabList.get(i).getAttribute("style")
                            .replaceAll("[^0-9]", ""));
                    logger.debug("Width : " + columnWidthBeforeIncrease);
                    Filter.getInstance().clickReorderButton();
                    WebElement columnHeader_ClickableElement = columnsTabList.get(i).findElement(By.tagName("div"));
                    columnHeader_ClickableElement.click();
                    Thread.sleep(3000);
                    selUtility.elementClick("increaseColumnWidth");
                    Thread.sleep(2000);
                    selUtility.elementClick("increaseColumnWidth");
                    columnHeader_ClickableElement.click();
                    break;
                }
            }
        }
    }

    public void verifyColumnReOrder_Right(String reOrdeColumnName)
            throws IOException, InterruptedException
    {

        Thread.sleep(2000);
        String columnName = null;
        String[] cannotSort =
        {
                "PACU bed (room)", "Patient", "Flags"
        };
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        Thread.sleep(5000);
        if ( !Arrays.asList(cannotSort).contains(reOrdeColumnName) )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( columnName.equals(reOrdeColumnName) )
                {
                    logger.debug("Column Name : " + columnName);
                    logger.debug("Column Postion after reorder: " + i);
                    int columnPositionAfterReOrder = i;
                    if ( columnPositionAfterReOrder > columnPositionBeforeReOrder )
                    {
                        Assert.assertTrue(reOrdeColumnName + " column reordered to Right side",
                                columnPositionAfterReOrder > columnPositionBeforeReOrder);

                    }
                    break;
                }

            }
        }

    }

    public void verifyColumnReOrder_Left(String reOrdeColumnName)
            throws IOException, InterruptedException
    {

        Thread.sleep(2000);
        String columnName = null;
        String[] cannotSort =
        {
                "PACU bed (room)", "Patient", "Flags"
        };
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        Thread.sleep(5000);
        if ( !Arrays.asList(cannotSort).contains(reOrdeColumnName) )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( columnName.equals(reOrdeColumnName) )
                {
                    logger.debug("Column Name : " + columnName);
                    logger.debug("Column Postion after reorder: " + i);
                    int columnPositionAfterReOrder = i;
                    if ( columnPositionAfterReOrder < columnPositionBeforeReOrder )
                    {
                        Assert.assertTrue(reOrdeColumnName + " column reordered to Left side",
                                columnPositionAfterReOrder < columnPositionBeforeReOrder);

                    }
                    break;
                }

            }
        }

    }

    public void verifyColumnIncWidth(String column)
    {
        WebElement columnsTab = selUtility.findElementbyXpath("//*[@id='ptListHeader']/tr");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        String columnName = null;
        if ( columnsTabList.size() > 0 )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( column.equals(columnName.trim()) )
                {
                    logger.debug("Column Name : " + columnName);
                    columnWidthAfterIncrease = Integer.parseInt(columnsTabList.get(i).getAttribute("style")
                            .replaceAll("[^0-9]", ""));
                    logger.debug("Relogin Width : " + columnWidthAfterIncrease);
                    break;
                }
            }
        }
        Assert.assertTrue("Resized column configurations are not saved for increase in width",
                columnWidthAfterIncrease > columnWidthBeforeIncrease);
    }

    public void clickDecWidthColumn(String column)
            throws IOException, InterruptedException
    {
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        String columnName = null;
        if ( columnsTabList.size() > 0 )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( column.equals(columnName.trim()) )
                {
                    logger.debug("Column Name : " + columnName);
                    columnWidthBeforeDecrease = Integer.parseInt(columnsTabList.get(i).getAttribute("style")
                            .replaceAll("[^0-9]", ""));
                    logger.debug("Width : " + columnWidthBeforeDecrease);
                    WebElement columnHeader_ClickableElement = columnsTabList.get(i).findElement(By.tagName("div"));
                    columnHeader_ClickableElement.click();
                    Thread.sleep(5000);
                    selUtility.elementClick("decreaseColumnWidth");
                    Thread.sleep(3000);
                    selUtility.elementClick("decreaseColumnWidth");
                    Thread.sleep(3000);
                    columnHeader_ClickableElement.click();
                    Thread.sleep(3000);
                }
            }
        }
    }

    public void verifyColumnDecWidth(String column)
    {
        WebElement columnsTab = selUtility.findElementbyXpath("//*[@id='ptListHeader']/tr");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        String columnName = null;
        if ( columnsTabList.size() > 0 )
        {
            for (int i = 0; i < columnsTabList.size(); i++)
            {
                columnName = columnsTabList.get(i).getText();
                if ( column.equals(columnName.trim()) )
                {
                    logger.debug("Column Name : " + columnName);
                    columnWidthAfterDecrease = Integer.parseInt(columnsTabList.get(i).getAttribute("style")
                            .replaceAll("[^0-9]", ""));
                    logger.debug("Relogin Width : " + columnWidthAfterDecrease);
                }
            }
        }
        Assert.assertTrue("Resized column configurations are not saved for decrease in width",
                columnWidthBeforeDecrease > columnWidthAfterDecrease);
    }

    /**
     * @param sortingColumn
     */
    public void selectTheColumnToRightReorder(String sortingColumn)
            throws InterruptedException, IOException
    {
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        System.out.println("No of columns " + columnsTabList);
        Column.getInstance().columnReorderRight(sortingColumn);
    }

    /**
     * @param sortingColumn
     */
    public void selectTheColumnToLeftReorder(String sortingColumn)
            throws InterruptedException, IOException
    {
        WebElement columnsTab = selUtility.getElementByXPath("columnsheader");
        List<WebElement> columnsTabList = columnsTab.findElements(By.tagName("th"));
        logger.debug("Number of Columns Configured :" + columnsTabList.size());
        Column.getInstance().columnReorderLeft(sortingColumn);
    }

    public void clickOnColumnHeader(String columnNameToClick)
            throws Exception
    {
        // make column visible on grid
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(columnNameToClick);
        PatientListData.getInstance().makeColumnVisible(headerNames);
        List<WebElement> patientListCoulmnHeader = selUtility.findElements("visibleColumns");
        for (int i = 0; i < patientListCoulmnHeader.size(); i++)
        {
            String columnName = patientListCoulmnHeader.get(i).getText();

            if ( columnNameToClick.equals(columnName) )
            {

                patientListCoulmnHeader.get(i).click();
                // exit if column found
                break;
            }

        }

    }
}
