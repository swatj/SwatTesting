/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.UnreachableBrowserException;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class PatientList
{
    private static Logger      logger     = Logger.getLogger(PatientList.class);
    private SeleniumUtility    selUtility = null;
    private static PatientList instance   = null;

    private PatientList()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("PatientList.PatientList() - error initializing web browser.", e);
        }
    }

    public static PatientList getInstance()
    {
        if ( instance == null )
        {
            instance = new PatientList();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    /** Launch the browser and navigate to URL */
    public void launchPatientListURL(String Url)
            throws IOException, Exception
    {

        navigateTo(Url);

    }

    /** After Launching url to continue Continue to this website (not recommended). */
    public void clicktoContinue()
            throws IOException
    {

        if ( selUtility.elementDisplayedByXpath("override_Link") )
        {
            selUtility.elementClick("override_Link");

        }

    }

    /* navigate to URL */
    public void navigateTo(String Url)
            throws IOException, Exception
    {

        selUtility.navigateTo("Url");
        logger.debug("PatientList:NavigateTo:Navigate to =" + PropertyFileHelper.getProjectProperty("Url"));
    }

    /* Enter username and apssword */
    public void enterCredentials(String userName, String password)
            throws IOException
    {
        // PatientList.getInstance().waitForElementToAppear("signin", Constants.SIGNIN_BUTTON_LABEL,
        // Constants.HIGH_TIMEOUT);
        selUtility.sendKeysWithWait("Username", userName);
        selUtility.sendKeysWithWait("Password", password);
        logger.debug("PatientList:EnterCredentials:enter usernmae =" + userName + " password=" + password);
    }

    /* click on sign in */
    public void clickOnlogin()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("signin");
        logger.debug("PatientList:clickOnlogin: click on sign in button");
    }

    /* get error message from login screen */
    public String getLoginErrorMessage(String message)
            throws IOException, InterruptedException
    {
        String ErrorMessage;
        PatientList.getInstance().waitForElementToAppear("LoginErrormessage", message, Constants.HIGH_TIMEOUT);
        logger.debug("getLoginErrorMessage: return invalid login message");
        ErrorMessage = selUtility.getElementByXPath("LoginErrormessage").getText().trim();
        logger.debug("PatientList:getLoginErrorMessage: get the error message from login screen");
        return ErrorMessage;
    }

    // verify signin button enabled or not
    public String verifySigninButtonEnabled()
            throws IOException, InterruptedException
    {
        String bFound = "false";
        List<WebElement> searchButtonEnabled = selUtility.findElements("signin");

        try
        {
            if ( searchButtonEnabled.get(0).getAttribute("disabled") != null )
            {
                bFound = searchButtonEnabled.get(0).getAttribute("disabled");
            }

        }
        catch (Exception e)
        {
            logger.error("Exception in finding Sign in disabled status", e);
        }

        return bFound;
    }

    /* get error message after login screen */
    public String getErrorMessage(String message)
            throws IOException, InterruptedException
    {
        String ErrorMessage;
        PatientList.getInstance().waitForElementToAppear("warningMessage", message, Constants.HIGH_TIMEOUT);
        logger.debug("getErrorMessage: return invalid login message");
        ErrorMessage = selUtility.getElementByXPath("warningMessage").getText().trim();
        logger.debug("getErrorMessage: get the error message after login screen");
        return ErrorMessage;
    }

    /* get alert dialog screen after big date range search */
    public String getBigDateRangeAlert(String message)
            throws IOException, InterruptedException
    {
        String ErrorMessage;
        PatientList.getInstance().waitForElementToAppear("big_date_range_alert_message", message,
                Constants.HIGH_TIMEOUT);
        logger.debug("getErrorMessage: alert message not appeared");
        ErrorMessage = selUtility.getElementByXPath("big_date_range_alert_message").getText().trim();
        logger.debug("getErrorMessage: get the alert dialog after big date search");
        return ErrorMessage;
    }

    /* get error message for date validation */
    public String getDateErrorMessage(String message)
            throws IOException, InterruptedException
    {
        List<WebElement> eleList = SeleniumUtility.getInstance().getElementsByXPath("warningMessage");
        String ErrorMessage = eleList.get(eleList.size() - 1).getText().trim();
        logger.debug("PatientList:getDateErrorMessage: " + ErrorMessage);
        return ErrorMessage;

    }

    /* get loggedin User Name from home screen */
    public String getloggedinUserName()
            throws IOException, InterruptedException
    {
        logger.debug("PatientList:getloggedinUserName: return logged in UserName");
        return selUtility.getElementByXPath("loggedinUserName").getText();
    }

    /* verify that after successful login,the home screen displayed without any error */
    public void checkHomePage()
            throws InterruptedException
    {
        Assert.assertEquals("The browser title should be same", Constants.BROWSERTITLE, selUtility.getBrowserTitle());
        logger.debug("PatientList:checkHomePage: check Home Page loaded");
    }

    /* click on logout */
    public void clickOnlogout()
            throws IOException, InterruptedException
    {
        selUtility.elementClick("useroption");
        selUtility.elementClick("logout");
        logger.debug("PatientList:clickOnlogout: click on logout");
    }

    /* close browser */
    public void closePatientListBrowser()
    {
        selUtility.closeBrowser();
        logger.debug("PatientList:closePatientListBrowser: close browser");
    }

    // wait for logged in user name to be appear on UI
    public boolean waitForElementToAppear(String objectName, String textTobePresent, int timeout)
            throws IOException
    {
        return selUtility.waitTextToBePresentInElement(objectName, textTobePresent, timeout);
    }

    // get Error Message after login
    public String getErrorMessage()
            throws IOException, InterruptedException
    {
        Thread.sleep(6000);
        String ErrorMessage;
        ErrorMessage = selUtility.getElementByXPath("error_message").getText().trim();
        logger.debug("getErrorMessage: get the error message from login screen");
        return ErrorMessage;
    }

    // capture full desktop screenshots
    public String captureScreenShot(String userDir, String fileName)
            throws IOException
    {
        return selUtility.captureScreenShot(userDir, fileName);

    }

    public String getCurrentDateLable()
            throws IOException
    {
        return selUtility.get_text("currentDateLable");
    }

    public String getSearchDate(String controlId, String controlClass, int index)
    {
        String dateValue = null;
        String getDateScriptById = "return document.getElementById('" + controlId + "').value";
        String getDateScriptByClass = "return document.getElementsByClassName(\"" + controlClass + "\")[" + index
                + "].value";

        /*
         * Try to get the value of the element by ID. If not found, it will return null.
         * In that case try to get the value based on class name
         */
        dateValue = (String) selUtility.executeJavaScript(getDateScriptById);
        if ( dateValue == null )
        {
            dateValue = (String) selUtility.executeJavaScript(getDateScriptByClass);
        }

        return dateValue;
    }

    /**
     * @return
     */
    public String getFromDateValue()
    {
        return getSearchDate("fromDateVal", "ng-valid ng-dirty", 0);
    }

    /**
     * @return
     */
    public String getToDateValue()
    {
        return getSearchDate("fromDateVal", "ng-valid ng-dirty", 1);
    }

    public String getFromDate()
            throws IOException
    {
        String fromdate = null;
        try
        {
            fromdate = (String) selUtility.executeJavaScript("return document.getElementById('fromDateVal').value");
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.PatientList.getFromDate()", e);
            fromdate = (String) selUtility
                    .executeJavaScript("return document.getElementsByClassName(\"ng-valid ng-dirty\")[0].value");
        }
        return fromdate;

    }

    public String getToDate()
            throws IOException
    {
        String todate = null;
        try
        {
            todate = (String) selUtility.executeJavaScript("return document.getElementById('toDateVal').value");
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.PatientList.getToDate()", e);
            todate = (String) selUtility
                    .executeJavaScript("return document.getElementsByClassName(\"ng-valid ng-dirty\")[1].value");
        }
        return todate;
    }

    public void clickOnSearch()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("search_button");
        logger.debug("PatientList:clickOnSearch: click on search button");

    }

    /* To click on the RefineSearch button on the Big date range message */
    public void clickOnRefineSearch()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("refine_search");
        logger.debug("PatientList:clickOnRefineSearch: click on Refine search button");

    }

    /* To click on the continue button on the Big date range message */
    public void clickOnContinue()
            throws IOException, InterruptedException
    {

        selUtility.elementClick("continue");
        logger.debug("PatientList:clickOnContinue: click on Continue button");

    }

    public void setDateCalender(String dateControl, String dateToSet)
            throws Exception

    {
        String retrivedDate = getCurrentPastFutureDate(dateToSet);
        switch (dateControl)
        {
            case "from":
                String actFromDate = getFromDate();
                if ( !actFromDate.equalsIgnoreCase(retrivedDate) )
                {
                    // instead of selecting date from caledar we directly stting to from and to text boxes
                    // selUtility.elementClick("icon_fromdate");
                    // changeDateInCalender(retrivedDate);
                    selUtility.sendKeys("fromDateTextbox", retrivedDate);

                }
                break;

            case "to":
                String actToDate = getToDate();
                if ( !actToDate.equalsIgnoreCase(retrivedDate) )
                {
                    // selUtility.elementClick("icon_todate");
                    // changeDateInCalender(retrivedDate);
                    selUtility.sendKeys("toDateTextbox", retrivedDate);

                }
                break;
        }

    }

    public String getSystemDate()
            throws IOException
    {
        DateFormat dateFormat = new SimpleDateFormat(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }

    public String getCurrentPastFutureDate(String date)
            throws Exception
    {
        String retriveDate = null;
        switch (date.toLowerCase())
        {
            case "now":
            case "current":
            {
                retriveDate = getSystemDate();
                break;
            }
            case "future":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("FUTURE_DATE")));
                break;
            case "past":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("PAST_DATE")));
                break;
            case "pastmonth":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("PAST_DATE_MORE_THEN30DAYS")));
                break;
            case "futuremonth":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("FUTURE_DATE_MORE_THEN30DAYS")));
                break;
            case "tomorrow":
                retriveDate = getCustomiseDate(getSystemDate(), "day", 1);
                break;
            case "yesterday":
                retriveDate = getCustomiseDate(getSystemDate(), "day", -1);
                break;
            case "blank":
                retriveDate = "";
                break;
            case "tooutsidecache":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("To_CACHE_RANGE")));
                retriveDate = getCustomiseDate(retriveDate, "day", +1);
                break;
            case "fromoutsidecache":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("FROM_CACHE_RANGE")));
                retriveDate = getCustomiseDate(retriveDate, "day", -1);
                break;
        }

        return retriveDate;
    }

    private String getCustomiseDate(String givenDate, String type, int number)
            throws Exception
    {
        DateFormat dateFormat = new SimpleDateFormat(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
        Date parsedDate = dateFormat.parse(givenDate);

        Calendar cal = Calendar.getInstance();
        cal.setTime(parsedDate);

        switch (type.toLowerCase())
        {
            case "day":
                cal.add(Calendar.DATE, number);
                break;
            case "month":
                cal.add(Calendar.MONTH, number);
                break;
            case "year":
                cal.add(Calendar.YEAR, number);
                break;
        }
        return dateFormat.format(cal.getTime());
    }

    // get alert text
    public String getAlertText()
            throws InterruptedException
    {
        Thread.sleep(1000); // wait for Alert to come
        return selUtility.getAlertText();

    }

    // perform action on alert
    public void performActionOnAlert(String actionToPerform)
    {
        selUtility.performActionOnAlert(actionToPerform);

    }

    // Verify column displayed or not
    public boolean verifyColumnDisplay(String columnName)
            throws Exception
    {

        boolean flag = false;
        List<WebElement> columnList = selUtility.findElements("visibleColumns");
        for (int i = 0; i < columnList.size(); i++)
        {
            String actualcolumnName = columnList.get(i).getText();
            if ( columnName.equalsIgnoreCase(actualcolumnName) )
            {
                flag = true;
                break;

            }
        }
        logger.debug("PatientList:verifyColumnDisplay: verify column " + columnName + " is display? " + flag);
        return flag;
    }

    // add column by clicking on configuration button so that column is visible on screen
    public void addColumnToColumnList(String columnName)
            throws Exception
    {
        // to open popup
        if ( !selUtility.elementDisplayedByXpath("radiobuttons") )
        {
            selUtility.elementClick("togglebutton");
        }
        List<WebElement> radioList = selUtility.findElements("radiobuttons");
        List<WebElement> column_name_in_columnpool = selUtility.findElements("column_name_in_columnpool");
        for (int i = 0; i < radioList.size(); i++)
        {
            if ( columnName.equalsIgnoreCase(column_name_in_columnpool.get(i).getText().trim()) )
            {
                if ( "dropdownitems icon-ico_circle_blank_sm".equalsIgnoreCase(radioList.get(i).getAttribute("class")) )
                {
                    radioList.get(i).click();
                    break;
                }
            }

        }
        // to close the popup
        selUtility.elementClick("togglebutton");
        logger.debug("PatientList:addColumnToColumnList: add column " + columnName + " from configuration button");
    }

    public void removeColumnFromColumnList(String columnName)
            throws Exception
    {
        // to open popup
        if ( !selUtility.elementDisplayedByXpath("radiobuttons") )
        {
            selUtility.elementClick("togglebutton");
        }
        List<WebElement> radioList = selUtility.findElements("radiobuttons");
        List<WebElement> column_name_in_columnpool = selUtility.findElements("column_name_in_columnpool");
        for (int i = 0; i < radioList.size(); i++)
        {

            if ( columnName.equalsIgnoreCase(column_name_in_columnpool.get(i).getText().trim()) )
            {

                if ( "dropdownitems  icon-ico_ok_circle_sm".equalsIgnoreCase(radioList.get(i).getAttribute("class"))
                        || "dropdownitems icon-ico_ok_circle_sm"
                                .equalsIgnoreCase(radioList.get(i).getAttribute("class")) )

                {
                    radioList.get(i).click();
                    break;

                }
            }
        }

        // to close popup

        selUtility.elementClick("togglebutton");

    }

    public void openURL(String url)
    {
        selUtility.openUrl(url);
    }

    // this function is used to change date in date picker

    public void changeDateInCalender(String expDateToSet)
            throws Exception

    {
        if ( "".equalsIgnoreCase(expDateToSet) )
        {
            selUtility.sendKeys("fromDateTextbox", expDateToSet);
            selUtility.sendKeys("toDateTextbox", expDateToSet);
        }
        else
        {
            DateFormat dateFormat = new SimpleDateFormat(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
            Date expDate = dateFormat.parse(expDateToSet);
            Calendar cal = Calendar.getInstance();
            cal.setTime(expDate);
            int day = cal.get(Calendar.DATE);

            // get expected month
            int expMonth = cal.get(Calendar.MONTH);

            // get date selected on calendar
            String calenderDate = selUtility.findElements("calendarmonthyear").get(0).getText();
            int currentCalenderMonth = -1;

            String[] monthNames =
            {
                    "January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
                    "November", "December"
            };

            // get month number of month displayed on calendar
            for (int i = 0; i < monthNames.length; i++)
            {
                if ( calenderDate.contains(monthNames[i]) )
                {
                    currentCalenderMonth = i;
                }
            }

            while (currentCalenderMonth != expMonth)
            {
                if ( expMonth < currentCalenderMonth )
                {
                    // click on back arrow to go to expected month

                    selUtility.elementClick("datePickerLeftArrow");
                    currentCalenderMonth = currentCalenderMonth - 1;
                }

                else
                {
                    // click on front arrow to go to expected month

                    selUtility.elementClick("datePickerRightArrow");
                    currentCalenderMonth = currentCalenderMonth + 1;
                }
            }

            // select day from calendar
            List<WebElement> dayList = selUtility.findElements("day_fromCalender");
            for (int i = 0; i < dayList.size(); i++)
            {
                if ( day == Integer.parseInt(dayList.get(i).getText()) )
                {
                    dayList.get(i).click();
                    break;
                }
            }
        }
    }

    // get warning message text
    public String getDateWarningMessageText()
            throws InterruptedException, IOException
    {
        waitForElementToAppear("warningMessage", "date", Constants.HIGH_TIMEOUT);
        return selUtility.get_text("warningMessage");

    }

    // return background color of active site
    public String getBackgroundColorOfActiveSite()
            throws IOException, InterruptedException
    {

        Site.getInstance().clickAddSite();
        List<WebElement> activeSite = selUtility.findElements("selected_site");
        // move to one level up in html
        WebElement active_Site = activeSite.get(0).findElement(By.xpath(".."));

        Site.getInstance().clickAddSite();
        return getBackgroundColor(active_Site);
    }

    // return background color of site,department and date controls Container

    public String getBackgroundColorOfHeaderContainer()
            throws IOException, InterruptedException
    {
        List<WebElement> element = selUtility.findElements("add_site");
        // move to one level up in html
        WebElement parentElement = element.get(0).findElement(By.xpath(".."));
        // move to one level up in html
        WebElement parentElement1 = parentElement.findElement(By.xpath(".."));
        return getBackgroundColor(parentElement1);
    }

    // return text color of active site
    public String getTextColorOfActiveSite()
            throws IOException, InterruptedException
    {
        List<WebElement> activeSite = selUtility.findElements("active_site");
        // move to one level up in html
        WebElement active_Site = activeSite.get(0).findElement(By.xpath(".."));
        return getTextColor(active_Site);
    }

    // Verify background and text color of inactive site
    public void verifyInactiveSiteBGAndTextColor(String expBGColor, String expTextColor)
            throws IOException, InterruptedException
    {
        String actualBGColorOfInactiveSites, actualTextColorOfInactiveSites;
        List<WebElement> activeSite = selUtility.findElements("active_site");
        List<WebElement> inActiveSiteList = selUtility.findElements("sites_from_sites_tab");
        WebElement inActiveSiteParent = null;
        for (int i = 0; i < inActiveSiteList.size(); i++)
        {
            // if site is not active site then verify the background color and text color
            if ( !inActiveSiteList.get(i).getText().equals(activeSite.get(0).getText()) )
            {
                // find out parent element which has background color.
                WebElement inActiveSite = inActiveSiteList.get(i);
                inActiveSiteParent = inActiveSite;
                for (int j = 0; j <= 4; j++)
                {
                    inActiveSiteParent = inActiveSiteParent.findElement(By.xpath(".."));
                }

                actualBGColorOfInactiveSites = getBackgroundColor(inActiveSiteParent);
                actualTextColorOfInactiveSites = getTextColor(inActiveSiteList.get(i));
                Assert.assertEquals("Verify background color of Inactive tab " + inActiveSiteList.get(i).getText(),
                        expBGColor, actualBGColorOfInactiveSites);
                Assert.assertEquals("Verify text color of Inactive tab " + inActiveSiteList.get(i).getText(),
                        expTextColor, actualTextColorOfInactiveSites);
            }
        }
    }

    // return container of passed element
    public String getContainer(String objectName, int level)
            throws IOException, InterruptedException
    {
        List<WebElement> element = selUtility.findElements(objectName);
        WebElement parentElement = element.get(0).findElement(By.xpath(".."));
        for (int i = 0; i < level; i++)
        {
            parentElement = parentElement.findElement(By.xpath(".."));
        }
        return (parentElement.getAttribute("class"));
    }

    // return background color of and patientList container
    public String getBGColorOfDeptPatListContainer()
            throws IOException, InterruptedException
    {
        WebElement element = selUtility
                .findElementbyXpath("//section[@class='" + Constants.DEPARTMENT_CONTAINER + "']");
        return getBackgroundColor(element);
    }

    // return text color of passed element
    public String getTextColor(WebElement element)
    {

        // get text color in rgba format
        String textColor = element.getCssValue("color");
        // convert text value into hexadecimal value
        String[] hexValue = textColor.replace("rgba(", "").replace(")", "").split(",");
        int hexValueR = Integer.parseInt(hexValue[0].trim());
        int hexValueG = Integer.parseInt(hexValue[1].trim());
        int hexValueB = Integer.parseInt(hexValue[2].trim());
        // convert into string
        return String.format(Constants.COLOR_FORMAT, hexValueR, hexValueG, hexValueB);

    }

    // return background color of passed element
    public String getBackgroundColor(WebElement element)
    {

        // get background color in rgba format
        String backgroundColor = element.getCssValue("background-color");
        // convert text value into hexadecimal value
        String[] hexValue = backgroundColor.replace("rgba(", "").replace(")", "").split(",");
        int hexValueR = Integer.parseInt(hexValue[0].trim());
        int hexValueG = Integer.parseInt(hexValue[1].trim());
        int hexValueB = Integer.parseInt(hexValue[2].trim());
        // convert into string
        return String.format(Constants.COLOR_FORMAT, hexValueR, hexValueG, hexValueB);

    }   
    
    
 // return text color of passed element
    public String getDeptColor(WebElement element)
    {

        // get text color in rgba format
        String textColor = element.getCssValue("border-bottom-color");
        // convert text value into hexadecimal value
        String[] hexValue = textColor.replace("rgba(", "").replace(")", "").split(",");
        int hexValueR = Integer.parseInt(hexValue[0].trim());
        int hexValueG = Integer.parseInt(hexValue[1].trim());
        int hexValueB = Integer.parseInt(hexValue[2].trim());
        // convert into string
        return String.format(Constants.COLOR_FORMAT, hexValueR, hexValueG, hexValueB);

    }


    // verify minimum width of department tab and check text aligned center
    public void verifyDepartmentWidthAndText(String minWidth, String textAlign)
            throws IOException, InterruptedException
    {
        String actMinWidth, actTextAlign;
        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");
        for (int i = 0; i < deptList.size(); i++)
        {
            WebElement actualElement = deptList.get(i).findElement(By.xpath(".."));
            actMinWidth = actualElement.getCssValue("min-width");
            actTextAlign = actualElement.getCssValue("text-align");
            Assert.assertEquals("Verify minimum width of " + deptList.get(i).getText(), minWidth, actMinWidth);
            Assert.assertEquals("Verify text color of Inactive tab " + deptList.get(i).getText(), textAlign,
                    actTextAlign);

        }
    }

    // change and set date in from date field
    public void changeAndSetDateInFrom(String fieldToChange, String valueToChange)
            throws IOException, InterruptedException
    {
        String replacedDate = getReplacedDate(fieldToChange, valueToChange);
        logger.debug("PatientList:changeAndSetDateInFrom:set invalid date in from field=" + replacedDate);
        Thread.sleep(3000);
        selUtility.sendKeys("fromDateTextbox", replacedDate);
    }

    // this function replace day,month or year in passed date
    public String getReplacedDate(String fieldToChange, String valueToChange)
            throws IOException
    {

        Calendar cal = Calendar.getInstance();

        String replaceString = PropertyFileHelper.getProjectProperty("DATE_FORMAT");
        switch (fieldToChange.toLowerCase())
        {
            case "day":
                if ( valueToChange.matches("\\d+") )
                {
                    valueToChange = String.format("%02d", Integer.parseInt(valueToChange));
                }
                replaceString = replaceString.replace("dd", String.valueOf(valueToChange));
                break;
            case "month":
                if ( valueToChange.matches("\\d+") )
                {
                    valueToChange = String.format("%02d", Integer.parseInt(valueToChange));
                }

                replaceString = replaceString.replace("MM", String.valueOf(valueToChange));
                break;
            case "year":
                replaceString = replaceString.replace("yyyy", String.valueOf(valueToChange));
                break;
        }

        replaceString = replaceString.replace("MM", String.format("%02d", cal.get(Calendar.MONTH) + 1));
        replaceString = replaceString.replace("yyyy", String.valueOf(cal.get(Calendar.YEAR)));
        replaceString = replaceString.replace("dd", String.format("%02d", cal.get(Calendar.DATE)));

        return replaceString;
    }

    // click on today link to set today's date
    public void clickTodayLink()
            throws IOException, InterruptedException
    {
        if ( !Site.getInstance().verifyCalendarOpen() )
        {
            selUtility.elementClick("icon_fromdate");
        }
        selUtility.elementClick("todayLink");
        Thread.sleep(100);//waitForElementToAppear("search_button", "Go", Constants.HIGH_TIMEOUT);
    }

    // return text color of Logged In User name
    public String getTextColorOfLoggedInUserName()
            throws IOException, InterruptedException
    {
        List<WebElement> element = selUtility.findElementsUsingDynamicPath("loggedinUserName", "//span");

        return getTextColor(element.get(0));
    }

    // return font of Logged In User name
    public String getFontOfLoggedInUserName()
            throws IOException, InterruptedException
    {
        List<WebElement> element = selUtility.findElementsUsingDynamicPath("loggedinUserName", "//span");

        String fontName = element.get(0).getCssValue("font-family");
        String[] fontNames = fontName.split(",");
        return fontNames[0].replace("\"", "");

    }

    // return font of Logged In User name
    public String getBackgroundColorOfLoggedInUserName()
            throws IOException, InterruptedException
    {
        List<WebElement> element = selUtility.findElements("loggedinUserName");

        return getBackgroundColor(element.get(0));

    }
    
    /**
     * @param expectedDeptList
     * @return
     */
    public void verifyDeptColor(String deptType)
            throws IOException, InterruptedException
    {  
        if(deptType.equals("periop")){
        	List<WebElement> periopDeptList = selUtility.findElements("periop_dept_from_depts_tab");
        	for (int i = 0; i < periopDeptList.size(); i++)
            {         		
        		logger.debug("Periop department indicator color : "+periopDeptList.get(i).getAttribute("class"));
        		Assert.assertTrue("Verify Periop department indicator color ", periopDeptList.get(i).getAttribute("class").contains(Constants.PERIOP_DEPTS_INDICATOR_COLOR));
                
            }
        }
        else if(deptType.equals("ICU")){
        	List<WebElement> icuDeptList = selUtility.findElements("icu_dept_from_depts_tab");        	
        	for (int i = 0; i < icuDeptList.size(); i++)
            {         
        		logger.debug("Periop department indicator color : "+icuDeptList.get(i).getAttribute("class"));
        		Assert.assertTrue("Verify ICU department indicator color ", icuDeptList.get(i).getAttribute("class").contains(Constants.ICU_DEPTS_INDICATOR_COLOR));
               
            }
        }
       
    }


    public void browserRestart()
    {
        // driver.navigate().refresh();

        try
        {
            PatientList.getInstance().closePatientListBrowser();
            PatientList.closeInstance();
            Site.closeInstance();
            Column.closeInstance();
            PatientListData.closeInstance();
            Filter.closeInstance();
            Popover.closeInstance();
            UpdateDate.closeInstance();
            Sorting.closeInstance();
            AboutBox.closeInstance();
            SeleniumUtility.closeInstance();
            SeleniumUtility.getInstance().navigateTo("Url");
            PatientList.getInstance().clicktoContinue();
        }
        catch (UnreachableBrowserException e)
        {
            logger.error("UnreachableBrowserException in com.ge.hac.pl.bdd.functions.PatientList.browserRestart()", e);
        }
        catch (WebDriverException e)
        {
            logger.error("WebDriverException in com.ge.hac.pl.bdd.functions.PatientList.browserRestart()", e);
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.PatientList.browserRestart()", e);
        }

    }

    /**
     * 
     */
    public void resizeWindow()
    {
        selUtility.resizeWindow();

    }

}
