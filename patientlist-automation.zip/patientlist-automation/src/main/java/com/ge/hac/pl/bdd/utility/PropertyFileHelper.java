/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.commons.io.input.BOMInputStream;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * 
 * @author 305014106
 * 
 */
public class PropertyFileHelper
{
    private static final Logger     logger = Logger.getLogger(PropertyFileHelper.class);

    private static final Properties objectIdentifierProperties;
    private static final Properties projectProperties;
    private static final Properties sqlscriptsProperties;

    /*
     * ****************************************************************
     * Initialize the static class members. Load the property files.
     * ***************************************************************
     */

    static
    {
        objectIdentifierProperties = new Properties();
        InputStream objectIdentifierStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("com/ge/hac/pl/bdd/properties/ObjectIdentifier.properties");

        projectProperties = new Properties();
        InputStream projectPropertiesStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("com/ge/hac/pl/bdd/properties/Project.properties");

        sqlscriptsProperties = new Properties();
        InputStream sqlscriptsPropertiesStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("com/ge/hac/pl/bdd/properties/SqlScripts.properties");

        try
        {
            objectIdentifierProperties.load(objectIdentifierStream);
            projectProperties.load(projectPropertiesStream);
            sqlscriptsProperties.load(sqlscriptsPropertiesStream);
        }
        catch (IOException e)
        {
            logger.error("PropertyFileHelper : static block error.", e);
        }
        finally
        {
            if ( objectIdentifierStream != null )
            {
                try
                {
                    objectIdentifierStream.close();
                }
                catch (IOException e)
                {
                    logger.error("PropertyFileHelper : static block error.", e);
                }
            }

            if ( projectPropertiesStream != null )
            {
                try
                {
                    projectPropertiesStream.close();
                }
                catch (IOException e)
                {
                    logger.error("PropertyFileHelper : static block error.", e);
                }
            }

            if ( sqlscriptsPropertiesStream != null )
            {
                try
                {
                    sqlscriptsPropertiesStream.close();
                }
                catch (IOException e)
                {
                    logger.error("PropertyFileHelper : static block error.", e);
                }
            }
        }
    }

    public static String getObjectIdentifier(String key)
    {
        return objectIdentifierProperties.getProperty(key);
    }

    public static String getProjectProperty(String key)
    {
        return projectProperties.getProperty(key);
    }

    public static String getSqlScripts(String key)
    {
        return sqlscriptsProperties.getProperty(key);
    }

    public static String getlanguageProperty(String filePath, String key)
    {
        String propertyValue = "";
        try

        {
            InputStreamReader reader = new InputStreamReader(
                    new BufferedInputStream(new BOMInputStream(new FileInputStream(filePath))), "UTF-8");
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);

            // get a String from the JSON object
            propertyValue = (String) jsonObject.get(key);
            System.out.println("locale=" + filePath + " key =" + key + " value=" + propertyValue);

        }
        catch (FileNotFoundException ex)
        {
            logger.error("FileNotFoundException in com.ge.hac.pl.bdd.utility.PropertyFileHelper.getlanguageProperty()",
                    ex);

        }
        catch (IOException ex)
        {
            logger.error("IOException in com.ge.hac.pl.bdd.utility.PropertyFileHelper.getlanguageProperty()", ex);
        }
        catch (ParseException ex)
        {
            logger.error("ParseException in com.ge.hac.pl.bdd.utility.PropertyFileHelper.getlanguageProperty()", ex);
        }
        catch (NullPointerException ex)
        {
            logger.error("NullPointerException in com.ge.hac.pl.bdd.utility.PropertyFileHelper.getlanguageProperty()",
                    ex);
        }

        return propertyValue;
    }

    public static JSONObject getLocaleFileAsJson(String filePath)
    {

        JSONObject localeFileJson = null;
        try
        {
            InputStreamReader reader = new InputStreamReader(
                    new BufferedInputStream(new BOMInputStream(new FileInputStream(filePath))), "UTF-8");
            JSONParser jsonParser = new JSONParser();
            localeFileJson = (JSONObject) jsonParser.parse(reader);

        }
        catch (Exception e)
        {
            logger.error("Exception in getLocaleFileAsJson (" + filePath + ")", e);
        }

        return localeFileJson;
    }
}
