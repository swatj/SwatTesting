/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

import java.util.List;

/**
 * @author 305014106
 *
 */
public class HospitalParams
{
    String       name;
    String       abbreviation;
    String       description;
    String       mapcode;
    String       mapname;
    String       id;
    String       code;
    List<String> departmentList;

    /**
     * 
     */
    public HospitalParams()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param name
     * @param abbreviation
     * @param description
     * @param mapcode
     * @param mapname
     * @param id
     * @param code
     * @param departmentList
     */
    public HospitalParams(String name, String abbreviation, String description, String mapcode, String mapname,
            String id, String code, List<String> departmentList)
    {
        super();
        this.name = name;
        this.abbreviation = abbreviation;
        this.description = description;
        this.mapcode = mapcode;
        this.mapname = mapname;
        this.id = id;
        this.code = code;
        this.departmentList = departmentList;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the abbreviation
     */
    public String getAbbreviation()
    {
        return this.abbreviation;
    }

    /**
     * @param abbreviation the abbreviation to set
     */
    public void setAbbreviation(String abbreviation)
    {
        this.abbreviation = abbreviation;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return this.description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the mapcode
     */
    public String getMapcode()
    {
        return this.mapcode;
    }

    /**
     * @param mapcode the mapcode to set
     */
    public void setMapcode(String mapcode)
    {
        this.mapcode = mapcode;
    }

    /**
     * @return the mapname
     */
    public String getMapname()
    {
        return this.mapname;
    }

    /**
     * @param mapname the mapname to set
     */
    public void setMapname(String mapname)
    {
        this.mapname = mapname;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return this.id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode()
    {
        return this.code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code)
    {
        this.code = code;
    }

    /**
     * @return the departmentList
     */
    public List<String> getDepartmentList()
    {
        return this.departmentList;
    }

    /**
     * @param departmentList the departmentList to set
     */
    public void setDepartmentList(List<String> departmentList)
    {
        this.departmentList = departmentList;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "HospitalParams [name=" + name + ", abbreviation=" + abbreviation + ", description=" + description
                + ", mapcode=" + mapcode + ", mapname=" + mapname + ", id=" + id + ", code=" + code
                + ", departmentList=" + departmentList + "]";
    }

}
