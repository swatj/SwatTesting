/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Sorting;

/**
 * @author Selvam M
 * 
 */
public class DefaultSortingSteps
{

    @Then("PatientList should display sorted data on <column> with <sorttype>")
    public void verifySortedColumnData(@Named("sorttype") String sortType, @Named("column") String columnToSort)
            throws Exception
    {
        boolean bStatus = Sorting.getInstance().verifySortedColumnData(columnToSort, sortType);
        Assert.assertEquals("Verify sorted " + sortType + " order for " + columnToSort + " column", true, bStatus);
    }
}
