package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.ge.hac.ca.common.info.ServerInfoSingleton;
import com.ge.hac.ca.common.interfaces.PropertySessionRemote;
import com.ge.hac.ca.common.util.ServiceLocator;
import com.ge.hac.common.ea.dto.configuration.LocaleConfig;
import com.ge.hac.pl.bdd.functions.ArrivingListCard;
import com.ge.hac.pl.bdd.functions.Card;
import com.ge.hac.pl.bdd.functions.Column;
import com.ge.hac.pl.bdd.functions.Configurator;
import com.ge.hac.pl.bdd.functions.DbAndServiceExecutor;
import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.functions.PopoverArrivingListCard;
import com.ge.hac.pl.bdd.functions.PopoverCard;
import com.ge.hac.pl.bdd.functions.SidePanel;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.LocaleParams;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.RestParams;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;
import com.ge.hac.pl.bdd.utility.ServiceHandler;

/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/**
 * @author pandharinathj
 * 
 */
public class LocalizationSteps
{
    private static Logger       logger                   = Logger.getLogger(LocalizationSteps.class);
    private static String       Language_Locale          = "en_US";
    private static String       currentDateFormat        = "MM/dd/yyyy";
    private static String       statusDurationKey        = "periopstatuslos.column.name";
    private static String       scheduleProcedureDateKey = "scheduled.procedure.date.column.name";
    private static String       patientInfoKey           = "patient.column.name";
    private static String       patientIDKey             = "patientid.column.name";
    private static String       dateWarningMesKey        = "warning.dateformat.ui.item.label";

    private static LocaleConfig localeConfigResponseEntity;
    private static LocaleParams originalLocaleConfig;

    // Only locale - new
    @When("the service.getLocaleConfig url is invoked: $dataTable")
    public static void invokeGetRestEndpoint(ExamplesTable dataTable)
    {
        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);

        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
                restParams.getRestEndpoint(), restParams.getQueryParams(), restParams.getPostEntity());

        LocalizationSteps.localeConfigResponseEntity = response.readEntity(LocaleConfig.class);
        copyOriginalLocaleConfigs();
        logger.debug("Current locale: " + LocalizationSteps.localeConfigResponseEntity.toString());

        Assert.assertEquals("service.getLocaleConfig response is OK", HttpResponseCodes.SC_OK, response.getStatus());
    }

    // Only locale - new
    @Then("the locale is updated: $dataTable")
    public void updateLocaleSettings(ExamplesTable dataTable)
            throws Exception
    {
        /*
         * Extract the information for:
         * - invoking the PUT request to update locale (restParams)
         * - the updated locale settings (localeParams)
         */
        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);
        LocaleParams localeParams = CommonUtility.extractLocaleConfig(dataTable, 1);

        /*
         * Update the locale settings and execute the PUT request to update the locale settings
         */
        LocaleConfig postEntity = LocalizationSteps.localeConfigResponseEntity;
        postEntity.setLocale(localeParams.getLocale());
        postEntity.setDateOrder(localeParams.getDateOrder());
        postEntity.setDateSeparator(localeParams.getDateSeparator());
        postEntity.setDecimalSeparator(localeParams.getDecimalSeparator());
        postEntity.setUse24h(localeParams.isUse24HourFormat());

        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
                restParams.getRestEndpoint(), restParams.getQueryParams(), postEntity);

        Assert.assertEquals("URL to update locale response is OK", HttpResponseCodes.SC_OK, response.getStatus());

    }

    @Then("the locale is reset:$dataTable")
    public void resetLocale(ExamplesTable dataTable)
    {
        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);

        /*
         * Update the locale settings and execute the PUT request to update the locale settings
         */
        LocaleConfig postEntity = LocalizationSteps.localeConfigResponseEntity;
        postEntity.setLocale(originalLocaleConfig.getLocale());
        postEntity.setDateOrder(originalLocaleConfig.getDateOrder());
        postEntity.setDateSeparator(originalLocaleConfig.getDateSeparator());
        postEntity.setDecimalSeparator(originalLocaleConfig.getDecimalSeparator());
        postEntity.setUse24h(originalLocaleConfig.isUse24HourFormat());

        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
                restParams.getRestEndpoint(), restParams.getQueryParams(), postEntity);

        Assert.assertEquals("URL to update locale response is OK", HttpResponseCodes.SC_OK, response.getStatus());
    }

    private static void copyOriginalLocaleConfigs()
    {
        originalLocaleConfig = new LocaleParams(localeConfigResponseEntity.getLocale(),
                localeConfigResponseEntity.getDateOrder(), localeConfigResponseEntity.getDateSeparator(),
                localeConfigResponseEntity.getUse24h(), localeConfigResponseEntity.getDecimalSeparator());

    }

    // Only locale - new
    @Then("verify that column names are as specified for the locale")
    public void verifyColumnNames()
            throws Exception
    {

        // Fetch the list of column keys that have to be tested
        String[] colListToBeTested = Constants.COLUMN_NAME_LOCALE.split(",");

        // Fetch the list of columns from the column pool on the UI
        Map<String, String> columnPoolMap = getColumnListFromColumnPool();

        String localeFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        JSONObject localeFile = PropertyFileHelper.getLocaleFileAsJson(localeFileName);

        for (String colKey : colListToBeTested)
        {
            String colName = (String) localeFile.get(colKey);

            if ( colName == null )
            {
                logger.debug("No entry in locale file " + localeFileName + " for the column key " + colKey);
                Assert.fail("No entry in locale file " + localeFileName + " for the column key " + colKey);
            }

            logger.debug(colName + " displayed correctly");
            Assert.assertTrue(colName + " displayed correctly : " + columnPoolMap.toString(),
                    columnPoolMap.containsKey(colName));
        }
    }

    // Only locale - new + old
    @When("user clicks on column configuration button")
    public void clickOnColumnConfiguration1()
            throws IOException, InterruptedException

    {
        Column.getInstance().clickOnColumnConfig();
        SeleniumUtility.getInstance().elementDisplayedByXpath("radiobuttons");
        Thread.sleep(2000);
    }

    // locale + others
    @Then("close the browser")
    @Given("close the browser if it is opened")
    public void closebrowser()
            throws Exception
    {
        CommonSteps CommonSteps = new CommonSteps();
        CommonSteps.AfterStory();

    }

    // Only locale - new
    @Then("user enters date in invalid format and gets validation message:$dataTable")
    public void verifyInvalidDateFormatMessage(ExamplesTable dataTable)
            throws Exception
    {
        CommonUtility.validateExampleTable(dataTable, 1);
        String messageKey = "";
        for (Map<String, String> row : dataTable.getRows())
        {
            messageKey = row.get("messageKey");
        }

        String invalidDate = CommonUtility.createInvalidCurrentDateString(localeConfigResponseEntity);
        /*
         * Clear the date and wait for empty text error to disappear
         */
        setFromDate("");
        Thread.sleep(20000);

        /*
         * Set the invalid date and then verify the validation message
         */
        setFromDate(invalidDate);
        verifyDateValidationMessage(messageKey);
        // Reset date controls to current day search
        setSearchDateToToday();
    }

    // Only locale - new
    @Then("user enters to date before from date and gets validation message:$dataTable")
    public void verifyFromToDateValidity(ExamplesTable dataTable)
            throws Exception
    {
        CommonUtility.validateExampleTable(dataTable, 1);
        String messageKey = "";
        for (Map<String, String> row : dataTable.getRows())
        {
            messageKey = row.get("messageKey");
        }

        setDateCalender("to", "blank");
        Thread.sleep(20000);
        setDateCalender("to", "past");
        verifyDateValidationMessage(messageKey);

        setSearchDateToToday();
    }

    // Only locale - new
    @Then("user sets the search dates to blank and gets validation message:$dataTable")
    public void verifyBlankDateError(ExamplesTable dataTable)
            throws Exception
    {
        CommonUtility.validateExampleTable(dataTable, 1);
        String messageKey = "";
        for (Map<String, String> row : dataTable.getRows())
        {
            messageKey = row.get("messageKey");
        }

        setDateCalender("from", "blank");
        verifyDateValidationMessage(messageKey);

        setSearchDateToToday();
    }

    private void verifyDateValidationMessage(String daterangemessage)
            throws IOException, InterruptedException
    {
        String localeFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());

        String message = PropertyFileHelper.getlanguageProperty(localeFileName, daterangemessage).trim();
        if ( daterangemessage.equalsIgnoreCase(dateWarningMesKey) )
        {
            message = message + " " + localeConfigResponseEntity.getDateFormat();
        }

        String errorMsg = getDateErrorMessage(message);

        Assert.assertEquals("Verify the error message for blank date rage", message, errorMsg);
        Assert.assertEquals("Search button should be disabled", "true", Site.getInstance().verifySerchButtonEnabled());
    }

    /**
     * @throws IOException
     * @throws InterruptedException
     */
    private void setSearchDateToToday()
            throws IOException, InterruptedException
    {
        SeleniumUtility.getInstance().elementClick("icon_fromdate");
        SeleniumUtility.getInstance().findElements("todayLink").get(0).click();
        SeleniumUtility.getInstance().elementClick("icon_todate");
        SeleniumUtility.getInstance().findElements("todayLink").get(0).click();
    }

    // Only locale - new
    @Then("the current date label displays the current date in the format specified by the locale")
    public void verifyCurrentDateLable()
            throws Exception
    {
        String localeFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        JSONObject localePropertyFile = PropertyFileHelper.getLocaleFileAsJson(localeFileName);

        String actCurrentDateLabel = PatientList.getInstance().getCurrentDateLable();
        String CurrentDatelable = (String) localePropertyFile.get("currentdate.ui.item.label");

        String expCurrentDate = CurrentDatelable + "\n"
                + CommonUtility.getDateUsingLocale(LocalizationSteps.localeConfigResponseEntity, "now");
        Assert.assertEquals("Verify Current date lable should display current Date", expCurrentDate,
                actCurrentDateLabel.trim());
    }

    // Only locale - new + old
    @Then("Patient list should display patient data as per locale")
    public void verifyPatientData(@Named("Patient_ID") String Patient_ID_val,
            @Named("Sched_Time") String Sched_Time_val, @Named("Patient") String Patient_Info_val,
            @Named("Status") String Status_val)
            throws Exception

    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());// getJSONFile(localeConfigResponseEntity.getLanguage()); // "hac-pl-locale_" +
                                                         // localeConfigResponseEntity.getLanguage() + ".json";
        String Patinet_ID = PropertyFileHelper.getlanguageProperty(JSONFileName, patientIDKey).trim();
        String Sched_Time = PropertyFileHelper.getlanguageProperty(JSONFileName, scheduleProcedureDateKey).trim();
        String Patient_Info = PropertyFileHelper.getlanguageProperty(JSONFileName, patientInfoKey).trim();
        String Status = PropertyFileHelper.getlanguageProperty(JSONFileName, statusDurationKey).trim();
        String age = PropertyFileHelper.getlanguageProperty(JSONFileName, "age.columndata.item.name").trim();
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Patinet_ID);
        headerNames.add(Sched_Time);
        headerNames.add(Patient_Info);
        headerNames.add(Status);

        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        PatientList.getInstance().removeColumnFromColumnList(age);
        String columnName = Patinet_ID;
        String filterValues = Patient_ID_val;
        Filter.getInstance().setFilter(columnName, filterValues);
        int patientIDRowNumber = getPatientIDRow(headerNames, Patient_ID_val);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + Patient_ID_val + " is not displayed on patient list");

        }
        else
        {

            verifyPatient(patientIDRowNumber, headerNames, Patient_Info_val);
            verifyStatusLOS(patientIDRowNumber, headerNames, Status_val);
            verifySchedTime(patientIDRowNumber, headerNames, Sched_Time_val);
            // CommonUtility.getDateUsingLocale(localeConfigResponseEntity, "now"));

        }
    }

    // Only locale - new
    @Then("the date search controls display date in the format specified by the locale")
    public void verifySearchDateFormat()
            throws Exception
    {
        String todayDate = CommonUtility.getDateUsingLocale(LocalizationSteps.localeConfigResponseEntity, "now");// getCurrentPastFutureDate("now");
        PatientList pl = PatientList.getInstance();
        String fromDate = pl.getFromDateValue();
        String toDate = pl.getToDateValue();

        Assert.assertTrue("Verify From date is displayed in correct format",
                todayDate.equals(fromDate) && todayDate.equals(toDate));
        Assert.assertTrue("Verify To date is displayed in correct format", todayDate.equals(toDate));
    }

    // verify value in Patient column
    private void verifyPatient(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedPatientValue)
            throws IOException, InterruptedException
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        int patientColPosition = PatientListData.getInstance().getColumnPosition(patientListColumnHeaderList,
                PropertyFileHelper.getlanguageProperty(JSONFileName, patientInfoKey).trim());
        String actPatientValue = PatientListData.getInstance().getCellValue(patientIDRowNumber, patientColPosition);
        actPatientValue = actPatientValue.replaceAll(Constants.NEWLINE_SEPERATOR, Constants.SINGLE_SPACE);
        Assert.assertEquals("Verify Patient column displays value=" + expectedPatientValue + " at row number="
                + patientIDRowNumber + " and column number=" + patientColPosition, expectedPatientValue,
                actPatientValue);
    }

    // verify value in Sched time column
    private void verifySchedTime(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedSchedTimeValue)
            throws Exception
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        int schedTimeColPosition = PatientListData.getInstance().getColumnPosition(patientListColumnHeaderList,
                PropertyFileHelper.getlanguageProperty(JSONFileName, scheduleProcedureDateKey).trim());
        String actSchedTimeValue = PatientListData.getInstance().getCellValue(patientIDRowNumber, schedTimeColPosition);
        /*
         * from feature file instead of passing actual date, we will be passing Today,Past,Future keywords
         * otherwise every time before running feature file we need to change sched time manually
         * and while verifying actual sched time with expected sched time we are converting these keyword with expected date values with respective current date
         * e.g Today -08/26/2015 Past -08/20/2015 Future -08/30/2015
         */
        if ( expectedSchedTimeValue.contains("Today") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Today",
                    CommonUtility.getDateUsingLocale(localeConfigResponseEntity, "current"));
        }
        else if ( expectedSchedTimeValue.contains("Past") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Past",
                    CommonUtility.getDateUsingLocale(localeConfigResponseEntity, "past"));
        }
        else if ( expectedSchedTimeValue.contains("Future") )
        {
            expectedSchedTimeValue = expectedSchedTimeValue.replace("Future",
                    CommonUtility.getDateUsingLocale(localeConfigResponseEntity, "future"));
        }
        Assert.assertEquals(
                "Verify Sched time column displays value=" + expectedSchedTimeValue + " at row number="
                        + patientIDRowNumber + " and column number=" + schedTimeColPosition,
                expectedSchedTimeValue, actSchedTimeValue);
    }

    // verify value in Status/LOS column
    private void verifyStatusLOS(int patientIDRowNumber, List<String> patientListColumnHeaderList,
            String expectedStatusLOS)
            throws IOException, InterruptedException
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        int statusLOSColPosition = PatientListData.getInstance().getColumnPosition(patientListColumnHeaderList,
                PropertyFileHelper.getlanguageProperty(JSONFileName, statusDurationKey).trim());
        expectedStatusLOS = expectedStatusLOS.trim();
        String actStatusLOSValue = PatientListData.getInstance().getCellValue(patientIDRowNumber, statusLOSColPosition);
        String[] actStatusLOSValue1 = actStatusLOSValue.split("\n");
        actStatusLOSValue = actStatusLOSValue1[0];
        //actStatusLOSValue = actStatusLOSValue1[0] + " " + actStatusLOSValue1[1];
        if ( !expectedStatusLOS.equalsIgnoreCase(actStatusLOSValue) )
        {
            Assert.fail("Verify Status/Duration column displays value=" + expectedStatusLOS + " at row number="
                    + patientIDRowNumber + " and column number=" + statusLOSColPosition + "  expected=:"
                    + expectedStatusLOS + " actual=:" + actStatusLOSValue);
        }
    }

    // get row which is having specified patientID
    private int getPatientIDRow(List<String> patientListColumnHeaderList, String patientIDValue)
            throws IOException, InterruptedException
    {
        Map<String, Integer> patientListColumnsHeaderIndexMap = PatientListData.getInstance()
                .getPatientListColumnsPosition(patientListColumnHeaderList);
        logger.debug("PatientListColumn:getPatientIDRow:get row of PatientId=" + patientIDValue);
        // get row in which PatientID is present
        return getRowNumber(patientIDValue, patientListColumnsHeaderIndexMap);

    }

    // this function gives row number depending upon passed row value
    private int getRowNumber(String patientID, Map<String, Integer> patientListColumnHeaderList)
            throws IOException, InterruptedException
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        int patientIdRowNum = 0;
        // get column position from hash map
        int patientIDColumnPosition = patientListColumnHeaderList
                .get(PropertyFileHelper.getlanguageProperty(JSONFileName, patientIDKey).trim());
        // create xpath by using column number
        String xpath = "//td[" + patientIDColumnPosition + "]";
        List<WebElement> allRows = SeleniumUtility.getInstance().findElements("allRows");
        for (int i = 0; i < allRows.size(); i++)
        {
            List<WebElement> patientIDColumnData = SeleniumUtility.getInstance().findElementsUsingDynamicPath("allRows",
                    xpath);

            // find row number by checking expected and actual values
            if ( patientID.equals((patientIDColumnData.get(i).getText())) )
            {
                // Highlight the row in patient list
                patientIDColumnData.get(i).click();
                patientIdRowNum = i + 1;
                break;
            }
        }

        logger.debug("PatientList:getRowNumber: row number of " + patientID + " is " + patientIdRowNum);
        return patientIdRowNum;
    }

    private Map<String, String> getColumnListFromColumnPool()
            throws IOException, InterruptedException
    {
        List<WebElement> elestate = SeleniumUtility.getInstance().findElements("radiobuttons");
        List<WebElement> column_name_in_columnpool = SeleniumUtility.getInstance()
                .findElements("column_name_in_columnpool");
        Map<String, String> ColumnNames = new HashMap<String, String>();
        String checkStatus = null;
        for (int i = 0; i < elestate.size(); i++)
        {

            String columnname = column_name_in_columnpool.get(i).getText().trim();
            if ( "dropdownitems icon-ico_circle_blank_sm"
                    .equalsIgnoreCase(elestate.get(i).getAttribute("class").toString()) )
            {
                checkStatus = "UNCHECKED";
            }
            else
            {
                checkStatus = "CHECKED";

            }

            ColumnNames.put(columnname.trim(), checkStatus.trim());

        }
        return ColumnNames;
    }

    public void clearBrowserCache()
            throws IOException, InterruptedException
    {
        try
        {
            SeleniumUtility.getInstance().deleteBrowserAllCookies();
        }

        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.steps.plintegration.LocalizationSteps.clearBrowserCache()", e);
        }
    }

    public void setDateCalender(String dateControl, String dateToSet)
            throws Exception

    {
        String retrivedDate = CommonUtility.getDateUsingLocale(localeConfigResponseEntity, dateToSet);// getCurrentPastFutureDate(dateToSet);
        switch (dateControl)
        {
            case "from":
                setFromDate(retrivedDate);
                break;
            case "to":

                SetToDate(retrivedDate);
                break;
        }

    }

    public String getSystemDate()
            throws IOException
    {
        DateFormat dateFormat = new SimpleDateFormat(currentDateFormat);
        Calendar cal = Calendar.getInstance();
        return dateFormat.format(cal.getTime());
    }

    public void SetToDate(String dateToSet)
            throws IOException

    {
        try
        {
            SeleniumUtility.getInstance().sendKeys("toDateTextbox", dateToSet);
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.steps.plintegration.LocalizationSteps.SetToDate()", e);
        }
    }

    public void setFromDate(String dateToSet)
            throws IOException

    {
        SeleniumUtility.getInstance().sendKeys("fromDateTextbox", dateToSet);
    }

    public String getCurrentPastFutureDate(String date)
            throws Exception
    {
        String retriveDate = null;
        switch (date.toLowerCase())
        {
            case "now":
            case "current":
            {
                retriveDate = getSystemDate();
                break;
            }
            case "future":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("FUTURE_DATE")));
                break;
            case "past":
                retriveDate = getCustomiseDate(getSystemDate(), "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("PAST_DATE")));
                break;
            case "blank":
                retriveDate = "";
                break;
        }

        return retriveDate;
    }

    private String getCustomiseDate(String givenDate, String type, int number)
            throws Exception
    {
        DateFormat dateFormat = new SimpleDateFormat(currentDateFormat);
        Date parsedDate = dateFormat.parse(givenDate);

        Calendar cal = Calendar.getInstance();
        cal.setTime(parsedDate);

        switch (type.toLowerCase())
        {
            case "day":
                cal.add(Calendar.DATE, number);
                break;
            case "month":
                cal.add(Calendar.MONTH, number);
                break;
            case "year":
                cal.add(Calendar.YEAR, number);
                break;
        }
        return dateFormat.format(cal.getTime());
    }

    // this function replace day,month or year in passed date
    public String getReplacedDate(String fieldToChange, String valueToChange)
            throws IOException
    {

        Calendar cal = Calendar.getInstance();

        String replaceString = currentDateFormat;
        switch (fieldToChange.toLowerCase())
        {
            case "day":
                if ( valueToChange.matches("\\d+") )
                {
                    valueToChange = String.format("%02d", Integer.parseInt(valueToChange));
                }
                replaceString = replaceString.replace("dd", String.valueOf(valueToChange));
                break;
            case "month":
                if ( valueToChange.matches("\\d+") )
                {
                    valueToChange = String.format("%02d", Integer.parseInt(valueToChange));
                }

                replaceString = replaceString.replace("MM", String.valueOf(valueToChange));
                break;
            case "year":
                replaceString = replaceString.replace("yyyy", String.valueOf(valueToChange));
                break;
        }

        replaceString = replaceString.replace("MM", String.format("%02d", cal.get(Calendar.MONTH) + 1));
        replaceString = replaceString.replace("yyyy", String.valueOf(cal.get(Calendar.YEAR)));
        replaceString = replaceString.replace("dd", String.format("%02d", cal.get(Calendar.DATE)));

        return replaceString;
    }

    /* get error message for date validation */
    public String getDateErrorMessage(String message)
            throws IOException, InterruptedException
    {
        String ErrorMessage;
        logger.debug("getDateErrorMessage: return invalid date range message");
        List<WebElement> eleList = SeleniumUtility.getInstance().getElementsByXPath("warningMessage");
        ErrorMessage = eleList.get(eleList.size() - 1).getText().trim();
        logger.debug("PatientList:getDateErrorMessage: " + ErrorMessage);
        return ErrorMessage;
    }

    // locale + others
    @When("the user enters <username> and <password>, and clicks on Sign in button")
    public void EnterCredentialAndSignIN(@Named("username") String userName, @Named("password") String password)
            throws Exception
    {
        logger.debug("get Sign In label  in " + Language_Locale + " locale");
        // String signInButtonLable = "Sign In";
        // PropertyFileHelper.getlanguageProperty(messageFilename,"login.page.loginButtonLabel").trim();
        int timeout = 0;
        Thread.sleep(2000);
        // wait for Sign in button to display
        while (!(SeleniumUtility.getInstance().elementDisplayedByXpath("signin")) && timeout <= 50)
        {
            PatientList.getInstance().browserRestart();
            Thread.sleep(2000);
            logger.debug("LocalizationSteps:EnterCredentials1 waiting for Sign in button to display=" + timeout);
            timeout++;
        }
        // wait for Sign in button to display
        // PatientList.getInstance().waitForElementToAppear("signin", signInButtonLable, Constants.HIGH_TIMEOUT);
        // enter credentials
        SeleniumUtility.getInstance().sendKeys("Username", userName);
        SeleniumUtility.getInstance().sendKeys("Password", password);
        logger.debug("PatientList:EnterCredentials:enter usernmae =" + userName + " password=" + password);
        PatientList.getInstance().clickOnlogin();

        Thread.sleep(5000);
        logger.debug("waiting for sucessful login");
        timeout = 0;
        while (SeleniumUtility.getInstance().elementDisplayedByXpath("signin") && timeout <= 50)
        {
            logger.debug(
                    "LocalizationStepsr:signIn1 poc server not yet started, waiting for server to start by refreshing the browser");
            PatientList.getInstance().browserRestart();
            SeleniumUtility.getInstance().sendKeys("Username", userName);
            SeleniumUtility.getInstance().sendKeys("Password", password);

            PatientList.getInstance().clickOnlogin();
            Thread.sleep(10000);
            logger.debug("LocalizationStepsr:signIn1 waiting for server to start=" + timeout);
            timeout++;
        }
    }

    @Then("Patient list displays <LoggedIn_UserName> after login")
    public void verifyLoggedinUserNameAfterLogin(@Named("LoggedIn_UserName") String loggedIn_UserName)
            throws Exception
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        String searchButton = PropertyFileHelper.getlanguageProperty(JSONFileName, "date.search.go.ui.item.button")
                .trim();
        logger.debug("LocalizationStepsr:verifyLoggedinUserName1 waiting for loggedin UserName to display");
        PatientList.getInstance().waitForElementToAppear("loggedinUserName", loggedIn_UserName, Constants.HIGH_TIMEOUT);
        String loggedInUserName = PatientList.getInstance().getloggedinUserName();
        Assert.assertEquals("The login is successfull for locale=" + localeConfigResponseEntity.getLocale(),
                loggedIn_UserName, loggedInUserName.trim());
        logger.debug("LocalizationStepsr:verifyLoggedinUserName1 waiting for search_button to display");
        PatientList.getInstance().waitForElementToAppear("search_button", searchButton, Constants.HIGH_TIMEOUT * 2);
        boolean gridDisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("datagrid");
        while (!gridDisplayed)
        {
            gridDisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("datagrid");
        }
        Assert.assertEquals("user is able to view the Patient List grid", true, gridDisplayed);

    }

    private static String getLocaleFilePath(String language, String country)
    {
        String langExtension = language;
        String filePrefix = "hac-pl-locale_";
        String localeFileName = "";

        if ( language.equalsIgnoreCase("pt") && country.toLowerCase().contains("br") )
        {
            langExtension = language + "-br";
        }

        localeFileName = PropertyFileHelper.getProjectProperty("Json_files_for_locale") + "\\" + filePrefix
                + langExtension + ".json";

        return localeFileName;
    }

    private String getJSONFile(String locale)
    {

        String jsonfilename = "hac-pl-locale_" + locale + ".json";
        String jsonfilePath = PropertyFileHelper.getProjectProperty("Json_files_for_locale") + "\\" + jsonfilename;
        File fjsonfile = new File(jsonfilePath);
        if ( !fjsonfile.exists() )
        {
            locale = locale.replace("_", "-");
            jsonfilename = "hac-pl-locale_" + locale + ".json";
            jsonfilePath = PropertyFileHelper.getProjectProperty("Json_files_for_locale") + "\\" + jsonfilename;
            fjsonfile = new File(jsonfilePath);
            if ( !fjsonfile.exists() )
            {
                String[] language = locale.split("-");
                jsonfilename = "hac-pl-locale_" + language[0] + ".json";
            }

        }

        return jsonfilename;
    }

    @Then("Unit View Layout should display data as per locale")
    public static void verifylabelsOnConfiguratorTool()
            throws IOException, InterruptedException
    {
        String JSONFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        Configurator.selectTab(Constants.CONFIGURATOR_SECOND_TAB_NAME);
        Thread.sleep(5000);
        Configurator.waitForPageToload();
        // get labels from UI
        String actSettingsTabLabel = SeleniumUtility.getInstance().get_text("first_tab").trim();
        String actUnitViewLayoutTabLabel = SeleniumUtility.getInstance().get_text("second_tab").trim();
        String actDepartmentLabel = SeleniumUtility.getInstance().get_text("department_label").trim();
        String actLayoutSizeLabel = SeleniumUtility.getInstance().get_text("layoutsize_label").trim();
        String actRowsLabel = SeleniumUtility.getInstance().get_text("rows_label").replace(":", "").trim();
        String actColsLabel = SeleniumUtility.getInstance().get_text("cols_label").replace(":", "").trim();
        // get the labels from locale files
        String expSettingsTabLabel = PropertyFileHelper
                .getlanguageProperty(JSONFileName, "Configurator.tool.settings.tab").trim();
        String expUnitViewLayoutTabLabel = PropertyFileHelper
                .getlanguageProperty(JSONFileName, "Configurator.tool.unitview.tab").trim();
        String expDepartmentLabel = PropertyFileHelper
                .getlanguageProperty(JSONFileName, "Configurator.tool.department.label").trim();
        String expLayoutSizeLabel = PropertyFileHelper
                .getlanguageProperty(JSONFileName, "Configurator.tool.layout.label").trim();
        String expRowsLabel = PropertyFileHelper.getlanguageProperty(JSONFileName, "Configurator.tool.rows.label")
                .trim();
        String expColsLabel = PropertyFileHelper.getlanguageProperty(JSONFileName, "Configurator.tool.cols.label")
                .trim();
        // compare UI labels with Locale labels
        Assert.assertTrue(
                "Verify Settings tab label ,expected=" + expSettingsTabLabel + ",actual=" + actSettingsTabLabel,
                expSettingsTabLabel.equalsIgnoreCase(actSettingsTabLabel));
        Assert.assertTrue(
                "Verify Unit View Layout tab label ,expected=" + expUnitViewLayoutTabLabel + ",actual="
                        + actUnitViewLayoutTabLabel,
                expUnitViewLayoutTabLabel.equalsIgnoreCase(actUnitViewLayoutTabLabel));
        Assert.assertTrue("Verify Department label ,expected=" + expDepartmentLabel + ",actual=" + actDepartmentLabel,
                expDepartmentLabel.equalsIgnoreCase(actDepartmentLabel));
        Assert.assertTrue("Verify Layout label ,expected=" + expLayoutSizeLabel + ",actual=" + actLayoutSizeLabel,
                expLayoutSizeLabel.equalsIgnoreCase(actLayoutSizeLabel));
        Assert.assertTrue("Verify Rows: label ,expected=" + expRowsLabel + ",actual=" + actRowsLabel,
                expRowsLabel.equalsIgnoreCase(actRowsLabel));
        Assert.assertTrue("Verify Department label ,expected=" + expColsLabel + ",actual=" + actColsLabel,
                expColsLabel.equalsIgnoreCase(actColsLabel));

        // delete the ocuupied cell verify error message
        String expErrorMessage = PropertyFileHelper.getlanguageProperty(JSONFileName, "Configurator.tool.error.01")
                .trim();
        String rowno = Configurator.getDefaultColsNo() - 1 + "";
        Configurator.setColumnNumber(rowno);
        String actErrorMessage = Configurator.getErrorMessage();
        Assert.assertTrue(
                "Verify Grid size cannot be reduced because it will result in removal of an already configured bed error displayed ,expected="
                        + expErrorMessage + ",actual=" + actErrorMessage,
                expErrorMessage.equalsIgnoreCase(actErrorMessage));
    }

    // locale + others
    @When("user changes the server locale to  <localelanguage> and restart the application server")
    public void changeLocalStartServer(@Named("localelanguage") String localelang)
            throws IOException, InterruptedException

    {
        Language_Locale = localelang.trim();
        String JSONFileName = getJSONFile(Language_Locale);
        logger.debug("locale=" + Language_Locale + " languagefilename=  " + JSONFileName);
        DbAndServiceExecutor.changeLocaleAndRestartServer(Language_Locale);

    }

    @Then("the application server is restarted")
    public void restartApplicationServer()
            throws Exception
    {
        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        try
        {

            PropertySessionRemote propService = (PropertySessionRemote) ServiceLocator
                    .getService(ServiceLocator.Services.PROPERTY);

            propService.setProperty(PropertySessionRemote.SYSTEM_LOCALE, localeConfigResponseEntity.getLocale(),
                    "System wide locale.");
            propService.setProperty(PropertySessionRemote.DATE_FORMAT_ORDER, localeConfigResponseEntity.getDateOrder(),
                    "Defines the order of day, month, year in date displays");
            propService.setProperty(PropertySessionRemote.DATE_FORMAT_SEPARATOR,
                    String.valueOf(localeConfigResponseEntity.getDateSeparator()),
                    "Defines the separator charactor in dates");
            propService.setProperty(PropertySessionRemote.NUMBER_DECIMAL_SEPARATOR,
                    String.valueOf(localeConfigResponseEntity.getDecimalSeparator()), "Defines decimal separator");
            propService.setProperty(PropertySessionRemote.TIME_FORMAT_USE24H,
                    String.valueOf(localeConfigResponseEntity.getUse24h()),
                    "Defines the time format 24h/AM/PM in times");

            ServerInfoSingleton sis = (ServerInfoSingleton) ServiceLocator
                    .getService(ServiceLocator.Services.SERVERINFO);
            sis.startService();

            Thread.sleep(15000);
        }
        catch (Exception e)
        {

            logger.error("restartApplicationServer - error while restarting the server.", e);
        }
    }

    @Then("user selects All Periop tab")
    public void selectAllTab(@Named("messageKey") String messageKey)
            throws Exception
    {

        String localeFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        String department = PropertyFileHelper.getlanguageProperty(localeFileName, messageKey).trim();
        Site.getInstance().selectDepartment(department);
    }

    private String getKeyValue(String Key)
    {
        String localeFileName = getLocaleFilePath(localeConfigResponseEntity.getLanguage(),
                localeConfigResponseEntity.getCountry());
        return PropertyFileHelper.getlanguageProperty(localeFileName, Key).trim();

    }

    @Then("arriving list should display Arriving tab")
    public void verifyArrivingTab(@Named("messageKey") String messageKey)
            throws Exception
    {

        Assert.assertEquals("side panel shows arriving list tab name in expand mode", getKeyValue(messageKey),
                SidePanel.getArrivalTabLabelInExpandedMode());

    }

    @Then("arriving list should display Arriving tab in collapsed mode")
    public void verifyArrivingTabNameInCollapseMode(@Named("messageKey") String messageKey)
            throws Exception
    {

        Assert.assertEquals("side panel shows arriving list tab name in collapse mode", getKeyValue(messageKey),
                SidePanel.getArrivalTabLabelInCollapsedMode());

    }

    @Then("error message should displayed indicating layout is not configured")
    public void verifyLayoutMisssingError(@Named("messageKey") String messageKey)
            throws Exception
    {
        Thread.sleep(2000);

        String actErrorMsg = getDateErrorMessage(messageKey);
        Assert.assertEquals("Verify the error message for missing bed layout configuration", getKeyValue(messageKey),
                actErrorMsg);

    }

    @Then("popover should display with localized patient data on pacu bed")
    public void verifyPacuPopoverOnbed(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("dob") String dob)
    {
        PopoverCard BedPopOver = new PopoverCard();
        String actDob = BedPopOver.getDateOfBirth();
        String actPatientidFieldText = BedPopOver.getPatientIdFieldText();
        String actPatientnameFieldText = BedPopOver.getPatientNameFieldText();
        String actDobFieldText = BedPopOver.getDateOfBirthFieldText();
        String actAgeFieldText = BedPopOver.getAgeFieldText();
        String actSurgeonFieldText = BedPopOver.getSurgeonFieldText();
        String actAnesthesiologistsFieldText = BedPopOver.getAnesthesiologistsFieldText();
        String actNurseFieldText = BedPopOver.getPacuNurseFieldText();
        String actIsolationFieldText = BedPopOver.getIsolationText();
        String actGenderFieldText = BedPopOver.getGenderFieldText();
        String actSimilarnameFieldText = BedPopOver.getSimilarnameText();
        String actProcedureFieldText = BedPopOver.getProcedureFieldText();
        String actLOSFieldText = BedPopOver.getLosFieldText();
        Assert.assertTrue("Verify Dob on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + dob
                + "; actual=" + actDob, actDob.equalsIgnoreCase(dob));
        String Patientname = getKeyValue("popover.unitview.name");
        Assert.assertTrue(
                "Verify Patient name text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientname + "; actual=" + actPatientnameFieldText,
                Patientname.equalsIgnoreCase(actPatientnameFieldText));
        String Dob = getKeyValue("popover.unitview.date.of.birth");
        Assert.assertTrue("Verify Dob text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Dob + "; actual=" + actDobFieldText, Dob.equalsIgnoreCase(actDobFieldText));
        String Age = getKeyValue("popover.unitview.age");
        Assert.assertTrue("Verify Age text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Age + "; actual=" + actAgeFieldText, Age.equalsIgnoreCase(actAgeFieldText));
        String Surgeon = getKeyValue("popover.unitview.surgeon");
        Assert.assertTrue(
                "Verify Surgeon text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Surgeon + "; actual=" + actSurgeonFieldText,
                Surgeon.equalsIgnoreCase(actSurgeonFieldText));
        String Anesthesiologists = getKeyValue("popover.unitview.anesthesiologist");
        Assert.assertTrue(
                "Verify Anesthesiologists text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Anesthesiologists + "; actual=" + actAnesthesiologistsFieldText,
                Anesthesiologists.equalsIgnoreCase(actAnesthesiologistsFieldText));
        String Isolationtext = getKeyValue("popover.unitview.isolation");
        Assert.assertTrue(
                "Verify Isolation icon text  on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Isolationtext + "; actual=" + actIsolationFieldText,
                Isolationtext.equalsIgnoreCase(actIsolationFieldText));
        String Gender = getKeyValue("popover.unitview.gender");
        Assert.assertTrue(
                "Verify Gender text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Gender + "; actual=" + actGenderFieldText,
                Gender.equalsIgnoreCase(actGenderFieldText));
        String Procedure = getKeyValue("popover.unitview.surgery");
        Assert.assertTrue(
                "Verify Procedure text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Procedure + "; actual=" + actProcedureFieldText,
                Procedure.equalsIgnoreCase(actProcedureFieldText));

        String Nurse = getKeyValue("popover.unitview.nurse");
        Assert.assertTrue(
                "Verify Nurse text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Nurse + "; actual=" + actNurseFieldText,
                Nurse.equalsIgnoreCase(actNurseFieldText));
        String LOS = getKeyValue("popover.unitview.length.of.stay");
        Assert.assertTrue("Verify LOS text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + LOS + "; actual=" + actLOSFieldText, LOS.equalsIgnoreCase(actLOSFieldText));
        String Patientid = getKeyValue("popover.unitview.patientid");
        Assert.assertTrue(
                "Verify Patientid text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientid + "; actual=" + actPatientidFieldText,
                Patientid.equalsIgnoreCase(actPatientidFieldText));
        String SimilarnameText = getKeyValue("popover.unitview.similar.name");
        Assert.assertTrue(
                "Verify similar name icon's text on popover for card at row=" + RowNumber + " and column="
                        + ColumnNumber + " expected=" + SimilarnameText + "; actual=" + actSimilarnameFieldText,
                SimilarnameText.equalsIgnoreCase(actSimilarnameFieldText));
    }

    @Then("popover should display with localized patient data on pacu arriving list")
    public void verifyPacuPopoverOnArrivingList(@Named("dob") String dob)
    {
        PopoverArrivingListCard BedPopOver = new PopoverArrivingListCard();
        String actDob = BedPopOver.getDateOfBirth();
        String actPatientidFieldText = BedPopOver.getPatientIdFieldText();
        String actPatientnameFieldText = BedPopOver.getPatientNameFieldText();
        String actDobFieldText = BedPopOver.getDateOfBirthFieldText();
        String actAgeFieldText = BedPopOver.getAgeFieldText();
        String actSurgeonFieldText = BedPopOver.getSurgeonFieldText();
        String actAnesthesiologistsFieldText = BedPopOver.getAnesthesiologistsFieldText();
        String actIsolationFieldText = BedPopOver.getIsolationText();
        String actGenderFieldText = BedPopOver.getGenderFieldText();
        // String actSimilarnameFieldText = BedPopOver.getSimilarnameText();
        String actProcedureFieldText = BedPopOver.getProcedureFieldText();
        String actLastTimeEventtext = BedPopOver.getLastTimeEventText();
        Assert.assertTrue("Verify Dob on card expected=" + dob + "; actual=" + actDob, actDob.equalsIgnoreCase(dob));
        String Patientname = getKeyValue("popover.unitview.name");
        Assert.assertTrue("Verify Patient name text on popover for card expected=" + Patientname + "; actual="
                + actPatientnameFieldText, Patientname.equalsIgnoreCase(actPatientnameFieldText));
        String Dob = getKeyValue("popover.unitview.date.of.birth");
        Assert.assertTrue("Verify Dob text on popover for card expected=" + Dob + "; actual=" + actDobFieldText,
                Dob.equalsIgnoreCase(actDobFieldText));
        String Age = getKeyValue("popover.unitview.age");
        Assert.assertTrue("Verify Age text on popover for card expected=" + Age + "; actual=" + actAgeFieldText,
                Age.equalsIgnoreCase(actAgeFieldText));
        String Surgeon = getKeyValue("popover.unitview.surgeon");
        Assert.assertTrue(
                "Verify Surgeon text on popover for card expected=" + Surgeon + "; actual=" + actSurgeonFieldText,
                Surgeon.equalsIgnoreCase(actSurgeonFieldText));
        String Anesthesiologists = getKeyValue("popover.unitview.anesthesiologist");
        Assert.assertTrue(
                "Verify Anesthesiologists text on popover for card expected=" + Anesthesiologists + "; actual="
                        + actAnesthesiologistsFieldText,
                Anesthesiologists.equalsIgnoreCase(actAnesthesiologistsFieldText));
        String Isolationtext = getKeyValue("popover.unitview.isolation");
        Assert.assertTrue("Verify Isolation icon text  on popover for card expected=" + Isolationtext + "; actual="
                + actIsolationFieldText, Isolationtext.equalsIgnoreCase(actIsolationFieldText));
        String Gender = getKeyValue("popover.unitview.gender");
        Assert.assertTrue(
                "Verify Gender text on popover for card expected=" + Gender + "; actual=" + actGenderFieldText,
                Gender.equalsIgnoreCase(actGenderFieldText));
        String Procedure = getKeyValue("popover.unitview.surgery");
        Assert.assertTrue(
                "Verify Procedure text on popover for card expected=" + Procedure + "; actual=" + actProcedureFieldText,
                Procedure.equalsIgnoreCase(actProcedureFieldText));

        String LastTimeEventtext = getKeyValue("popover.unitview.surgical.milestone");
        Assert.assertTrue("Verify surgery status text on popover for card expected=" + LastTimeEventtext + "; actual="
                + actLastTimeEventtext, LastTimeEventtext.equalsIgnoreCase(actLastTimeEventtext));

        String Patientid = getKeyValue("popover.unitview.patientid");
        Assert.assertTrue(
                "Verify Patientid text on popover for card expected=" + Patientid + "; actual=" + actPatientidFieldText,
                Patientid.equalsIgnoreCase(actPatientidFieldText));
        // String SimilarnameText = getKeyValue("popover.unitview.similar.name");
        // Assert.assertTrue("Verify similar name icon's text on popover for card expected=" + SimilarnameText
        // + "; actual=" + actSimilarnameFieldText, SimilarnameText.equalsIgnoreCase(actSimilarnameFieldText));
    }

    @Then("popover should display with localized patient data on ICU bed")
    public void verifyIcuPopoverOnbed(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
    {
        PopoverCard BedPopOver = new PopoverCard();

        String actPatientidFieldText = BedPopOver.getPatientIdFieldText();
        String actPatientnameFieldText = BedPopOver.getPatientNameFieldText();
        String actDobFieldText = BedPopOver.getDateOfBirthFieldText();
        String actAgeFieldText = BedPopOver.getAgeFieldText();
        String actSurgeonFieldText = BedPopOver.getSurgeonFieldText();
        String actIntensivistsFieldText = BedPopOver.getIntensivistsText();
        String actNurseFieldText = BedPopOver.getIcuNurseText();
        String actLastTimeEventtext = BedPopOver.getLastTimeEventText();
        String actGenderFieldText = BedPopOver.getGenderFieldText();
        // String actSimilarnameFieldText = BedPopOver.getSimilarnameText();
        String actProcedureFieldText = BedPopOver.getProcedureFieldText();
        String actLOSFieldText = BedPopOver.getLosFieldText();

        String Patientname = getKeyValue("popover.unitview.name");
        Assert.assertTrue(
                "Verify Patient name text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientname + "; actual=" + actPatientnameFieldText,
                Patientname.equalsIgnoreCase(actPatientnameFieldText));
        String Dob = getKeyValue("popover.unitview.date.of.birth");
        Assert.assertTrue("Verify Dob text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Dob + "; actual=" + actDobFieldText, Dob.equalsIgnoreCase(actDobFieldText));
        String Age = getKeyValue("popover.unitview.age");
        Assert.assertTrue("Verify Age text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Age + "; actual=" + actAgeFieldText, Age.equalsIgnoreCase(actAgeFieldText));

        String Intensivists = getKeyValue("popover.unitview.intensivist");
        Assert.assertTrue(
                "Verify Intensivists text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Intensivists + "; actual=" + actIntensivistsFieldText,
                Intensivists.equalsIgnoreCase(actIntensivistsFieldText));
        // String Isolationtext = getKeyValue("popover.unitview.isolation");
        /// Assert.assertTrue(
        // "Verify Isolation icon text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
        // + " expected=" + Isolationtext + "; actual=" + actIsolationFieldText,
        // Isolationtext.equalsIgnoreCase(actIsolationFieldText));
        String Gender = getKeyValue("popover.unitview.gender");
        Assert.assertTrue(
                "Verify Gender text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Gender + "; actual=" + actGenderFieldText,
                Gender.equalsIgnoreCase(actGenderFieldText));

        String Nurse = getKeyValue("popover.unitview.nurse");
        Assert.assertTrue(
                "Verify Nurse text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Nurse + "; actual=" + actNurseFieldText,
                Nurse.equalsIgnoreCase(actNurseFieldText));
        String LOS = getKeyValue("popover.unitview.length.of.stay");
        Assert.assertTrue("Verify LOS text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + LOS + "; actual=" + actLOSFieldText, LOS.equalsIgnoreCase(actLOSFieldText));
        String Patientid = getKeyValue("popover.unitview.patientid");
        Assert.assertTrue(
                "Verify Patientid text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientid + "; actual=" + actPatientidFieldText,
                Patientid.equalsIgnoreCase(actPatientidFieldText));
        // String LastTimeEventtext = getKeyValue("popover.unitview.surgical.milestone");
        // Assert.assertTrue("Verify surgery status text on popover for card expected=" + LastTimeEventtext + "; actual="
        // + actLastTimeEventtext, LastTimeEventtext.equalsIgnoreCase(actLastTimeEventtext));

        String Surgeon = getKeyValue("popover.unitview.surgeon");
        Assert.assertTrue(
                "Verify Surgeon text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Surgeon + "; actual=" + actSurgeonFieldText,
                Surgeon.equalsIgnoreCase(actSurgeonFieldText));
        String Procedure = getKeyValue("popover.unitview.surgery");
        Assert.assertTrue(
                "Verify Procedure text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Procedure + "; actual=" + actProcedureFieldText,
                Procedure.equalsIgnoreCase(actProcedureFieldText));
    }

    @Then("popover should display with localized patient data on ICU arriving list")
    public void verifyIcuPopoverOnArrivingList()
    {
        PopoverArrivingListCard BedPopOver = new PopoverArrivingListCard();

        String actPatientidFieldText = BedPopOver.getPatientIdFieldText();
        String actPatientnameFieldText = BedPopOver.getPatientNameFieldText();
        String actDobFieldText = BedPopOver.getDateOfBirthFieldText();
        String actAgeFieldText = BedPopOver.getAgeFieldText();
        String actSurgeonFieldText = BedPopOver.getSurgeonFieldText();
        String actAnesthesiologistsFieldText = BedPopOver.getAnesthesiologistsFieldText();
        // String actIsolationFieldText = BedPopOver.getIsolationText();
        String actGenderFieldText = BedPopOver.getGenderFieldText();
        // String actSimilarnameFieldText = BedPopOver.getSimilarnameText();
        // String actProcedureFieldText = BedPopOver.getProcedureFieldText();
        String actAdmissionReasontexttext = BedPopOver.getAdmissionReasontext();
        String Patientname = getKeyValue("popover.unitview.name");
        Assert.assertTrue("Verify Patient name text on popover for card expected=" + Patientname + "; actual="
                + actPatientnameFieldText, Patientname.equalsIgnoreCase(actPatientnameFieldText));
        String Dob = getKeyValue("popover.unitview.date.of.birth");
        Assert.assertTrue("Verify Dob text on popover for card expected=" + Dob + "; actual=" + actDobFieldText,
                Dob.equalsIgnoreCase(actDobFieldText));
        String Age = getKeyValue("popover.unitview.age");
        Assert.assertTrue("Verify Age text on popover for card expected=" + Age + "; actual=" + actAgeFieldText,
                Age.equalsIgnoreCase(actAgeFieldText));
        String Surgeon = getKeyValue("popover.unitview.surgeon");
        Assert.assertTrue(
                "Verify Surgeon text on popover for card expected=" + Surgeon + "; actual=" + actSurgeonFieldText,
                Surgeon.equalsIgnoreCase(actSurgeonFieldText));
        String Anesthesiologists = getKeyValue("popover.unitview.anesthesiologist");
        Assert.assertTrue(
                "Verify Anesthesiologists text on popover for card expected=" + Anesthesiologists + "; actual="
                        + actAnesthesiologistsFieldText,
                Anesthesiologists.equalsIgnoreCase(actAnesthesiologistsFieldText));
        // String Isolationtext = getKeyValue("popover.unitview.isolation");
        // Assert.assertTrue("Verify Isolation icon text on popover for card expected=" + Isolationtext + "; actual="
        // + actIsolationFieldText, Isolationtext.equalsIgnoreCase(actIsolationFieldText));
        String Gender = getKeyValue("popover.unitview.gender");
        Assert.assertTrue(
                "Verify Gender text on popover for card expected=" + Gender + "; actual=" + actGenderFieldText,
                Gender.equalsIgnoreCase(actGenderFieldText));
        // String Procedure = getKeyValue("popover.unitview.surgery");
        // Assert.assertTrue(
        // "Verify Procedure text on popover for card expected=" + Procedure + "; actual=" + actProcedureFieldText,
        // Procedure.equalsIgnoreCase(actProcedureFieldText));

        // String LastTimeEventtext = getKeyValue("popover.unitview.surgical.milestone");
        // Assert.assertTrue("Verify surgical status text on popover for card expected=" + LastTimeEventtext + "; actual="
        // + actLastTimeEventtext, LastTimeEventtext.equalsIgnoreCase(actLastTimeEventtext));

        String Patientid = getKeyValue("popover.unitview.patientid");
        Assert.assertTrue(
                "Verify Patientid text on popover for card expected=" + Patientid + "; actual=" + actPatientidFieldText,
                Patientid.equalsIgnoreCase(actPatientidFieldText));
        String AdmissionReasontexttext = getKeyValue("popover.unitview.reason.of.admission");
        Assert.assertTrue(
                "Verify Admission Reason text on popover for card expected=" + AdmissionReasontexttext + "; actual="
                        + actAdmissionReasontexttext,
                AdmissionReasontexttext.equalsIgnoreCase(actAdmissionReasontexttext));
    }

    @Then("patient data should display as per locale on PACU bed")
    public void verifyPacuBedData(@Named("dob") String dob, @Named("RowNumber") int RowNumber,
            @Named("ColumnNumber") int ColumnNumber)
    {
        Card Bed = new Card(RowNumber, ColumnNumber);

        String actDob = Bed.getDateOfBirth();
        Assert.assertTrue("Verify Dob on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected=" + dob
                + "; actual=" + actDob, actDob.equalsIgnoreCase(dob));
    }

    @Then("patient data should display as per locale on PACU arriving bed")
    public void verifyICUBedData(@Named("dob") String dob, @Named("Position") int Position)
    {
        ArrivingListCard ArrivingListCard = new ArrivingListCard(Position);

        String actDob = ArrivingListCard.getDateOfBirth();
        Assert.assertTrue("Verify Dob on card at position=" + Position + " expected=" + dob + "; actual=" + actDob,
                actDob.equalsIgnoreCase(dob));
    }

    @Then("popover should display localized bed conflict message")
    public void verifyBedConflict()
            throws Exception
    {
        // select site
        String site = "Postop hospital";
        boolean bStatus = Site.getInstance().verifyActiveSite(site);
        if ( !bStatus )
        {
            Site.getInstance().clickAddSite();
            bStatus = Site.getInstance().AddSite(site);
            Thread.sleep(6000);
            PatientList.getInstance().waitForElementToAppear("add_site", site, Constants.HIGH_TIMEOUT);
        }
        // select department
        String department = "PACU general";
        Site.getInstance().selectDepartment(department);
        Site.getInstance().clickOnToggleViewButton();
        // open popover for conflict bed
        Card card = new Card(1, 2);
        card.clickOnCard();
        // verify message
        PopoverCard BedPopOver = new PopoverCard();

        Assert.assertEquals("Verify that Bed conflict message in popover",
                getKeyValue("popover.unitview.bed.conflictmsg"), BedPopOver.getBedConfictMessage());
        // verify table headers
        String TableHeaders = getKeyValue("popover.unitview.conflict.list.patient.name") + ";"
                + getKeyValue("popover.unitview.patientid") + ";"
                + getKeyValue("popover.unitview.conflict.list.admission.time");
        Assert.assertEquals("Verify conflict cases table headers", TableHeaders,
                BedPopOver.getBedConfictTableHeaders());

    }

}
