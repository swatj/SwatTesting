package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.functions.UpdateDate;
import com.ge.hac.pl.bdd.utility.Constants;

public class DepartmentAssignedSteps
{

    @When("the user charts time event <Preop Holding Room>")
    public void chartTimeEvent(@Named("TimeEvent") String timeEvent, @Named("FileName") String XmlFileName,
            @Named("PlannedTime") String time)
            throws IOException, InterruptedException
    {
        UpdateDate.getInstance().updateXML(timeEvent, XmlFileName, time);
        Thread.sleep(3000);

    }

    @Then("verify the patient's current view data in the Periop departments")
    public void verifyCurrentViewData(@Named("Care phase") String carePhaseValue,
            @Named("departments") String PeriopDepartment, @Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("Sched time") String schedTimeValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);

        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        String[] departments = PeriopDepartment.split(",");
        for (int i = 0; i < departments.length; i++)
        {

            System.out.println(departments[i]);
            System.out.println(i);
            Site.getInstance().selectDepartment(departments[i]);
            Filter.getInstance().clearAllFilter();
            Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
            int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

            if ( patientIDRowNumber == 0 )
            {
                Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

            }
            else
            {

                PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
                PatientListData.getInstance().verifyCarePhase(patientIDRowNumber, headerNames, carePhaseValue);
                PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);

            }
        }
    }

    @Then("verify the patient does not present other than periop departments")
    public void verifyCurrentViewDataInNonPeriopDepartment(@Named("Patient ID") String patientIDValue,
            @Named("Non Departments") String NonperiopDepartment)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);

        String[] departments = NonperiopDepartment.split(",");
        for (int i = 0; i < departments.length; i++)
        {
            Site.getInstance().selectDepartment(departments[i]);
            Filter.getInstance().clearAllFilter();
            Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);

            // Call select department
            int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

            if ( patientIDRowNumber == 0 )
            {
                Assert.assertSame("Verify Patient ID=" + patientIDValue + " is displayed on patient list", true, true);

            }
            else
            {
                Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");
            }
        }

    }

}
