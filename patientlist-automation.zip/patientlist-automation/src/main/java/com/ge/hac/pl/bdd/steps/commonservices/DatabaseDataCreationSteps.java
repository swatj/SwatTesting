/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.commonservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;

import com.ge.hac.pl.bdd.utility.BedParams;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.DbUtility;
import com.ge.hac.pl.bdd.utility.DepartmentParams;
import com.ge.hac.pl.bdd.utility.FieldValues;
import com.ge.hac.pl.bdd.utility.HospitalParams;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.RoomParams;
import com.ge.hac.pl.bdd.utility.StaffMemberValues;

/**
 * @author 305014106
 *
 */
public class DatabaseDataCreationSteps
{
    private static Logger logger                    = Logger.getLogger(DatabaseDataCreationSteps.class);

    private static String sqlInsertDocument         = "INSERT INTO Document (RevisionID, DocumentID, SessionID, TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID) "
            + " VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?) ";

    private static String sqlInsertDocumentOfFolder = "INSERT INTO SYS_DocumentsOfFolder (FolderID, FirstRevID, RelationType) VALUES (?, ?, ?) ";

    private static String sqlInsertRoom             = "INSERT INTO [dbo].[Room] ([firstrevid],[documentid],[revisionid],[SessionID],[creationtime],[id],[abbreviation],[name],[description],[mapcode],[mapname],[roomtypefrid]) "
            + " VALUES (?,?,?,?,CURRENT_TIMESTAMP,?,?,?,?,?,?,?)";

    private static String sqlInsertRoomBeds         = "INSERT INTO [dbo].[RoomBeds] ([firstrevid], [elementid], [bedfrid]) VALUES (?, ?, ?)";

    private static String sqlInsertBeds             = "INSERT INTO [dbo].[Bed] ([firstrevid],[documentid],[revisionid],[SessionID],[creationtime],[bedtypefrid],[id],[abbreviation],[name],[description],[mapcode],[mapname],[IsManagingDevices]) "
            + " VALUES (?,?,?,?,CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?)";

    private static String sqlGetBedFrid             = "SELECT [firstrevid] FROM [dbo].[Bed] WHERE [name] = ?";

    private static String sqlGetRoomFrid            = "SELECT [firstrevid] FROM [dbo].[Room] WHERE [name] = ?";

    private static String sqlInsertDepartmentRooms  = "INSERT INTO [dbo].[DepartmentRooms] ([firstrevid], [elementid], [roomfrid]) VALUES (?, ?, ?)";

    @When("the room data is created:$dataTable")
    public void createRooms(ExamplesTable dataTable)
    {
        PreparedStatement stInsertRooms = null;
        PreparedStatement stInsertDocument = null;
        PreparedStatement stInsertDocOfFolder = null;
        PreparedStatement stGetBedFrid = null;
        PreparedStatement stInsertRoomBeds = null;

        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS,
                PropertyFileHelper.getSqlScripts("pocDbUrl"));

        List<RoomParams> rooms = CommonUtility.extractRoomCreationParamsFromTable(dataTable);

        if ( conn != null )
        {
            try
            {
                stInsertRooms = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertRoom);
                stInsertDocument = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertDocument);
                stInsertDocOfFolder = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertDocumentOfFolder);
                stGetBedFrid = conn.prepareStatement(DatabaseDataCreationSteps.sqlGetBedFrid);
                stInsertRoomBeds = conn.prepareStatement(sqlInsertRoomBeds);

                for (RoomParams roomDetails : rooms)
                {
                    String frid = CommonUtility.getNewFrid();
                    insertRooms(stInsertRooms, roomDetails, frid);
                    insertDocuments(stInsertDocument, frid, "1G0000000002QD05DF", "1200C3");
                    insertDocsOfFolder(stInsertDocOfFolder, "1Q9024I", frid);

                    if ( roomDetails.getBedList() != null )
                    {
                        int elementId = 0;
                        for (String bedName : roomDetails.getBedList())
                        {
                            String bedFrid = "";
                            stGetBedFrid.setString(1, bedName.trim());

                            ResultSet rs = stGetBedFrid.executeQuery();
                            while (rs.next())
                            {
                                bedFrid = rs.getString("firstrevid");
                            }
                            rs.close();

                            if ( !bedFrid.isEmpty() )
                            {
                                insertRoomBeds(stInsertRoomBeds, frid, elementId, bedFrid);
                                elementId++;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stInsertRooms != null )
                    {
                        stInsertRooms.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stInsertDocOfFolder != null )
                    {
                        stInsertDocOfFolder.close();
                    }
                    if ( stGetBedFrid != null )
                    {
                        stGetBedFrid.close();
                    }
                    if ( stInsertRoomBeds != null )
                    {
                        stInsertRoomBeds.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }
        }
    }

    @When("the bed data is created:$dataTable")
    public void createBeds(ExamplesTable dataTable)
    {
        PreparedStatement stInsertBed = null;
        PreparedStatement stInsertDocument = null;
        PreparedStatement stInsertDocOfFolder = null;

        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS,
                PropertyFileHelper.getSqlScripts("pocDbUrl"));

        List<BedParams> beds = CommonUtility.extractBedCreationParamsFromTable(dataTable);

        if ( conn != null )
        {
            try
            {
                stInsertBed = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertBeds);
                stInsertDocument = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertDocument);
                stInsertDocOfFolder = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertDocumentOfFolder);

                for (BedParams bedDetails : beds)
                {
                    String frid = CommonUtility.getNewFrid();
                    insertBeds(stInsertBed, bedDetails, frid);

                    insertDocuments(stInsertDocument, frid, "1G0000000002QD04Z7", "1200BM");

                    insertDocsOfFolder(stInsertDocOfFolder, "1Q902KW", frid);
                }
            }
            catch (Exception e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stInsertBed != null )
                    {
                        stInsertBed.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stInsertDocOfFolder != null )
                    {
                        stInsertDocOfFolder.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }
        }

    }

    @When("the department data is created:$dataTable")
    public void createTestDepartments(ExamplesTable dataTable)
    {
        String pocDbUrl = PropertyFileHelper.getSqlScripts("pocDbUrl");
        String sqlGetDeptTypeFrid = "SELECT firstrevid from POC.dbo.DepartmentType where name = ?";
        String sqlGetDeptFolderId = "SELECT FolderID FROM SYS_Folder WHERE Name = ?";

        String sqlInsertDepartment = "INSERT INTO Department (CreationTime, DocumentID, RevisionID, FirstRevID, SessionID, description, mapcode, mapname, abbreviation, name, departmenttypefrid, id ) "
                + " VALUES ( CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlInsertDocument = "INSERT INTO Document (RevisionID, DocumentID, SessionID, TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID) "
                + " VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?) ";
        String sqlInsertDocumentOfFolder = "INSERT INTO SYS_DocumentsOfFolder (FolderID, FirstRevID, RelationType) VALUES (?, ?, ?) ";

        List<DepartmentParams> departments = CommonUtility.extractDeptCreationParamsFromTable(dataTable);

        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS, pocDbUrl);

        if ( conn != null )
        {
            PreparedStatement stGetDeptTypeFrid = null;
            PreparedStatement stGetDeptFolderId = null;
            PreparedStatement stInsertDepartment = null;
            PreparedStatement stInsertDocument = null;
            PreparedStatement stInsertDocOfFolder = null;
            PreparedStatement stGetRoomFrid = null;
            PreparedStatement stInsertDeptRooms = null;
            try
            {
                stGetDeptTypeFrid = conn.prepareStatement(sqlGetDeptTypeFrid);
                stGetDeptFolderId = conn.prepareStatement(sqlGetDeptFolderId);
                stInsertDepartment = conn.prepareStatement(sqlInsertDepartment);
                stInsertDocument = conn.prepareStatement(sqlInsertDocument);
                stInsertDocOfFolder = conn.prepareStatement(sqlInsertDocumentOfFolder);
                stGetRoomFrid = conn.prepareStatement(DatabaseDataCreationSteps.sqlGetRoomFrid);
                stInsertDeptRooms = conn.prepareStatement(DatabaseDataCreationSteps.sqlInsertDepartmentRooms);

                for (DepartmentParams deptDetails : departments)
                {
                    String newFrid = CommonUtility.getNewFrid();

                    // Get the department folder name
                    String deptFolderName = getFolderNameFromDeptType(deptDetails.getDeptType());
                    // Fetch the department type FRID
                    String deptTypeFrid = getDeptTypeFrid(stGetDeptTypeFrid, deptDetails.getDeptType());
                    // Fetch the department folder id
                    String deptFolderId = getDeptFolderId(stGetDeptFolderId, deptFolderName);
                    String loginDeptFolderId = getDeptFolderId(stGetDeptFolderId, getFolderNameFromDeptType("Login"));
                    System.out.println("deptTypeFrid = " + deptTypeFrid + " , deptFolderId = " + deptFolderId);

                    // Insert the values into department table
                    insertDepartments(stInsertDepartment, deptDetails, newFrid, deptTypeFrid);

                    // Insert values into Document table
                    insertDocuments(stInsertDocument, newFrid, "1G0000000002QD055M", "1200B5");

                    // Insert SYS_DocumentOfFolder for creating department under correct department type folder
                    insertDocsOfFolder(stInsertDocOfFolder, deptFolderId, newFrid);

                    // Insert SYS_DocumentOfFolder for creating department under Login Departments folder
                    insertLoginDeptShortcut(stInsertDocOfFolder, newFrid, loginDeptFolderId);

                    // insert the rooms in departmentRooms table
                    List<String> roomNames = deptDetails.getRoomList();

                    if ( roomNames != null )
                    {
                        int elementId = 0;
                        for (String roomName : roomNames)
                        {
                            String roomFrid = "";
                            stGetRoomFrid.setString(1, roomName.trim());

                            ResultSet rs = stGetRoomFrid.executeQuery();
                            while (rs.next())
                            {
                                roomFrid = rs.getString("firstrevid");
                            }
                            rs.close();

                            if ( !roomFrid.isEmpty() )
                            {
                                insertDepartmentRooms(stInsertDeptRooms, newFrid, elementId, roomFrid);
                                elementId++;
                            }
                        }
                    }

                }
            }
            catch (SQLException e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stGetDeptFolderId != null )
                    {
                        stGetDeptFolderId.close();
                    }
                    if ( stGetDeptTypeFrid != null )
                    {
                        stGetDeptTypeFrid.close();
                    }
                    if ( stInsertDepartment != null )
                    {
                        stInsertDepartment.close();
                    }
                    if ( stInsertDocOfFolder != null )
                    {
                        stInsertDocOfFolder.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stGetRoomFrid != null )
                    {
                        stGetRoomFrid.close();
                    }
                    if ( stInsertDeptRooms != null )
                    {
                        stInsertDeptRooms.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }

        }
    }

    @Then("the hospital data is created:$dataTable")
    public void createTestHospitals(ExamplesTable dataTable)
    {
        String pocDbUrl = PropertyFileHelper.getSqlScripts("pocDbUrl");
        String sqlInsertHospital = "INSERT INTO Hospital (SessionID, RevisionID, FirstRevID, DocumentID, CreationTime, id, mapname, code, abbreviation, description, mapcode, name ) "
                + " VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?,?, ?, ?, ?, ?, ?) ";
        String sqlInsertDocument = "INSERT INTO Document (RevisionID, DocumentID, SessionID, TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID) "
                + " VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?) ";
        String sqlInsertDocumentOfFolder = "INSERT INTO SYS_DocumentsOfFolder (FolderID, FirstRevID, RelationType) VALUES (?, ?, ?) ";
        String sqlInsertHospitalDept = "INSERT INTO HospitalDepartments ( ElementID, FirstRevID, departmentfrid ) VALUES (?, ?, ?)";
        String sqlGetDeptFrid = "SELECT firstrevid from POC.dbo.Department where name = ?";

        List<HospitalParams> hospitals = CommonUtility.extractHospitalCreationParamsFromTable(dataTable);

        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS, pocDbUrl);

        if ( conn != null )
        {
            PreparedStatement stInsertHospital = null;
            PreparedStatement stInsertDocument = null;
            PreparedStatement stInsertDocOfFolder = null;
            PreparedStatement stInsertHospitalDept = null;
            PreparedStatement stGetDeptFrid = null;

            try
            {
                stInsertHospital = conn.prepareStatement(sqlInsertHospital);
                stInsertDocument = conn.prepareStatement(sqlInsertDocument);
                stInsertDocOfFolder = conn.prepareStatement(sqlInsertDocumentOfFolder);
                stGetDeptFrid = conn.prepareStatement(sqlGetDeptFrid);
                stInsertHospitalDept = conn.prepareStatement(sqlInsertHospitalDept);

                for (HospitalParams hospitalDetails : hospitals)
                {
                    String newFrid = CommonUtility.getNewFrid();

                    // Insert the values into hospital table
                    insertHospital(stInsertHospital, hospitalDetails, newFrid);

                    // Insert values into Document table
                    insertDocuments(stInsertDocument, newFrid, "1G0000000002QD05BG", "3P0157");

                    // Insert SYS_DocumentOfFolder for creating hospital under the Hospitals folder
                    insertDocsOfFolder(stInsertDocOfFolder, "1Q901I7", newFrid);

                    // Insert the HospitalDepartments entry for each department

                    List<String> deptNames = hospitalDetails.getDepartmentList();

                    if ( deptNames != null && !deptNames.isEmpty() )
                    {
                        int elementId = 0;
                        for (String deptName : deptNames)
                        {
                            // first get the FRID of the department
                            String deptFrid = "";
                            stGetDeptFrid.setString(1, deptName.trim());
                            ResultSet rs = stGetDeptFrid.executeQuery();
                            while (rs.next())
                            {
                                deptFrid = rs.getString("firstrevid").trim();
                            }
                            rs.close();

                            if ( !CommonUtility.isStringEmptyOrNull(deptFrid) )
                            {
                                // insert the department of the hospital
                                stInsertHospitalDept.setInt(1, elementId);
                                stInsertHospitalDept.setString(2, newFrid);
                                stInsertHospitalDept.setString(3, deptFrid);

                                stInsertHospitalDept.executeUpdate();
                                elementId++;
                            }
                            else
                            {
                                logger.error("Hospital : " + hospitalDetails.getName()
                                        + " .No frid found for department : " + deptName);
                            }
                        }
                    }

                }
            }
            catch (SQLException e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stInsertHospital != null )
                    {
                        stInsertHospital.close();
                    }
                    if ( stInsertDocOfFolder != null )
                    {
                        stInsertDocOfFolder.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stInsertHospitalDept != null )
                    {
                        stInsertHospitalDept.close();
                    }
                    if ( stGetDeptFrid != null )
                    {
                        stGetDeptFrid.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }

        }
    }

    @Then("the departments are added to security profile:$dataTable")
    public void addDeptToSecProfile(ExamplesTable dataTable)
    {
        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS,
                PropertyFileHelper.getSqlScripts("pocDbUrl"));
        String sqlGetProfileFrid = "SELECT FirstRevID FROM Field WHERE ElementKey = '/A00G/' AND StringValue = ?";
        String sqlGetMaxCollectionid = "SELECT MAX(CollectionID) AS deptCount FROM Field WHERE FirstRevID = ? AND ElementKey LIKE '/DPTS/%/DPT/'";
        String sqlGetDeptFrid = "SELECT firstrevid FROM poc.dbo.Department WHERE name = ?";
        String sqlInsertDeptAccess = "INSERT INTO [dbo].[Field] ( [FieldID],[FirstRevID],[ValueRefID],[ElementKey],[ValueTime],[ValueType],[StringValue],[NumValue],[DatetimeValue],[BinaryValue],[UnitID],[ElementKeySize],[CollectionID],[LinkValue],[DocumentLinkType]) "
                + " VALUES (?, ?, NULL, ?,NULL, '100', NULL, NULL,NULL, NULL, NULL,'4', ?, ?, NULL)";
        PreparedStatement stGetProfileFrid = null;
        PreparedStatement stGetMaxCollectionid = null;
        PreparedStatement stInsertDeptAccess = null;
        PreparedStatement stGetDeptFrid = null;

        if ( conn != null )
        {
            try
            {
                stGetProfileFrid = conn.prepareStatement(sqlGetProfileFrid);
                stGetMaxCollectionid = conn.prepareStatement(sqlGetMaxCollectionid);
                stGetDeptFrid = conn.prepareStatement(sqlGetDeptFrid);
                stInsertDeptAccess = conn.prepareStatement(sqlInsertDeptAccess);

                for (Map<String, String> row : dataTable.getRows())
                {
                    String profileName = row.get("profileName");
                    String departmentList = row.get("departmentList");
                    List<String> departmentNames = Arrays.asList(departmentList.split(","));

                    /* Get the FRID of the supplied profile */
                    stGetProfileFrid.setString(1, profileName.trim());
                    ResultSet rs = stGetProfileFrid.executeQuery();
                    String profileFrid = null;
                    String deptCountValue = null;
                    String deptFrid = null;
                    while (rs.next())
                    {
                        profileFrid = rs.getString("FirstRevID");
                    }
                    rs.close();

                    /* Get the max collection id of departments associated with this profile */
                    stGetMaxCollectionid.setString(1, profileFrid.trim());
                    rs = stGetMaxCollectionid.executeQuery();
                    while (rs.next())
                    {
                        deptCountValue = rs.getString("deptCount");
                    }
                    int deptCount = Integer.parseInt(deptCountValue);
                    rs.close();

                    /* For each department in the feature file, insert a value in Field table and increment the dept count */
                    for (String deptName : departmentNames)
                    {
                        stGetDeptFrid.setString(1, deptName.trim());
                        rs = stGetDeptFrid.executeQuery();
                        while (rs.next())
                        {
                            deptFrid = rs.getString("firstrevid");
                        }
                        if ( !CommonUtility.isStringEmptyOrNull(deptFrid) )
                        {
                            stInsertDeptAccess.setString(1, CommonUtility.getNewFrid());
                            stInsertDeptAccess.setString(2, profileFrid);
                            stInsertDeptAccess.setString(3, "/DPTS/" + String.valueOf(deptCount) + "/DPT/");
                            stInsertDeptAccess.setString(4, String.valueOf(deptCount));
                            stInsertDeptAccess.setString(5, deptFrid);

                            stInsertDeptAccess.executeUpdate();
                            deptCount++;
                        }
                    }

                }
            }
            catch (SQLException e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stGetDeptFrid != null )
                    {
                        stGetDeptFrid.close();
                    }
                    if ( stGetMaxCollectionid != null )
                    {
                        stGetMaxCollectionid.close();
                    }
                    if ( stGetProfileFrid != null )
                    {
                        stGetProfileFrid.close();
                    }
                    if ( stInsertDeptAccess != null )
                    {
                        stInsertDeptAccess.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }
        }
    }

    @Then("the security profile is created:$dataTable")
    public void createSecurityProfile(ExamplesTable dataTable)
    {
        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS,
                PropertyFileHelper.getSqlScripts("pocDbUrl"));

        String sqlInsertDocument = "INSERT INTO Document (RevisionID, DocumentID, SessionID, TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID) "
                + " VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?) ";
        String sqlInsertDocumentOfFolder = "INSERT INTO SYS_DocumentsOfFolder (FolderID, FirstRevID, RelationType) VALUES (?, ?, ?) ";
        String sqlInsertField = "INSERT INTO [dbo].[Field] ( [FieldID],[FirstRevID],[ValueRefID],[ElementKey],[ValueTime],[ValueType],[StringValue],[NumValue],[DatetimeValue],[BinaryValue],[UnitID],[ElementKeySize],[CollectionID],[LinkValue],[DocumentLinkType]) "
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlInsertSysFolderAccess = "INSERT INTO [dbo].[SYS_FolderAccess] ([FolderID], [AccessLevel], [RoleDocFirstRevID]) VALUES (?, ?, ?)";
        // String sqlGetPatListFolderId = "SELECT [FolderID] FROM [dbo].[SYS_Folder] WHERE Name = 'Patient List'";

        PreparedStatement stInsertDocument = null;
        PreparedStatement stInsertDocumentOfFolder = null;
        PreparedStatement stInsertField = null;
        PreparedStatement stInsertSysFolderAccess = null;

        if ( conn != null )
        {
            try
            {
                stInsertDocument = conn.prepareStatement(sqlInsertDocument);
                stInsertDocumentOfFolder = conn.prepareStatement(sqlInsertDocumentOfFolder);
                stInsertField = conn.prepareStatement(sqlInsertField);
                stInsertSysFolderAccess = conn.prepareStatement(sqlInsertSysFolderAccess);

                for (Map<String, String> row : dataTable.getRows())
                {
                    String profileName = row.get("profileName");
                    String profileFrid = row.get("profileFrid");

                    FieldValues fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/A00G/",
                            null, "0", profileName.trim(), null, null, null, null, "2", null, null, null);

                    // Insert values into Document table
                    insertDocuments(stInsertDocument, profileFrid, "5000", "30");
                    // Insert SYS_DocumentOfFolder for creating hospital under the Hospitals folder
                    insertDocsOfFolder(stInsertDocumentOfFolder, "USERROLE", profileFrid);

                    // Insert into the field table with key = A00G
                    insertIntoFieldTable(stInsertField, fv);

                    // give access to Patient List
                    stInsertSysFolderAccess.setString(1, Constants.PATIENT_LIST_FOLDER_ID);
                    stInsertSysFolderAccess.setString(2, "1");
                    stInsertSysFolderAccess.setString(3, profileFrid);
                    stInsertSysFolderAccess.executeUpdate();

                    // can modify patient data
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/WA/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // can modify end cases and visits
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/WACC/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // can delete patient registrations and patient cases
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/DR/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // can restore cases from the warehouse
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/OA/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // can manage drug and fluid orders
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/MO/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // can record drugs and fluids without order
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/DA/", null, "5", "T",
                            null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // Profile description
                    fv = new FieldValues(CommonUtility.getNewFrid(), profileFrid.trim(), null, "/A00J/", null, "0",
                            "Profile description", null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                }
            }
            catch (SQLException e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stInsertDocumentOfFolder != null )
                    {
                        stInsertDocumentOfFolder.close();
                    }
                    if ( stInsertField != null )
                    {
                        stInsertField.close();
                    }
                    if ( stInsertSysFolderAccess != null )
                    {
                        stInsertSysFolderAccess.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }
        }
    }

    @Then("the user is created:$dataTable")
    public void createUsers(ExamplesTable dataTable)
    {
        Connection conn = DbUtility.getConnection(Constants.SQL_DRIVER_CLASS,
                PropertyFileHelper.getSqlScripts("pocDbUrl"));

        String sqlInsertDocument = "INSERT INTO Document (RevisionID, DocumentID, SessionID, TemplateDocumentID, TemplateID, Status, CreationTime, FirstRevID) "
                + " VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?) ";
        String sqlInsertDocumentOfFolder = "INSERT INTO SYS_DocumentsOfFolder (FolderID, FirstRevID, RelationType) VALUES (?, ?, ?) ";
        String sqlInsertField = "INSERT INTO [dbo].[Field] ( [FieldID],[FirstRevID],[ValueRefID],[ElementKey],[ValueTime],[ValueType],[StringValue],[NumValue],[DatetimeValue],[BinaryValue],[UnitID],[ElementKeySize],[CollectionID],[LinkValue],[DocumentLinkType]) "
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlInsertStaffMember = "INSERT INTO [dbo].[StaffMember] ([firstrevid],[documentid],[revisionid],[SessionID],[creationtime],[lastname],[firstname],[namesuffix],[title],[abbreviation],[ssid],[personid],[mapcode],[mapname]) "
                + " VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlInsertStaffJobRole = "INSERT INTO [dbo].[StaffJobRoles]  ([FirstRevID], [elementid], [jobrolefrid]) "
                + " VALUES (?, ?, ?) ";

        PreparedStatement stInsertDocument = null;
        PreparedStatement stInsertDocumentOfFolder = null;
        PreparedStatement stInsertField = null;
        PreparedStatement stInsertStaffMember = null;
        PreparedStatement stInsertStaffJobRole = null;

        if ( conn != null )
        {
            try
            {
                stInsertDocument = conn.prepareStatement(sqlInsertDocument);
                stInsertDocumentOfFolder = conn.prepareStatement(sqlInsertDocumentOfFolder);
                stInsertField = conn.prepareStatement(sqlInsertField);
                stInsertStaffMember = conn.prepareStatement(sqlInsertStaffMember);
                stInsertStaffJobRole = conn.prepareStatement(sqlInsertStaffJobRole);

                for (Map<String, String> row : dataTable.getRows())
                {
                    String staffMemFrid = CommonUtility.getNewFrid();

                    StaffMemberValues sm = new StaffMemberValues(staffMemFrid, staffMemFrid, "0", "0",
                            row.get("lastName"), row.get("firstName"), null, null, row.get("abbreviation"),
                            CommonUtility.getNewFrid(), CommonUtility.getNewFrid(), row.get("mapCode"),
                            row.get("mapName"));

                    // insert the staff member details
                    inertStaffMember(stInsertStaffMember, sm);

                    // insert the staff job role
                    insertStaffJobRole(stInsertStaffJobRole, staffMemFrid, "0", row.get("jobRoleFrid"));

                    // insert sys_documentOfFolder and document for inserting entry under present users folder
                    insertDocuments(stInsertDocument, staffMemFrid, "1G0000000002UW5IUB", "120004");
                    insertDocsOfFolder(stInsertDocumentOfFolder, "2K00000000000A42OU", staffMemFrid);

                    String newFrid = CommonUtility.getNewFrid();
                    insertDocuments(stInsertDocument, newFrid, "5000", "11");
                    insertDocsOfFolder(stInsertDocumentOfFolder, "USER", newFrid);

                    // Insert into the field table with key = LCK for account lock
                    FieldValues fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/LCK/", null, "5",
                            row.get("accountLock").trim(), null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // Insert into the field table with key = CNL for password change required
                    fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/CNL/", null, "5", "F", null, null,
                            null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // Insert into the field table with key = CNL for password change required
                    fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/STMB/", null, "100", null, null,
                            null, null, null, "2", null, staffMemFrid, null);
                    insertIntoFieldTable(stInsertField, fv);

                    // Insert into the field table for security profile
                    if(row.get("securityProfileFrid") != null)
                    {
	                    fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/ROLS/1/ROLE/", null, "100", null,
	                            null, null, null, null, "4", "1", row.get("securityProfileFrid"), null);
	                    insertIntoFieldTable(stInsertField, fv);
                    }

                    fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/PSWD/", null, "0",
                            "OHyZtdfyIRyF4fkwXv/6qA==", null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                    fv = new FieldValues(CommonUtility.getNewFrid(), newFrid, null, "/LNAM/", null, "0",
                            row.get("userName"), null, null, null, null, "2", null, null, null);
                    insertIntoFieldTable(stInsertField, fv);

                }
            }
            catch (SQLException e)
            {
                logger.error(e);
            }
            finally
            {
                try
                {
                    if ( conn != null )
                    {
                        conn.close();
                    }
                    if ( stInsertDocument != null )
                    {
                        stInsertDocument.close();
                    }
                    if ( stInsertDocumentOfFolder != null )
                    {
                        stInsertDocumentOfFolder.close();
                    }
                    if ( stInsertField != null )
                    {
                        stInsertField.close();
                    }
                    if ( stInsertStaffJobRole != null )
                    {
                        stInsertStaffJobRole.close();
                    }
                    if ( stInsertStaffMember != null )
                    {
                        stInsertStaffMember.close();
                    }
                }
                catch (SQLException e)
                {
                    logger.error(e);
                }
            }
        }
    }

    /**
     * @param stInsertStaffJobRole
     * @param staffMemFrid
     * @param string
     * @param string2
     * @throws SQLException
     */
    private void insertStaffJobRole(PreparedStatement stInsertStaffJobRole, String staffMemFrid, String elementId,
            String jobRoleFrid)
            throws SQLException
    {
        stInsertStaffJobRole.setString(1, staffMemFrid);
        stInsertStaffJobRole.setString(2, elementId);
        stInsertStaffJobRole.setString(3, jobRoleFrid);

        stInsertStaffJobRole.executeUpdate();
    }

    /**
     * @param stInsertStaffMember
     * @param sm
     * @throws SQLException
     */
    private void inertStaffMember(PreparedStatement stInsertStaffMember, StaffMemberValues sm)
            throws SQLException
    {
        stInsertStaffMember.setString(1, sm.getFirstRevid());
        stInsertStaffMember.setString(2, sm.getDocumentId());
        stInsertStaffMember.setString(3, sm.getRevisionId());
        stInsertStaffMember.setString(4, sm.getSessionId());
        stInsertStaffMember.setString(5, sm.getLastName());
        stInsertStaffMember.setString(6, sm.getFirstName());
        stInsertStaffMember.setString(7, sm.getNameSuffix());
        stInsertStaffMember.setString(8, sm.getTitle());
        stInsertStaffMember.setString(9, sm.getAbbreviation());
        stInsertStaffMember.setString(10, sm.getSsid());
        stInsertStaffMember.setString(11, sm.getPersonId());
        stInsertStaffMember.setString(12, sm.getMapCode());
        stInsertStaffMember.setString(13, sm.getMapName());

        stInsertStaffMember.executeUpdate();
    }

    /**
     * @param stInsertDocOfFolder
     * @param newFrid
     * @param loginDeptFolderId
     * @throws SQLException
     */
    private void insertLoginDeptShortcut(PreparedStatement stInsertDocOfFolder, String newFrid,
            String loginDeptFolderId)
            throws SQLException
    {
        stInsertDocOfFolder.setString(1, loginDeptFolderId);
        stInsertDocOfFolder.setString(2, newFrid);
        stInsertDocOfFolder.setInt(3, 1);

        stInsertDocOfFolder.executeUpdate();
    }

    /**
     * @param stInsertDocOfFolder
     * @param firstRevId
     * @param folderId
     * @throws SQLException
     */
    // private void insertDocsOfFolder(PreparedStatement stInsertDocOfFolder, String newFrid, String deptFolderId)
    private void insertDocsOfFolder(PreparedStatement stInsertDocOfFolder, String folderId, String firstRevId)
            throws SQLException
    {
        stInsertDocOfFolder.setString(1, folderId);
        stInsertDocOfFolder.setString(2, firstRevId);
        stInsertDocOfFolder.setInt(3, 0);

        stInsertDocOfFolder.executeUpdate();
    }

    /**
     * @param stInsertDocument
     * @param newFrid
     * @throws SQLException
     */
    private void insertDocuments(PreparedStatement stInsertDocument, String newFrid, String templateDocumentID,
            String templateId)
            throws SQLException
    {
        stInsertDocument.setInt(1, 0);
        stInsertDocument.setString(2, newFrid);
        stInsertDocument.setString(3, "0");
        stInsertDocument.setString(4, templateDocumentID);
        stInsertDocument.setString(5, templateId);
        stInsertDocument.setInt(6, 0);
        stInsertDocument.setString(7, newFrid);

        stInsertDocument.executeUpdate();
    }

    /**
     * @param stInsertDepartment
     * @param deptDetails
     * @param newFrid
     * @param deptTypeFrid
     * @throws SQLException
     */
    private void insertDepartments(PreparedStatement stInsertDepartment, DepartmentParams deptDetails, String newFrid,
            String deptTypeFrid)
            throws SQLException
    {
        stInsertDepartment.setString(1, newFrid);
        stInsertDepartment.setInt(2, 0);
        stInsertDepartment.setString(3, newFrid);
        stInsertDepartment.setString(4, "0");
        stInsertDepartment.setString(5, deptDetails.getDescription());
        stInsertDepartment.setString(6, deptDetails.getMapcode());
        stInsertDepartment.setString(7, deptDetails.getMapname());
        stInsertDepartment.setString(8, deptDetails.getAbbreviation());
        stInsertDepartment.setString(9, deptDetails.getName());
        stInsertDepartment.setString(10, deptTypeFrid);
        stInsertDepartment.setString(11, deptDetails.getId());

        stInsertDepartment.executeUpdate();
    }

    /**
     * @param stInsertHospital
     * @param hospitalDetails
     * @param newFrid
     */
    private void insertHospital(PreparedStatement stInsertHospital, HospitalParams hospitalDetails, String newFrid)
            throws SQLException
    {
        stInsertHospital.setString(1, "0");
        stInsertHospital.setInt(2, 0);
        stInsertHospital.setString(3, newFrid);
        stInsertHospital.setString(4, newFrid);
        stInsertHospital.setString(5, hospitalDetails.getId());
        stInsertHospital.setString(6, hospitalDetails.getMapname());
        stInsertHospital.setString(7, hospitalDetails.getCode());
        stInsertHospital.setString(8, hospitalDetails.getAbbreviation());
        stInsertHospital.setString(9, hospitalDetails.getDescription());
        stInsertHospital.setString(10, hospitalDetails.getMapcode());
        stInsertHospital.setString(11, hospitalDetails.getName());

        stInsertHospital.executeUpdate();

    }

    /**
     * @param deptDetails
     * @param deptFolderName
     * @return
     */
    private String getFolderNameFromDeptType(String deptType)
    {
        String deptFolderName = null;
        for (Constants.DeptFolderNames tab : Constants.DeptFolderNames.values())
        {
            if ( tab.getDeptKeyInFeature().equalsIgnoreCase(deptType.trim()) )
            {
                deptFolderName = tab.getDeptFolderName();
                break;
            }
        }
        return deptFolderName;
    }

    /**
     * @param stGetDeptFolderId
     * @param deptFolderId
     * @param deptFolderName
     * @return
     * @throws SQLException
     */
    private String getDeptFolderId(PreparedStatement stGetDeptFolderId, String deptFolderName)
            throws SQLException
    {
        String deptFolderId = null;
        ResultSet rs;

        stGetDeptFolderId.setString(1, deptFolderName);
        rs = stGetDeptFolderId.executeQuery();
        while (rs.next())
        {
            deptFolderId = rs.getString("FolderID");
        }

        rs.close();
        return deptFolderId;
    }

    /**
     * @param stGetDeptTypeFrid
     * @param deptDetails
     * @param deptTypeFrid
     * @return
     * @throws SQLException
     */
    private String getDeptTypeFrid(PreparedStatement stGetDeptTypeFrid, String deptType)
            throws SQLException
    {
        String deptTypeFrid = null;

        stGetDeptTypeFrid.setString(1, deptType);
        ResultSet rs = stGetDeptTypeFrid.executeQuery();
        while (rs.next())
        {
            deptTypeFrid = rs.getString("firstrevid");
        }
        rs.close();
        return deptTypeFrid;
    }

    private void insertIntoFieldTable(PreparedStatement stInsertLinkTable, FieldValues field)
            throws SQLException
    {
        stInsertLinkTable.setString(1, field.getFieldID());
        stInsertLinkTable.setString(2, field.getFirstRevID());
        stInsertLinkTable.setString(3, (field.getValueRefID() == null) ? null : field.getValueRefID());
        stInsertLinkTable.setString(4, field.getElementKey());
        stInsertLinkTable.setString(5, (field.getValueTime() == null) ? null : field.getValueTime());
        stInsertLinkTable.setString(6, field.getValueType());
        stInsertLinkTable.setString(7, (field.getStringValue() == null) ? null : field.getStringValue());
        stInsertLinkTable.setString(8, (field.getNumValue() == null) ? null : field.getNumValue());
        stInsertLinkTable.setString(9, (field.getDatetimeValue() == null) ? null : field.getDatetimeValue());

        if ( field.getBinaryValue() == null )
        {
            stInsertLinkTable.setNull(10, Types.VARBINARY);
        }
        else
        {
            stInsertLinkTable.setString(10, (field.getBinaryValue() == null) ? null : field.getBinaryValue());
        }

        stInsertLinkTable.setString(11, (field.getUnitID() == null) ? null : field.getUnitID());
        stInsertLinkTable.setString(12, field.getElementKeySize());
        stInsertLinkTable.setString(13, (field.getCollectionID() == null) ? null : field.getCollectionID());
        stInsertLinkTable.setString(14, (field.getLinkValue() == null) ? null : field.getLinkValue());
        stInsertLinkTable.setString(15, (field.getDocumentLinkType() == null) ? null : field.getDocumentLinkType());

        stInsertLinkTable.executeUpdate();
    }

    /**
     * @param stInsertBed
     * @param bedDetails
     * @param frid
     * @throws SQLException
     */
    private void insertBeds(PreparedStatement stInsertBed, BedParams bedDetails, String frid)
            throws SQLException
    {
        stInsertBed.setString(1, frid.trim());
        stInsertBed.setString(2, frid.trim());
        stInsertBed.setInt(3, 0);
        stInsertBed.setString(4, "0");
        stInsertBed.setNull(5, Types.NVARCHAR);
        stInsertBed.setString(6, bedDetails.getId());
        stInsertBed.setString(7, bedDetails.getAbbreviation());
        stInsertBed.setString(8, bedDetails.getName());
        stInsertBed.setString(9, bedDetails.getDescription());
        stInsertBed.setString(10, bedDetails.getMapcode());
        stInsertBed.setString(11, bedDetails.getMapname());
        stInsertBed.setString(12, bedDetails.getIsManagingDevices());

        stInsertBed.executeUpdate();
    }

    /**
     * @param stInsertRooms
     * @param roomDetails
     * @param frid
     * @throws SQLException
     */
    private void insertRooms(PreparedStatement stInsertRoom, RoomParams roomDetails, String frid)
            throws SQLException
    {

        stInsertRoom.setString(1, frid.trim());
        stInsertRoom.setString(2, frid.trim());
        stInsertRoom.setInt(3, 0);
        stInsertRoom.setString(4, "0");
        stInsertRoom.setString(5, roomDetails.getId());
        stInsertRoom.setString(6, roomDetails.getAbbreviation());
        stInsertRoom.setString(7, roomDetails.getName());
        stInsertRoom.setString(8, roomDetails.getDescription());
        stInsertRoom.setString(9, roomDetails.getMapcode());
        stInsertRoom.setString(10, roomDetails.getMapname());
        stInsertRoom.setString(11, roomDetails.getRoomType());

        stInsertRoom.executeUpdate();

    }

    /**
     * @param stInsertRoomBeds
     * @param frid
     * @param elementId
     * @param bedFrid
     * @throws SQLException
     */
    private void insertRoomBeds(PreparedStatement stInsertRoomBeds, String frid, int elementId, String bedFrid)
            throws SQLException
    {
        stInsertRoomBeds.setString(1, frid);
        stInsertRoomBeds.setInt(2, elementId);
        stInsertRoomBeds.setString(3, bedFrid);

        stInsertRoomBeds.executeUpdate();

    }

    /**
     * @param stInsertDeptRooms
     * @param newFrid
     * @param elementId
     * @param roomFrid
     * @throws SQLException
     */
    private void insertDepartmentRooms(PreparedStatement stInsertDeptRooms, String newFrid, int elementId,
            String roomFrid)
            throws SQLException
    {
        stInsertDeptRooms.setString(1, newFrid);
        stInsertDeptRooms.setInt(2, elementId);
        stInsertDeptRooms.setString(3, roomFrid);

        stInsertDeptRooms.executeUpdate();

    }
}
