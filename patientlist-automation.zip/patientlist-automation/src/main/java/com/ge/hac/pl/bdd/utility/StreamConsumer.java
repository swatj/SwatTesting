package com.ge.hac.pl.bdd.utility;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class StreamConsumer extends Thread
{
    InputStream inputStream = null;

    /**
     * 
     */
    public StreamConsumer(InputStream is)
    {
        this.inputStream = is;
    }

    public void run()
    {
        try
        {
            InputStreamReader isr = new InputStreamReader(this.inputStream);
            BufferedReader br = new BufferedReader(isr);
            String line = null;
            while ((line = br.readLine()) != null)
            {
                System.out.println(line);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
