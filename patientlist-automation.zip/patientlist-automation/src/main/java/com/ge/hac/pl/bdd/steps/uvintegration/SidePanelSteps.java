/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.functions.SidePanel;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class SidePanelSteps

{
    int    widthOfBedLayoutContainerInCollapsedState = 0;
    int    widthOfBedLayoutContainerInExpandedState  = 0;
    String arrivingBedData                           = "ArrivingList_PatientBed",
            arrvingPatientName = "ArrivingList_Patientname", arrivingPatientID = "ArrivingList_PatientId",
            arrivingPatientSex = "ArrivingList_PatientSex", arrivingPatientProcedure = "ArrivingList_PatientProcedure",
            arrvingLastTime = "ArrivingList_LastTimeEvent", arrvingPatientSurgeon = "ArrivingList_Surgeon",
            arrivingPatientAnestheologist = "ArrivingList_Anestheologist", arrivingPatientDob = "ArrivingList_Dob",
            arrivingPatientAge = "ArrivingList_Age", arrivingisolation = "ArrivingList_Isolation",
            arrivinginfection = "ArrivingList_Infection", arrivingStaffIndicator = "ArrivingList_StaffIndicator";

    @Then("List panel will display in <mode> mode")
    public void verifyArrivingListPanelMode(@Named("mode") String panelMode)
            throws IOException
    {
        if ( panelMode.equalsIgnoreCase("expanded") )
        {
            Assert.assertEquals("side panel displays in expanded mode.", true, SidePanel.isSidePanelExpanded());
        }
        else if ( panelMode.equalsIgnoreCase("collapsed") )
        {
            Assert.assertEquals("side panel displays in collapsed mode.", true, SidePanel.isSidePanelCollapsed());
        }

    }

    @Then("List panel will show <tabs> tabs")
    public void verifyArrivingListPanelTabs(@Named("tabs") String tabHeader)
            throws IOException
    {
        Assert.assertEquals("side panel shows arriving list tab", tabHeader,
                SidePanel.getArrivalTabLabelInExpandedMode());

    }

    // TODO - This should test what is the current selected tab
    @Then("List panel has <selectedTab> tab selected")
    public void verifyArrivingListPanelSelectedTab(@Named("selectedTab") String tabHeader)
            throws IOException
    {
        Assert.assertEquals("side panel has arriving list tab selected", tabHeader,
                SidePanel.getArrivalTabLabelInExpandedMode());

    }

    @Then("List panel shows button to collapse the panel")
    public void VerifyCollapseButtonOfSidePanel()
            throws IOException
    {
        Assert.assertEquals("collapse button should display on side panel.", true,
                SidePanel.isSidePanelCollapseButtonDisplayed());
    }

    @When("user clicks on the button to collapse the list panel")
    public void ClickOnCollapseButtonOfSidePanel()
            throws IOException
    {
        widthOfBedLayoutContainerInExpandedState = SidePanel.getWidthOfBedLayoutContainer();
        SidePanel.clickOnCollapse();

    }

    // TODO - is this checking for arrivals name?
    @Then("List panel will show <tabs> tabs in collapsed mode")
    public void VerifyArrivingPatientListPanelCollapseStateName(@Named("tabs") String Collapsed_tabs_Name)
            throws IOException
    {
        Assert.assertEquals("side panel shows tabs " + Collapsed_tabs_Name, Collapsed_tabs_Name,
                SidePanel.getArrivalTabLabelInCollapsedMode());
    }

    // TODO - there should be a button to expand
    @Then("List panel will show button to expand the panel")
    public void VerifyArrivingPatientListPanelButtonToExpand()
            throws IOException
    {
        // TODO
    }

    @When("users clicks on the button to expand the list panel")
    public void ClicksOnExpandButtonOfSidePanel()
            throws IOException
    {
        widthOfBedLayoutContainerInCollapsedState = SidePanel.getWidthOfBedLayoutContainer();
        SidePanel.clickOnExpand();

    }

    @Then("side panel should expand and show a <Tabs> tabs header")
    public void VerifyArrivingPatientListPanelExpandState(@Named("Tabs") String SidepaneltabsHeader)
            throws IOException
    {
        Assert.assertEquals("side panel should expand and show " + SidepaneltabsHeader + "tabs header.", true,
                SidePanel.isSidePanelExpanded());
        Assert.assertEquals("side panel should expand and show " + SidepaneltabsHeader, SidepaneltabsHeader,
                SidePanel.getArrivalTabLabelInExpandedMode());

    }

    @When("the user selects <department1> from department tab")
    public void SelectICUDepartment(@Named("department1") String department)
            throws IOException, InterruptedException
    {
        Site.getInstance().selectDepartment(department);
    }

    @Then("the user selects <changedDepartment> from department tab")
    public void SelectDepartment(@Named("changedDepartment") String department)
            throws IOException, InterruptedException
    {
        Site.getInstance().selectDepartment(department);
    }

    @When("the user switch to patient list view and back resource view")
    public void ToggleBetweenView()
            throws IOException
    {
        Site.getInstance().clickOnToggleViewButton();
        Site.getInstance().clickOnToggleViewButton();
    }

    @Then("beds in the grid panel scale up")
    public void verifyBedLayoutContainerScaledUp()
            throws IOException
    {
        int widthAfterCollapse = SidePanel.getWidthOfBedLayoutContainer();
        Assert.assertTrue(
                "bed layout container gets scaled up actual =" + widthAfterCollapse + " expected="
                        + widthOfBedLayoutContainerInExpandedState,
                widthAfterCollapse > widthOfBedLayoutContainerInExpandedState);
    }

    @Then("beds in the grid panel scale down")
    public void verifyBedLayoutContainerScaledDown()
            throws IOException
    {

        int widthAfterExpand = SidePanel.getWidthOfBedLayoutContainer();
        Assert.assertTrue(
                "bed layout container gets scaled down actual=" + widthAfterExpand + " expected="
                        + widthOfBedLayoutContainerInCollapsedState,
                widthAfterExpand < widthOfBedLayoutContainerInCollapsedState);
    }

    @Then("only $patientCases patient cards displayed in arriving list")
    public void verifyArrivingListCases(String patientCases)
            throws IOException, InterruptedException
    {
        List<WebElement> patientList = SeleniumUtility.getInstance()
                .findElements("NoOfPatientsAvailableinArrivingList");
        int allCasesAvailable = patientList.size();
        Assert.assertEquals("No of Patients appearing in Arriving List", Integer.parseInt(patientCases),
                allCasesAvailable);

    }

    @Then("the user verifies all the patients data available in list: $dataTable")
    public void verifyArrivingPatientInfo(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        int iter = 0;
        for (Map<String, String> row : dataTable.getRows())
        {
            // System.out.println(" Row details:" +row);
            String bedno = row.get("Bed No");
            String patientname = row.get("PatientName");
            String patientid = row.get("PatientID");
            String sex = row.get("Sex");
            String surgicalProcedure = row.get("SurgicalProcedure");
            String lasttimeevent = row.get("LastTimeEvent");
            String surgeon = row.get("Surgeon");
            String anestheologist = row.get("Anestheologist");
            String dob = row.get("DOB");
            String age = row.get("Age");
            String isolation = row.get("isolation");
            String infection = row.get("infection");
            String actualbedno = Site.getInstance().getDetailsByRow(arrivingBedData, iter);
            String actualpatientname = Site.getInstance().getDetailsByRow(arrvingPatientName, iter);
            String actualpatientid = Site.getInstance().getDetailsByRow(arrivingPatientID, iter);
            String actualsex = Site.getInstance().getDetailsByRow(arrivingPatientSex, iter);
            String actualsurgicalprocedure = Site.getInstance().getDetailsByRow(arrivingPatientProcedure, iter);
            // String actuallasttimeevent = Site.getInstance().getDetailsByRow(arrvingLastTime,iter);
            String actualsurgeon = Site.getInstance().getDetailsByRow(arrvingPatientSurgeon, iter);
            String actualanestheologist = Site.getInstance().getDetailsByRow(arrivingPatientAnestheologist, iter);
            String actualdob = Site.getInstance().getDetailsByRow(arrivingPatientDob, iter);
            String actualage = Site.getInstance().getDetailsByRow(arrivingPatientAge, iter);
            String actualisolation = String.valueOf(Site.getInstance().isDisplayed(arrivingisolation, iter));
            String actualinfection = String.valueOf(Site.getInstance().isDisplayed(arrivinginfection, iter));
            Assert.assertTrue("Verify the (:" + row + ")Bed No of the Patient is displayed ,expected=" + bedno
                    + ", actual=" + actualbedno, bedno.equalsIgnoreCase(actualbedno));
            Assert.assertTrue("Verify the (:" + row + ")Patientname of the Patient is displayed ,expected="
                    + patientname + ", actual=" + actualpatientname, patientname.equalsIgnoreCase(actualpatientname));
            Assert.assertTrue("Verify the (:" + row + ")PatientId of the Patient is displayed ,expected=" + patientid
                    + ", actual=" + actualpatientid, patientid.equalsIgnoreCase(actualpatientid));
            Assert.assertTrue("Verify the (:" + row + ")Sex of the Patient is displayed ,expected=" + sex + ", actual="
                    + actualsex, sex.equalsIgnoreCase(actualsex));
            Assert.assertTrue(
                    "Verify the (:" + row + ")SurgicalProcedure of the Patient is displayed ,expected="
                            + surgicalProcedure + ", actual=" + surgicalProcedure,
                    surgicalProcedure.equalsIgnoreCase(actualsurgicalprocedure));
            // Assert.assertTrue("Verify the (:"+row+ ")TimeEvent of the Patient is displayed ,expected=" + lasttimeevent + ", actual=" + actuallasttimeevent,
            // lasttimeevent.equalsIgnoreCase(actuallasttimeevent));
            Assert.assertTrue("Verify the (:" + row + ")Surgeon of the Patient is displayed ,expected=" + surgeon
                    + ", actual=" + actualsurgeon, surgeon.equalsIgnoreCase(actualsurgeon));
            Assert.assertTrue(
                    "Verify the (:" + row + ")Anestheologist of the Patient is displayed ,expected=" + anestheologist
                            + ", actual=" + actualanestheologist,
                    anestheologist.equalsIgnoreCase(actualanestheologist));
            Assert.assertTrue("Verify the (:" + row + ")dob of the Patient is displayed ,expected=" + dob + ", actual="
                    + actualdob, dob.equalsIgnoreCase(actualdob));
            Assert.assertTrue("Verify the (:" + row + ")age of the Patient is displayed ,expected=" + age + ", actual="
                    + actualage, age.equalsIgnoreCase(actualage));
            Assert.assertTrue("Verify the (:" + row + ")infection of the Patient is displayed ,expected=" + infection
                    + ", actual=" + actualinfection, infection.equalsIgnoreCase(actualinfection));
            Assert.assertTrue("Verify the (:" + row + ")isolation of the Patient is displayed ,expected=" + isolation
                    + ", actual=" + actualisolation, isolation.equalsIgnoreCase(actualisolation));
            iter++;
        }
    }

    @Then("the user verifies staff data in the arriving list card: $dataTable")
    public void verifyArrivingStaffDetails(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        int iter = 0;
        for (Map<String, String> row : dataTable.getRows())
        {
            String surgeon = row.get("Surgeon");
            String anestheologist = row.get("Anestheologist");
            String actualsurgeon = Site.getInstance().getDetailsByRow(arrvingPatientSurgeon, iter);
            String actualanestheologist = Site.getInstance().getDetailsByRow(arrivingPatientAnestheologist, iter);
            Assert.assertTrue("Verify the (:" + row + ")Surgeon of the Patient is displayed ,expected=" + surgeon
                    + ", actual=" + actualsurgeon, surgeon.equalsIgnoreCase(actualsurgeon));
            Assert.assertTrue(
                    "Verify the (:" + row + ")Anestheologist of the Patient is displayed ,expected=" + anestheologist
                            + ", actual=" + actualanestheologist,
                    anestheologist.equalsIgnoreCase(actualanestheologist));
            iter++;
        }
    }

    @Then("the user verifies procedure data in the arriving list card: $dataTable")
    public void verifyProcedureDetails(ExamplesTable dataTable)
            throws IOException, InterruptedException
    {
        int iter = 0;
        for (Map<String, String> row : dataTable.getRows())
        {
            String surgicalProcedure = row.get("SurgicalProcedure");
            String actualsurgicalprocedure = Site.getInstance().getDetailsByRow(arrivingPatientProcedure, iter);
            Assert.assertTrue(
                    "Verify the (:" + row + ")SurgicalProcedure of the Patient is displayed ,expected="
                            + surgicalProcedure + ", actual=" + surgicalProcedure,
                    surgicalProcedure.equalsIgnoreCase(actualsurgicalprocedure));
            iter++;
        }
    }

    /*
     * @Then("the color indicator displayed for logged in staff user on arriving list: $dataTable")
     * public void verifyColorIndicatorForArrivingStaffDetails(ExamplesTable dataTable) throws IOException, InterruptedException
     * {
     * int iter =0;
     * for (Map<String, String> row : dataTable.getRows())
     * {
     * String staffIndicatorColorFormat=row.get("StaffIndicatorColorFormat");
     * String actualStaffIndicatorColorValue;
     * actualStaffIndicatorColorValue = Site.getInstance().getStaffIndicatorDetailsByRow(arrivingStaffIndicator,iter);
     * Assert.assertTrue("Verify staff color indicator on card  expected= " + staffIndicatorColorFormat + "; actual=" + actualStaffIndicatorColorValue,
     * actualStaffIndicatorColorValue.equalsIgnoreCase(staffIndicatorColorFormat));
     * iter++;
     * }
     * }
     */

    @Then("the color indicator displayed for logged in staff user on arriving list")
    public void verifyColorIndicatorForArrivingStaffDetails(@Named("Staff_Role") String Staff_Role,
            @Named("StaffIndicatorColorFormat") String StaffIndicatorColorFormat)
            throws IOException, InterruptedException
    {
        String actualStaffIndicatorColorValue;
        actualStaffIndicatorColorValue = Site.getInstance().getStaffIndicatorDetailsByRow(arrivingStaffIndicator);
        Assert.assertTrue(
                "Verify staff color indicator on card  expected= " + StaffIndicatorColorFormat + "; actual="
                        + actualStaffIndicatorColorValue,
                actualStaffIndicatorColorValue.equalsIgnoreCase(StaffIndicatorColorFormat));

    }
}
