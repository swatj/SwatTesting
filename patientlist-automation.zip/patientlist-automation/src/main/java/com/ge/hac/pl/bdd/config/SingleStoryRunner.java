/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */

package com.ge.hac.pl.bdd.config;

import java.util.List;
import java.util.Properties;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.parsers.gherkin.GherkinStoryParser;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.junit.Test;

import com.ge.hac.pl.bdd.steps.plintegration.ColorCodeSteps;
import com.ge.hac.pl.bdd.steps.plintegration.ColumnSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CommonSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CurrentLocationSteps;
import com.ge.hac.pl.bdd.steps.plintegration.CurrentViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DateLabelSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DefaultSortingSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DepartmentAssignedSteps;
import com.ge.hac.pl.bdd.steps.plintegration.DepartmentSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FilterSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FilteringAndSortingSteps;
import com.ge.hac.pl.bdd.steps.plintegration.FutureViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.LocalizationSteps;
import com.ge.hac.pl.bdd.steps.plintegration.NewColumnsSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PastViewSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PatientListCSSSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PatientListDataSteps;
import com.ge.hac.pl.bdd.steps.plintegration.PopoverSteps;
import com.ge.hac.pl.bdd.steps.plintegration.SiteSteps;

public class SingleStoryRunner extends JUnitStories
{
    // change me
    private static final String STORIES = "**/BDD2075.feature";

    public SingleStoryRunner()
    {
        configuredEmbedder().embedderControls().doGenerateViewAfterStories(true).doIgnoreFailureInStories(false)
                .doIgnoreFailureInView(false).useThreads(1).useStoryTimeoutInSecs(1500000);

    }

    @Override
    public Configuration configuration()
    {
        Properties viewResources = new Properties();
        viewResources.put("decorateNonHtml", "true");

        return new MostUsefulConfiguration().useStoryParser(new GherkinStoryParser()).useStoryReporterBuilder(
                new StoryReporterBuilder().withFormats(Format.STATS, Format.CONSOLE, Format.HTML, Format.TXT)
                        .withViewResources(viewResources).withFailureTrace(true)
                        .withReporters(new CustomStoryReporter()));

    }

    @Test
    @Override
    public void run()
            throws Throwable
    {
        super.run();
    }

    @Override
    public InjectableStepsFactory stepsFactory()
    {
        // change me
        return new InstanceStepsFactory(configuration(), new CommonSteps(), new SiteSteps(), new DateLabelSteps(),
                new DepartmentSteps(), new PatientListCSSSteps(), new ColumnSteps(), new CurrentViewSteps(),
                new FutureViewSteps(), new PastViewSteps(), new PatientListDataSteps(), new NewColumnsSteps(),
                new FilterSteps(), new CurrentLocationSteps(), new DepartmentAssignedSteps(),
                new FilteringAndSortingSteps(), new DefaultSortingSteps(), new PopoverSteps(), new ColorCodeSteps(),
                new LocalizationSteps());

    }

    @Override
    protected List<String> storyPaths()
    {
        // One must manually copy the Stories into the classes output directory.
        return new StoryFinder().findPaths(CodeLocations.codeLocationFromClass(this.getClass()), STORIES, "");
    }

}
