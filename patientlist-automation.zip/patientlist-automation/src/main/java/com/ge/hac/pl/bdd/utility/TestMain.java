package com.ge.hac.pl.bdd.utility;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ge.hac.ca.bdd.common.CAHelper;
import com.ge.hac.ca.common.interfaces.IHealthHistoryServiceRemote;
import com.ge.hac.ca.common.interfaces.IPatientServiceRemote;
import com.ge.hac.ca.common.interfaces.PropertySessionRemote;
import com.ge.hac.ca.common.sm.IState;
import com.ge.hac.ca.common.util.ServiceLocator;
import com.ge.hac.ca.common.util.ServiceLocator.Services;
import com.ge.hac.ca.ea.common.CAPatientInfo;
import com.ge.hac.ca.ea.ext.operational.person.Patient_ContactPersonExt;
import com.ge.hac.ca.server.casemanagement.PatientService;
import com.ge.hac.ca.server.patientrisks.IPatientRisksServiceLocal;
import com.ge.hac.ca.server.patientrisks.PatientRisksService;
import com.ge.hac.common.ea.dto.operational.person.Patient_ContactPerson;

public class TestMain
{

    public static void main(String[] args)
    {
        System.out.println(PropertyFileHelper.getObjectIdentifier("logout"));
        System.out.println(PropertyFileHelper.getObjectIdentifier("invalidCredentialLink"));
        System.out.println(PropertyFileHelper.getObjectIdentifier("error_message"));
        System.out.println(PropertyFileHelper.getObjectIdentifier("add_site"));
        
        System.out.println(PropertyFileHelper.getProjectProperty("FUTURE_DATE_MORE_THEN30DAYS"));
        System.out.println(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
        System.out.println(PropertyFileHelper.getProjectProperty("CA_VERSION"));
        System.out.println(PropertyFileHelper.getProjectProperty("FUTURE_DATE"));
        
        System.out.println(PropertyFileHelper.getSqlScripts("Updated_Column"));
        System.out.println(PropertyFileHelper.getSqlScripts("delete_H_SYS_Screeconfig_User_Config"));
        System.out.println(PropertyFileHelper.getSqlScripts("delete_SYS_Screeconfig_User_Config"));
        System.out.println(PropertyFileHelper.getSqlScripts("update_locale"));
//        InitialContext ctx;
//        try {
//            System.setProperty(javax.naming.Context.PROVIDER_URL, "remote://localhost:4899");
//            System.out.println(System.getProperty(javax.naming.Context.PROVIDER_URL));
//            ServiceLocator.getInstance();
//            //IPatientServiceRemote p = (IPatientServiceRemote)ServiceLocator.getService(Services.PATIENTSERVICE);
//            try
//            {
//                Patient_ContactPersonExt p = CAHelper.initNewPatient();//  ServiceLocator.getInstance().lookup(Services.PATIENTSERVICE);
//                p.setFirstname("bdd1");
//                p.setLastname("bdd1");
//                CAHelper.createNewPatientFromInit(p);
//                System.out.println(p.toString());
//                //Patient_ContactPersonExt pc = p.getInitPatient(CAHelper.getState("0"));
//            }
//            catch (Exception e)
//            {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }
//            //CAHelper.createNewPatientFromSnapshot(snapshotName, shiftTime, offsetFromCurrentTime, generateNewPatientContext, valueReplacements)
//            CAPatientInfo c = CAHelper.createNewPatientFromSnapshot("snap01.xml", false, 0, true, null);
//            System.out.println("done  " + c.toString());
//            
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//        try
//        {
//            IPatientServiceRemote psr = CAHelper.getPatientServiceRemote();
//            IState state = CAHelper.getState("0");
//            System.out.println(state.toString());
//            Patient_ContactPersonExt p = psr.getInitPatient(state);
//            //Patient_ContactPersonExt p = CAHelper.initNewPatient();
//            System.out.println(psr.toString());
//            System.out.println(p.toString());
//        }
//        catch (Exception e)
//        {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
        //System.out.println(psr.toString());

    }

}
