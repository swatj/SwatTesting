/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.config;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.GivenStories;
import org.jbehave.core.model.Meta;
import org.jbehave.core.model.Narrative;
import org.jbehave.core.model.OutcomesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.jbehave.core.model.StoryDuration;
import org.jbehave.core.reporters.NullStoryReporter;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;

public class CustomStoryReporter extends NullStoryReporter
{
    private static Logger logger          = Logger.getLogger(CustomStoryReporter.class);
    private static String imageFilepath   = PropertyFileHelper.getProjectProperty("basedir")
                                                  + "\\target\\Jbehave\\View\\Screenshots";
    private static String featureFileName = "Temp";
    private static String ImageFileName   = "Image";
    private static int    imageCounter    = 0;

    public void afterExamples()
    {

    }

    public void afterScenario()
    {

    }

    public void afterStory(boolean arg0)
    {

        imageCounter = 0;
    }

    public void beforeExamples(List<String> arg0, ExamplesTable arg1)
    {

    }

    public void beforeScenario(String arg0)
    {

    }

    public void beforeStep(String arg0)
    {

    }

    public void beforeStory(Story storyName, boolean arg1)
    {
        if ( storyName.getName().endsWith(".feature") )
        {
            featureFileName = storyName.getName().replace(".feature", "");

        }
        if ( !featureFileName.equalsIgnoreCase("Temp") )
        {
            if ( !storyName.getName().equalsIgnoreCase("AfterStories") )
            {
                if ( !storyName.getName().equalsIgnoreCase("BeforeStories") )

                clearDirectory(imageFilepath + "\\" + featureFileName);
            }
        }
    }

    public void dryRun()
    {

    }

    public void example(Map<String, String> arg0)
    {

    }

    public void failed(String arg0, Throwable arg1)
    {
        screenshot(Constants.STEP_STATUS_FAILED);
    }

    public void failedOutcomes(String arg0, OutcomesTable arg1)
    {

    }

    public void givenStories(GivenStories arg0)
    {

    }

    public void givenStories(List<String> arg0)
    {

    }

    public void ignorable(String arg0)
    {
        screenshot(Constants.STEP_STATUS_IGNORABLE);
    }

    public void narrative(Narrative arg0)
    {

    }

    public void notPerformed(String arg0)
    {
        screenshot(Constants.STEP_STATUS_NOTPERFORMED);
    }

    public void pending(String arg0)
    {
        screenshot(Constants.STEP_STATUS_PENDING);
    }

    public void pendingMethods(List<String> arg0)
    {

    }

    public void restarted(String arg0, Throwable arg1)
    {

    }

    public void scenarioMeta(Meta arg0)
    {

    }

    public void scenarioNotAllowed(Scenario arg0, String arg1)
    {

    }

    public void storyCancelled(Story arg0, StoryDuration arg1)
    {

    }

    public void storyNotAllowed(Story arg0, String arg1)
    {

    }

    public void successful(String arg0)
    {
        screenshot(Constants.STEP_STATUS_PASS);
    }

    public void screenshot(String prefix)
    {
    	if(PropertyFileHelper.getProjectProperty("screenshot").equalsIgnoreCase("true")){
    		try
            {
               
                imageCounter++;
                PatientList.getInstance().captureScreenShot(imageFilepath + "\\" + featureFileName,
                        imageCounter + "-" + prefix + "_" + ImageFileName);
                logger.debug("Screenshot captured at =" + imageFilepath + "\\" + featureFileName + "\\" + imageCounter
                        + "-" + prefix + "_" + ImageFileName);
                // add screenshot to html report if step failed.
                if ( Constants.STEP_STATUS_FAILED.equalsIgnoreCase(prefix) )
                {
                    CustomWebDriverHtmlOutput.HTMLWriter.println("<div class=\"step successful\">"
                            + "<img src=\"screenshots/" + featureFileName + "/" + imageCounter + "-" + prefix + "_"
                            + ImageFileName + ".jpg\" alt=\"successful screenshot\"/></div>\n");
                }
            }
            catch (IOException e)
            {
                logger.error("Exception in com.ge.hac.pl.bdd.config.CustomStoryReporter.screenshot(String)", e);
            }
    	}
       
    	
    }

    public void clearDirectory(String dirPath)
    {
        File file = new File(dirPath);
        if ( file.exists() )
        {
            String[] filesToDelete;
            if ( file.isDirectory() )
            {
                filesToDelete = file.list();
                for (int i = 0; i < filesToDelete.length; i++)
                {
                    File fileToDelete = new File(file, filesToDelete[i]);
                    System.out.println(fileToDelete);
                    fileToDelete.delete();
                }
            }
        }
    }

}
