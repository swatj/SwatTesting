/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Manjunatha.H     22-April-2016         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author 212357558
 * 
 */
public class GridPanel
{

    private static Logger    logger   = Logger.getLogger(Site.class);
    private SeleniumUtility  selUtility;
    private static GridPanel instance = null;

    private GridPanel()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("Site() - error initializing web browser.", e);
        }

    }

    public static GridPanel getInstance()
    {
        if ( instance == null )
        {
            instance = new GridPanel();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    // This function will return number of Grid Cells displayed.
    public int getGridSizeByNoOfCells()
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        List<WebElement> noOfCells = selUtility.findElements("NoOfGridCells");
        logger.debug(" No of Cells : " + noOfCells.size());
        return noOfCells.size();

    }

    // This function will return number of rows displayed.
    public int getGridSizeByNoOfRows()
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        List<WebElement> noOfRows = selUtility.findElements("GridSizeByNoOfRows");
        logger.debug(" No of Rows : " + noOfRows.size());
        return noOfRows.size();

    }

    // This function will return occupied number of beds displayed.
    public int getOccupiedBedNos(String OccupiedBedNosICU)
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        List<WebElement> noOfBeds = selUtility.findElements(OccupiedBedNosICU);
        logger.debug(" Occupied no of Beds : " + noOfBeds.size());
        return noOfBeds.size();

    }

    // This function will return occupied number of beds displayed.
    public int getOccupiedBedNosWithPatient(String OccupiedBedNosWithPatientsICU)
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        List<WebElement> noOfBedsWithPatients = selUtility.findElements(OccupiedBedNosWithPatientsICU);
        logger.debug(" Occupied no of Beds with Patients: " + noOfBedsWithPatients.size());
        return noOfBedsWithPatients.size();

    }

    // This function will return Unoccupied number of Cells displayed.
    public int getUnoccupiedCellNos(String unoccupiedFreeCellsICU)
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        List<WebElement> unoccupiedNoOfCells = selUtility.findElements(unoccupiedFreeCellsICU);
        logger.debug(" Unoccupied No of Cells : " + unoccupiedNoOfCells.size());
        return unoccupiedNoOfCells.size();

    }

    // This function verifies duplicate icon image is displayed or not
    public boolean isDuplicateIconPresent(String patientName)
            throws Exception, WebDriverException, IOException, InterruptedException

    {
        boolean flag = false;
        List<WebElement> patientsList = selUtility.findElements("BedLayout_PatientName");
        List<WebElement> duplicateImageIcon_List = selUtility.findElements("BedLayout_PatientDuplicateIcon");
        for (int i = 0; i < patientsList.size(); i++)
        {
            if ( patientName.equalsIgnoreCase(patientsList.get(i).getText().trim()) )
            {
                logger.debug("Patient With Same Name :" + patientsList.get(i).getText().trim());
                flag = duplicateImageIcon_List.get(i).isDisplayed();
                logger.debug("Duplicate Image Icon is displayed :" + flag);
            }

        }

        return flag;

    }

}
