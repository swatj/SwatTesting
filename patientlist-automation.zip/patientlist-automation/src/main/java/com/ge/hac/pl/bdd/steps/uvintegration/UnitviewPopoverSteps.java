/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.ArrivingListCard;
import com.ge.hac.pl.bdd.functions.Card;
import com.ge.hac.pl.bdd.functions.PopoverCard;

public class UnitviewPopoverSteps
{
    @Then("popover should display with patient data on pacu bed")
    public void verifyPACUPopoverDisplayed(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String Bedname, @Named("patientid") String Patientid,
            @Named("patientname") String Patientname, @Named("dob") String Dob, @Named("age") String Age,
            @Named("surgeon") String Surgeon, @Named("anesthesiologists") String Anesthesiologists,
            @Named("nurse") String Nurse, @Named("isolation") boolean Isolation, @Named("gender") String Gender,
            @Named("similarname") boolean Similarname, @Named("procedure") String Procedure,
            @Named("isolationtext") String IsolationText, @Named("similarnametext") String SimilarnameText)
            throws IOException
    {

        PopoverCard BedPopOver = new PopoverCard();
        String actBedname = BedPopOver.getBedName();
        String actPatientid = BedPopOver.getPatientId();
        String actPatientname = BedPopOver.getPatientName();
        String actDob = BedPopOver.getDateOfBirth();
        String actAge = BedPopOver.getAge();
        String actSurgeon = BedPopOver.getSurgeon();
        String actAnesthesiologists = BedPopOver.getAnesthesiologists();
        String actNurse = BedPopOver.getPacuNurse();
        boolean actIsolation = BedPopOver.isPatientIsolated();
        String actGender = BedPopOver.getGender();
        boolean actSimilarname = BedPopOver.isPatientSimilar();
        String actProcedure = BedPopOver.getProcedure();
        String actIsolationText = BedPopOver.getIsolationText();
        String actSimilarnameText = BedPopOver.getSimilarnameText();

        Assert.assertTrue("Verify bed name on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Bedname + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue(
                "Verify Patientid on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientid + "; actual=" + actPatientid,
                actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue(
                "Verify Patient name on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientname + "; actual=" + actPatientname,
                actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue("Verify Dob on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Dob + "; actual=" + actDob, actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Age + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Surgeon on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Surgeon + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue(
                "Verify Anesthesiologists on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Anesthesiologists + "; actual=" + actAnesthesiologists,
                actAnesthesiologists.equalsIgnoreCase(Anesthesiologists));

        Assert.assertTrue("Verify Isolation icon on popover for card at row=" + RowNumber + " and column="
                + ColumnNumber + " expected=" + Isolation + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Gender + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));

        Assert.assertTrue("Verify Similar name icon on popover for card at row=" + RowNumber + " and column="
                + ColumnNumber + " expected=" + Similarname + "; actual=" + actSimilarname,
                actSimilarname == Similarname);

        Assert.assertTrue(
                "Verify Procedure on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Procedure + "; actual=" + actProcedure,
                actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue(
                "Verify isoloation icon's text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + IsolationText + "; actual=" + actIsolationText,
                actIsolationText.equalsIgnoreCase(IsolationText));
        Assert.assertTrue(
                "Verify similar name icon's text on popover for card at row=" + RowNumber + " and column="
                        + ColumnNumber + " expected=" + SimilarnameText + "; actual=" + actSimilarnameText,
                actSimilarnameText.equalsIgnoreCase(SimilarnameText));
        Assert.assertTrue("Verify Nurse on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Nurse + "; actual=" + actNurse, Nurse.equalsIgnoreCase(actNurse));

    }

    @Then("popover should display with patient data on icu bed")
    public void verifyICUPopoverDisplayed(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String Bedname, @Named("patientid") String Patientid,
            @Named("patientname") String Patientname, @Named("dob") String Dob, @Named("age") String Age,
            @Named("surgeon") String Surgeon, @Named("intensivists") String Intensivists, @Named("nurse") String Nurse,
            @Named("isolation") boolean Isolation, @Named("gender") String Gender,
            @Named("admissionreason") String Admissionreason, @Named("similarname") boolean Similarname,
            @Named("procedure") String Procedure, @Named("isolationtext") String IsolationText,
            @Named("similarnametext") String SimilarnameText)
            throws IOException
    {

        PopoverCard BedPopOver = new PopoverCard();
        String actBedname = BedPopOver.getBedName();
        String actPatientid = BedPopOver.getPatientId();
        String actPatientname = BedPopOver.getPatientName();
        String actDob = BedPopOver.getDateOfBirth();
        String actAge = BedPopOver.getAge();
        String actSurgeon = BedPopOver.getSurgeon();
        String actIntensivists = BedPopOver.getIntensivists();
        String actNurse = BedPopOver.getIcuNurse();
        boolean actIsolation = BedPopOver.isPatientIsolated();
        String actGender = BedPopOver.getGender();
        String actAdmissionreason = BedPopOver.getAdmissionReason();
        boolean actSimilarname = BedPopOver.isPatientSimilar();
        String actProcedure = BedPopOver.getProcedure();
        String actIsolationText = BedPopOver.getIsolationText();
        String actSimilarnameText = BedPopOver.getSimilarnameText();

        Assert.assertTrue("Verify bed name on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Bedname + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue(
                "Verify Patientid on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientid + "; actual=" + actPatientid,
                actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue(
                "Verify Patient name on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Patientname + "; actual=" + actPatientname,
                actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue("Verify Dob on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Dob + "; actual=" + actDob, actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue("Verify Age on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Age + "; actual=" + actAge, actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Surgeon on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Surgeon + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue(
                "Verify Intensivists on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Intensivists + "; actual=" + actIntensivists,
                actIntensivists.equalsIgnoreCase(Intensivists));
        Assert.assertTrue("Verify Nurse on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Nurse + "; actual=" + actNurse, actNurse.equalsIgnoreCase(Nurse));
        Assert.assertTrue("Verify Isolation icon on popover for card at row=" + RowNumber + " and column="
                + ColumnNumber + " expected=" + Isolation + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                + " expected=" + Gender + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue(
                "Verify Admission reason on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Admissionreason + "; actual=" + actAdmissionreason,
                actAdmissionreason.equalsIgnoreCase(Admissionreason));
        Assert.assertTrue("Verify Similar name icon on popover for card at row=" + RowNumber + " and column="
                + ColumnNumber + " expected=" + Similarname + "; actual=" + actSimilarname,
                actSimilarname == Similarname);

        Assert.assertTrue(
                "Verify Procedure on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + Procedure + "; actual=" + actProcedure,
                actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue(
                "Verify isoloation icon's text on popover for card at row=" + RowNumber + " and column=" + ColumnNumber
                        + " expected=" + IsolationText + "; actual=" + actIsolationText,
                actIsolationText.equalsIgnoreCase(IsolationText));
        Assert.assertTrue(
                "Verify similar name icon's text on popover for card at row=" + RowNumber + " and column="
                        + ColumnNumber + " expected=" + SimilarnameText + "; actual=" + actSimilarnameText,
                actSimilarnameText.equalsIgnoreCase(SimilarnameText));
    }

    @Then("popover should disappear")
    public void verifyPopupDisappeared(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
            throws Exception
    {
        Thread.sleep(1000);
        Card card = new Card(RowNumber, ColumnNumber);
        boolean popoverdisplayed = card.isPopOverDisplayed();
        Assert.assertTrue("Verify popover should not display for card at row=" + RowNumber + " and column="
                + ColumnNumber + " expected=fasle ; actual=" + popoverdisplayed, popoverdisplayed == false);
    }

    @When("user searches for patient id in arriving list")
    public void SearchArrivingPatient(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber)
            throws Exception
    {

        Card card = new Card(RowNumber, ColumnNumber);
        card.isPopOverDisplayed();

        boolean popoverdisplayed = card.isPopOverDisplayed();
        Assert.assertEquals("popover should not display", false, popoverdisplayed);
    }

    @Then("arriving list popover should display with patient data")
    public void verifyPopoverDisplayed2(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String bedname, @Named("patientid") String patientid,
            @Named("patientname") String patientname, @Named("dob") String dob, @Named("age") String age,
            @Named("staff") String staff, @Named("isolation") boolean Isolation, @Named("gender") String gender,
            @Named("admissionreason") String admissionreason, @Named("similarname") String similarname)
            throws IOException
    {

        Card card = new Card(RowNumber, ColumnNumber);
        boolean popoverDisplayedCheck = card.isPopOverDisplayed();
        Assert.assertEquals("popover should  display", true, popoverDisplayedCheck);
    }

    @Then("arriving list card popover should disappear")
    public void verifyArrivingListCardPopupDisappeared(@Named("Position") int Position)
            throws Exception
    {

        ArrivingListCard card = new ArrivingListCard(Position);
        card.isPopOverDisplayed();

        boolean popoverdisplayed = card.isPopOverDisplayed();
        Assert.assertEquals("popover should not display", false, popoverdisplayed);
    }

    @Then("popover should display with patient data on icu arriving list")
    public void verifyICUArrivingPopoverDisplayed(@Named("Position") int Position, @Named("bedname") String Bedname,
            @Named("patientid") String Patientid, @Named("patientname") String Patientname, @Named("dob") String Dob,
            @Named("age") String Age, @Named("surgeon") String Surgeon,
            @Named("anesthesiologists") String Anesthesiologists, @Named("isolation") boolean Isolation,
            @Named("gender") String Gender, @Named("admissionreason") String Admissionreason,
            @Named("similarname") boolean Similarname, @Named("procedure") String Procedure,
            @Named("isolationtext") String IsolationText, @Named("similarnametext") String SimilarnameText,
            @Named("lasttimeevent") String LastTimeEvent)
            throws IOException
    {

        PopoverCard BedPopOver = new PopoverCard();
        String actBedname = BedPopOver.getBedName();
        String actPatientid = BedPopOver.getPatientId();
        String actPatientname = BedPopOver.getPatientName();
        String actDob = BedPopOver.getDateOfBirth();
        String actAge = BedPopOver.getAge();
        String actSurgeon = BedPopOver.getSurgeon();
        String actAnesthesiologists = BedPopOver.getAnesthesiologists();
        boolean actIsolation = BedPopOver.isPatientIsolated();
        String actGender = BedPopOver.getGender();
        String actAdmissionreason = BedPopOver.getAdmissionReason();
        boolean actSimilarname = BedPopOver.isPatientSimilar();
        String actProcedure = BedPopOver.getProcedure();
        String actIsolationText = BedPopOver.getIsolationText();
        String actSimilarnameText = BedPopOver.getSimilarnameText();
        String actLastTimeEvent = BedPopOver.getLastTimeEvent();
        Assert.assertTrue("Verify bed name on popover for card at position=" + Position + " expected=" + Bedname
                + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on popover for card at position=" + Position + " expected=" + Patientid
                + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on popover for card at position=" + Position + " expected=" + Patientname
                + "; actual=" + actPatientname, actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue(
                "Verify Dob on popover for card at position=" + Position + " expected=" + Dob + "; actual=" + actDob,
                actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue(
                "Verify Age on popover for card at position=" + Position + " expected=" + Age + "; actual=" + actAge,
                actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Surgeon on popover for card at position=" + Position + " expected=" + Surgeon
                + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue("Verify Intensivists on popover for card at position=" + Position + " expected="
                + Anesthesiologists + "; actual=" + actAnesthesiologists,
                actAnesthesiologists.equalsIgnoreCase(Anesthesiologists));
        Assert.assertTrue("Verify Isolation icon on popover for card at position=" + Position + " expected=" + Isolation
                + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on popover for card at position=" + Position + " expected=" + Gender
                + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));
        Assert.assertTrue("Verify Admission reason on popover for card at position=" + Position + " expected="
                + Admissionreason + "; actual=" + actAdmissionreason,
                actAdmissionreason.equalsIgnoreCase(Admissionreason));
        Assert.assertTrue("Verify Similar name icon on popover for card at position=" + Position + " expected="
                + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on popover for card at position=" + Position + " expected=" + Procedure
                + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue(
                "Verify isoloation icon's text on popover for card at position=" + Position + " expected="
                        + IsolationText + "; actual=" + actIsolationText,
                actIsolationText.equalsIgnoreCase(IsolationText));
        Assert.assertTrue(
                "Verify similar name icon's text on popover for card at position=" + Position + " expected="
                        + SimilarnameText + "; actual=" + actSimilarnameText,
                actSimilarnameText.equalsIgnoreCase(SimilarnameText));
        Assert.assertTrue("Verify Last Time Event(without date time) on popover for card at position=" + Position
                + " expected=" + LastTimeEvent + "; actual=" + actLastTimeEvent,
                actLastTimeEvent.contains(LastTimeEvent));
    }

    @Then("popover should display with patient data on pacu arriving list")
    public void verifyPACUArrivingPopoverDisplayed(@Named("Position") int Position, @Named("bedname") String Bedname,
            @Named("patientid") String Patientid, @Named("patientname") String Patientname, @Named("dob") String Dob,
            @Named("age") String Age, @Named("surgeon") String Surgeon,
            @Named("anesthesiologists") String Anesthesiologists, @Named("isolation") boolean Isolation,
            @Named("gender") String Gender, @Named("similarname") boolean Similarname,
            @Named("procedure") String Procedure, @Named("isolationtext") String IsolationText,
            @Named("similarnametext") String SimilarnameText, @Named("lasttimeevent") String LastTimeEvent)
            throws IOException
    {

        PopoverCard BedPopOver = new PopoverCard();
        String actBedname = BedPopOver.getBedName();
        String actPatientid = BedPopOver.getPatientId();
        String actPatientname = BedPopOver.getPatientName();
        String actDob = BedPopOver.getDateOfBirth();
        String actAge = BedPopOver.getAge();
        String actSurgeon = BedPopOver.getSurgeon();
        String actAnesthesiologists = BedPopOver.getAnesthesiologists();
        boolean actIsolation = BedPopOver.isPatientIsolated();
        String actGender = BedPopOver.getGender();
        String actLastTimeEvent = BedPopOver.getLastTimeEvent();
        boolean actSimilarname = BedPopOver.isPatientSimilar();
        String actProcedure = BedPopOver.getProcedure();
        String actIsolationText = BedPopOver.getIsolationText();
        String actSimilarnameText = BedPopOver.getSimilarnameText();
        Assert.assertTrue("Verify bed name on popover for card at position=" + Position + " expected=" + Bedname
                + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
        Assert.assertTrue("Verify Patientid on popover for card at position=" + Position + " expected=" + Patientid
                + "; actual=" + actPatientid, actPatientid.equalsIgnoreCase(Patientid));
        Assert.assertTrue("Verify Patient name on popover for card at position=" + Position + " expected=" + Patientname
                + "; actual=" + actPatientname, actPatientname.equalsIgnoreCase(Patientname));
        Assert.assertTrue(
                "Verify Dob on popover for card at position=" + Position + " expected=" + Dob + "; actual=" + actDob,
                actDob.equalsIgnoreCase(Dob));
        Assert.assertTrue(
                "Verify Age on popover for card at position=" + Position + " expected=" + Age + "; actual=" + actAge,
                actAge.equalsIgnoreCase(Age));
        Assert.assertTrue("Verify Surgeon on popover for card at position=" + Position + " expected=" + Surgeon
                + "; actual=" + actSurgeon, actSurgeon.equalsIgnoreCase(Surgeon));
        Assert.assertTrue("Verify Intensivists on popover for card at position=" + Position + " expected="
                + Anesthesiologists + "; actual=" + actAnesthesiologists,
                actAnesthesiologists.equalsIgnoreCase(Anesthesiologists));
        Assert.assertTrue("Verify Isolation icon on popover for card at position=" + Position + " expected=" + Isolation
                + "; actual=" + actIsolation, actIsolation == Isolation);
        Assert.assertTrue("Verify Gender on popover for card at position=" + Position + " expected=" + Gender
                + "; actual=" + actGender, actGender.equalsIgnoreCase(Gender));

        Assert.assertTrue("Verify Similar name icon on popover for card at position=" + Position + " expected="
                + Similarname + "; actual=" + actSimilarname, actSimilarname == Similarname);

        Assert.assertTrue("Verify Procedure on popover for card at position=" + Position + " expected=" + Procedure
                + "; actual=" + actProcedure, actProcedure.equalsIgnoreCase(Procedure));
        Assert.assertTrue(
                "Verify isoloation icon's text on popover for card at position=" + Position + " expected="
                        + IsolationText + "; actual=" + actIsolationText,
                actIsolationText.equalsIgnoreCase(IsolationText));
        Assert.assertTrue(
                "Verify similar name icon's text on popover for card at position=" + Position + " expected="
                        + SimilarnameText + "; actual=" + actSimilarnameText,
                actSimilarnameText.equalsIgnoreCase(SimilarnameText));
        Assert.assertTrue("Verify Last Time Event on popover for card at position=" + Position + " expected="
                + LastTimeEvent + "; actual=" + actLastTimeEvent, actLastTimeEvent.contains(LastTimeEvent));
    }

}
