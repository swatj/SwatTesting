/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.AboutBox;
import com.ge.hac.pl.bdd.functions.AboutBoxHelper;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;

public class AboutBoxSteps
{

    @When("user clicks on LoggedIn user link")
    public void clickloggedinLink()
            throws IOException
    {
        AboutBoxHelper.clickOnLoggedInUserName();
    }

    @Then("Patient list should display About Patient List link")
    public void verifyLinkDisplay()
            throws IOException
    {
        Assert.assertEquals("Patient list should display About Patient List link", Constants.ABOUT_LINK,
                AboutBoxHelper.getAboutText());

    }

    @When("user clicks on About Patient List link")
    public void clickLink()
            throws IOException
    {
        AboutBoxHelper.clickAboutLink();
    }

    @Then("About box should be displayed with software version, CA version, image, addresses")
    public void verifyAboutBoxDisplay()
            throws IOException, InterruptedException
    {
        String display = AboutBoxHelper.verifyAboutDialogDisplay();
        String GELogoImagePath = AboutBoxHelper.getGELogoImagePath();
        Assert.assertTrue("Verify GE logo on about dialog",
                GELogoImagePath.matches(".*(" + Constants.GELOGO_IMAGE + ").*"));
        // when dialog box is displayed then its hidden property is false
        Assert.assertEquals("About box should be displayed", "false", display);
        // verify software version, CA version, image, addresses
        Assert.assertEquals("Verify Patient list software version on about dialog", PropertyFileHelper
                .getProjectProperty("PATIENTLIST_VERSION"), AboutBoxHelper.getSoftwareVersion());
        Assert.assertEquals("Verify CA version on about dialog", PropertyFileHelper.getProjectProperty("CA_VERSION"),
                AboutBoxHelper.getCAVersion());

        Assert.assertEquals("The ManufacturerAddress should be same", Constants.MANUFACTURE_ADDRESS, AboutBox
                .getInstance().getManufacturerAddress().replace("\n", ""));
        Assert.assertEquals("The AsiaHeadquarterAddress should be same", Constants.ASIAHEADQUARTER_ADDRESS,
                AboutBoxHelper.getAsiaHeadquarterAddress().replace("\n", ""));

        AboutBoxHelper.closeAboutDialog();
    }

}
