/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public enum RequestType
{
    GET("GET"), POST("POST"), DELETE("DELETE"), PUT("PUT"), UNKNOWN("UNKNOWN");

    private String requestType;

    private RequestType(final String requestType)
    {
        this.requestType = requestType;
    }

    /**
     * @return the requestType
     */
    public String getRequestType()
    {
        return this.requestType;
    }

}
