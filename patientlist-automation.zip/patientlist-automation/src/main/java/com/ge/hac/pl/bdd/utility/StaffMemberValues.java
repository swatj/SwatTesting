/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class StaffMemberValues
{
    String firstRevid;
    String documentId;
    String revisionId;
    String sessionId;
    String lastName;
    String firstName;
    String nameSuffix;
    String title;
    String abbreviation;
    String ssid;
    String personId;
    String mapCode;
    String mapName;

    /**
     * 
     */
    public StaffMemberValues()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param firstRevid
     * @param documentId
     * @param revisionId
     * @param sessionId
     * @param lastName
     * @param firstName
     * @param nameSuffix
     * @param title
     * @param abbreviation
     * @param ssid
     * @param personId
     * @param mapCode
     * @param mapName
     */
    public StaffMemberValues(String firstRevid, String documentId, String revisionId, String sessionId, String lastName,
            String firstName, String nameSuffix, String title, String abbreviation, String ssid, String personId,
            String mapCode, String mapName)
    {
        super();
        this.firstRevid = firstRevid;
        this.documentId = documentId;
        this.revisionId = revisionId;
        this.sessionId = sessionId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.nameSuffix = nameSuffix;
        this.title = title;
        this.abbreviation = abbreviation;
        this.ssid = ssid;
        this.personId = personId;
        this.mapCode = mapCode;
        this.mapName = mapName;
    }

    /**
     * @return the firstRevid
     */
    public String getFirstRevid()
    {
        return this.firstRevid;
    }

    /**
     * @param firstRevid the firstRevid to set
     */
    public void setFirstRevid(String firstRevid)
    {
        this.firstRevid = firstRevid;
    }

    /**
     * @return the documentId
     */
    public String getDocumentId()
    {
        return this.documentId;
    }

    /**
     * @param documentId the documentId to set
     */
    public void setDocumentId(String documentId)
    {
        this.documentId = documentId;
    }

    /**
     * @return the revisionId
     */
    public String getRevisionId()
    {
        return this.revisionId;
    }

    /**
     * @param revisionId the revisionId to set
     */
    public void setRevisionId(String revisionId)
    {
        this.revisionId = revisionId;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId()
    {
        return this.sessionId;
    }

    /**
     * @param sessionId the sessionId to set
     */
    public void setSessionId(String sessionId)
    {
        this.sessionId = sessionId;
    }

    /**
     * @return the lastName
     */
    public String getLastName()
    {
        return this.lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName()
    {
        return this.firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * @return the nameSuffix
     */
    public String getNameSuffix()
    {
        return this.nameSuffix;
    }

    /**
     * @param nameSuffix the nameSuffix to set
     */
    public void setNameSuffix(String nameSuffix)
    {
        this.nameSuffix = nameSuffix;
    }

    /**
     * @return the title
     */
    public String getTitle()
    {
        return this.title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * @return the abbreviation
     */
    public String getAbbreviation()
    {
        return this.abbreviation;
    }

    /**
     * @param abbreviation the abbreviation to set
     */
    public void setAbbreviation(String abbreviation)
    {
        this.abbreviation = abbreviation;
    }

    /**
     * @return the ssid
     */
    public String getSsid()
    {
        return this.ssid;
    }

    /**
     * @param ssid the ssid to set
     */
    public void setSsid(String ssid)
    {
        this.ssid = ssid;
    }

    /**
     * @return the personId
     */
    public String getPersonId()
    {
        return this.personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(String personId)
    {
        this.personId = personId;
    }

    /**
     * @return the mapCode
     */
    public String getMapCode()
    {
        return this.mapCode;
    }

    /**
     * @param mapCode the mapCode to set
     */
    public void setMapCode(String mapCode)
    {
        this.mapCode = mapCode;
    }

    /**
     * @return the mapName
     */
    public String getMapName()
    {
        return this.mapName;
    }

    /**
     * @param mapName the mapName to set
     */
    public void setMapName(String mapName)
    {
        this.mapName = mapName;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "StaffMemberValues [firstRevid=" + firstRevid + ", documentId=" + documentId + ", revisionId="
                + revisionId + ", sessionId=" + sessionId + ", lastName=" + lastName + ", firstName=" + firstName
                + ", nameSuffix=" + nameSuffix + ", title=" + title + ", abbreviation=" + abbreviation + ", ssid="
                + ssid + ", personId=" + personId + ", mapCode=" + mapCode + ", mapName=" + mapName + "]";
    }

}
