/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.UnreachableBrowserException;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class ArrivingListCard extends Bed
{

    private static int       position;
    private List<WebElement> arrivingCardItems = null;

    public ArrivingListCard(int position)
    {
        super();

        String arrivingCardPath = "//div[@class='arrival-patient-list scroll-section-position']//div[@id='arrivingbed"
                + position + "']//div[@id='bedDetails']";
        arrivingCardItems = SeleniumUtility.getInstance().findElementsByXpath(arrivingCardPath);

        if ( arrivingCardItems != null )
        {

            ArrivingListCard.position = position;
        }

        initializeBed("//div[@class='arrival-patient-list scroll-section-position']//div[@id='arrivingbed" + position
                + "']//*");

    }

    /**
     * Returns the count of the ArrivingListCard
     * 
     */
    public int getcountOfCard()
    {
        String arrivingListPath = "//div[@class='arrival-patient-list']//div[contains(@id,'arrivingbed')]";
        List<WebElement> arrivingList = SeleniumUtility.getInstance().findElementsByXpath(arrivingListPath);
        if ( arrivingList != null )
        {
            return arrivingList.size();
        }
        else
            return 0;

    }

    /**
     * opens up the ArrivlingListCard Popover
     * 
     */
    public void openPopover()
            throws Exception

    {
        String popOverButtonPath = "//div[@class='arrival-patient-list']//div[@id='arrivingbed" + position
                + "']//*[contains(@class,'overflow-info pull-right ng-scope ng-isolate-scope')]";// change

        SeleniumUtility.getInstance().elementClickUsingXPath(popOverButtonPath);

    }

    /**
     * closed the ArrivlingListCard Popover
     * 
     */
    public void closePopover()
            throws Exception
    {
        String popOverButtonPath = "//div[@class='arrival-patient-list']//div[@id='arrivingbed" + position
                + "']//*[contains(@class,'overflow-info pull-right ng-scope ng-isolate-scope')]";// change
        SeleniumUtility.getInstance().elementClickUsingXPath(popOverButtonPath);

    }

    public void clickOnCard()
            throws IOException
    {
        String arrivingCardPath = "//div[@class='arrival-patient-list scroll-section-position']//div[@id='arrivingbed"
                + position + "']//div[@id='bedContainer']//div";

        List<WebElement> AllCardItems = SeleniumUtility.getInstance().findElementsByXpath(arrivingCardPath);
        AllCardItems.get(0).click();

    }

    /**
     * @return
     * @throws IOException
     * @throws WebDriverException
     * @throws UnreachableBrowserException
     */
    public boolean isPopupDisplayed()
            throws IOException
    {

        return SeleniumUtility.getInstance().elementDisplayedByXpath("CaseInfoMneu");

    }

}
