/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

import java.util.List;

/**
 * @author 305014106
 *
 */
public class RoomParams
{
    String       roomType;
    String       id;
    String       abbreviation;
    String       name;
    String       mapcode;
    String       mapname;
    String       description;
    List<String> bedList;

    /**
     * 
     */
    public RoomParams()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param roomType
     * @param id
     * @param abbreviation
     * @param name
     * @param mapcode
     * @param mapname
     * @param description
     * @param bedList
     */
    public RoomParams(String roomType, String id, String abbreviation, String name, String mapcode, String mapname,
            String description, List<String> bedList)
    {
        super();
        this.roomType = roomType;
        this.id = id;
        this.abbreviation = abbreviation;
        this.name = name;
        this.mapcode = mapcode;
        this.mapname = mapname;
        this.description = description;
        this.bedList = bedList;
    }

    /**
     * @return the roomType
     */
    public String getRoomType()
    {
        return this.roomType;
    }

    /**
     * @param roomType the roomType to set
     */
    public void setRoomType(String roomType)
    {
        this.roomType = roomType;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return this.id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the abbreviation
     */
    public String getAbbreviation()
    {
        return this.abbreviation;
    }

    /**
     * @param abbreviation the abbreviation to set
     */
    public void setAbbreviation(String abbreviation)
    {
        this.abbreviation = abbreviation;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the mapcode
     */
    public String getMapcode()
    {
        return this.mapcode;
    }

    /**
     * @param mapcode the mapcode to set
     */
    public void setMapcode(String mapcode)
    {
        this.mapcode = mapcode;
    }

    /**
     * @return the mapname
     */
    public String getMapname()
    {
        return this.mapname;
    }

    /**
     * @param mapname the mapname to set
     */
    public void setMapname(String mapname)
    {
        this.mapname = mapname;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return this.description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the bedList
     */
    public List<String> getBedList()
    {
        return this.bedList;
    }

    /**
     * @param bedList the bedList to set
     */
    public void setBedList(List<String> bedList)
    {
        this.bedList = bedList;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "RoomParams [roomType=" + roomType + ", id=" + id + ", abbreviation=" + abbreviation + ", name=" + name
                + ", mapcode=" + mapcode + ", mapname=" + mapname + ", description=" + description + ", bedList="
                + bedList + "]";
    }

}
