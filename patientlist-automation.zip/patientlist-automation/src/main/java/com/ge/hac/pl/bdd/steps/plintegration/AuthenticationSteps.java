/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author 305014106
 *
 */
public class AuthenticationSteps
{
    private static Logger          logger  = Logger.getLogger(AuthenticationSteps.class);
    private static SeleniumUtility selUtil = SeleniumUtility.getInstance();

    @When("the Patient List is launched with <username> and <password>")
    public void loginToPl(@Named("username") String userName, @Named("password") String password)
            throws IOException, Exception
    {
        String plUrl = PropertyFileHelper.getProjectProperty("Url");
        String browserType = PropertyFileHelper.getProjectProperty("BrowserType");

        login(userName, password, plUrl, browserType);
    }

    @When("the Configurator tool is launched with <username> and <password>")
    public void loginToConfigurator(@Named("username") String userName, @Named("password") String password)
            throws IOException, Exception
    {
        String plUrl = PropertyFileHelper.getProjectProperty("ConfiguratorUrl");
        String browserType = PropertyFileHelper.getProjectProperty("BrowserType");

        login(userName, password, plUrl, browserType);
    }

    /**
     * @param userName
     * @param password
     * @param plUrl
     * @param browserType
     * @throws IOException
     * @throws InterruptedException
     */
    private void login(String userName, String password, String plUrl, String browserType)
            throws IOException, InterruptedException
    {
        PatientList pl = PatientList.getInstance();
        pl.openURL(plUrl);
        if ( browserType.equals("IEExplorer") )
        {
            pl.clicktoContinue();
        }

        pl.enterCredentials(userName, password);
        pl.clickOnlogin();
    }

    @Then("the user verifies the logged in user name <loggedInUser>")
    public void verifyLoggedInUser(@Named("loggedInUser") String loggedInUser)
            throws Exception
    {
        PatientList pl = PatientList.getInstance();
        pl.waitForElementToAppear("loggedinUserName", loggedInUser, Constants.HIGH_TIMEOUT);
        Assert.assertEquals("The login is successfull ", loggedInUser, pl.getloggedinUserName().trim());
        Thread.sleep(6000);
    }

    @Then("the user logs out from Patient List")
    public void logoutFromPl()
            throws Exception
    {
        clickLogout();
    }

    @Then("the user logs out from Configurator tool")
    public void logoutFromConfigurator()
            throws Exception
    {
        clickLogout();
    }

    /**
     * @throws IOException
     * @throws InterruptedException
     */
    private void clickLogout()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().clickOnlogout();
        Thread.sleep(5000);
    }

}
