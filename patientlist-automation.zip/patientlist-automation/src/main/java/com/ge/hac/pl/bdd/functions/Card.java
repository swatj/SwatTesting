/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinath
 * 
 */
public class Card extends Bed
{

    private static int       row;
    private static int       column;
    private List<WebElement> cardItems = null;

    /**
     * @param row
     * @param column
     */
    public Card(int row, int column)
    {
        super();
        String cardPath = "//div[@class='room']//div[@class='bed-layout-row ng-scope'][" + row + "]/div[" + column
                + "]//div[contains(@class,'pull-left')]";
        cardItems = SeleniumUtility.getInstance().findElementsByXpath(cardPath);
        if ( cardItems != null )
        {
            Card.row = row;
            Card.column = column;
        }

        initializeBed("//div[@class='room']//div[@class='bed-layout-row ng-scope'][" + Card.row + "]/div["
                + Card.column + "]//*");

    }

    /**
     * returns True if Card is Empty
     * 
     */
    public boolean isCardEmpty()
    {

        if ( cardItems.size() == 0 )
        {
            return true;
        }
        return false;
    }

    /**
     * returns True if Bed is Empty
     * 
     */
    public boolean isBedEmpty()
    {

        if ( cardItems.size() == 1 )
        {
            return true;
        }
        return false;
    }

    /**
     * opens up the Card Popover
     * 
     */
    public void openPopover()
            throws Exception

    {
        String popOverButtonPath = "//div[@class='room']//div[@class='bed-layout-row ng-scope'][" + row + "]/div["
                + column + "]//*[@class='overflow-info pull-right ng-scope ng-isolate-scope']";// change

        SeleniumUtility.getInstance().elementClickUsingXPath(popOverButtonPath);

    }

    /**
     * Closes the Card Popover
     * 
     */
    public void closePopover()
            throws Exception
    {
        String popOverButtonPath = "//div[@class='room']//div[@class='bed-layout-row ng-scope'][" + row + "]/div["
                + column + "]//*[@class='overflow-info pull-right ng-scope ng-isolate-scope']";// change

        SeleniumUtility.getInstance().elementClickUsingXPath(popOverButtonPath);

    }

    public boolean isPopupDisplayed()
            throws IOException
    {

        return SeleniumUtility.getInstance().elementDisplayedByXpath("CaseInfoMneu");

    }

    public void clickOnCard()
            throws Exception
    {
        String cardPath = "//div[@class='room']//div[@class='bed-layout-row ng-scope'][" + row + "]/div[" + column
                + "]//div[contains(@class,'pull-left')]";

        // div[@class='arrival-patient-list']//div[@id='arrivingbed"+position+"']//div[@id='bedContainer']

        List<WebElement> AllCardItems = SeleniumUtility.getInstance().findElementsByXpath(cardPath);
        AllCardItems.get(0).click();

    }
}
