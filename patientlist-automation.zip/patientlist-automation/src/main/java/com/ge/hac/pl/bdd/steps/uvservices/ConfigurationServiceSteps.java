/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.uvservices;

import java.math.BigInteger;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.junit.Assert;

import com.ge.hac.common.ea.dto.configuration.DepartmentLayoutConfiguration;
import com.ge.hac.common.ea.dto.configuration.DeptLayout;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.RestParams;
import com.ge.hac.pl.bdd.utility.ServiceHandler;

/**
 * @author 305014106
 *
 */
public class ConfigurationServiceSteps
{
    private static Logger                        logger = Logger.getLogger(ConfigurationServiceSteps.class);
    private static int                           getServiceResponse;
    private static String                        getResponseString;
    private static DepartmentLayoutConfiguration getResponseEntity;

    private static int                           postServiceResponse;

    @When("the service.getDepartmentLayout url is invoked: $dataTable")
    public static void invokeGetRestEndpoint(ExamplesTable dataTable)
    {
        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);

        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
                restParams.getRestEndpoint(), restParams.getQueryParams(), restParams.getPostEntity());

        ConfigurationServiceSteps.getResponseString = response.readEntity(String.class);
        ConfigurationServiceSteps.getServiceResponse = response.getStatus();

        Assert.assertEquals("Response is OK", HttpResponseCodes.SC_OK, ConfigurationServiceSteps.getServiceResponse);
    }

    @Then("verify that service.getDepartmentLayout returns $departmentCount departments")
    public static void verifyDepartmentCount(String departmentCount)
    {
        /*
         * Populate the response entity of type DepartmentLayoutConfiguration.
         * This can be used by other methods here too.
         */
        ConfigurationServiceSteps.getResponseEntity = (DepartmentLayoutConfiguration) CommonUtility.getObjectFromJson(
                CommonUtility.getMapperObject(), getResponseString, DepartmentLayoutConfiguration.class);

        Assert.assertEquals("Department count matches", Integer.parseInt(departmentCount), getResponseEntity
                .getDeptLayout().size());

    }

    @Then("verify that service.getDepartmentLayout returns rooms and beds: $dataTable")
    public static void verifyDeaprtmentAttributes(ExamplesTable dataTable)
    {
        int iter = 0;
        DepartmentLayoutConfiguration d = ConfigurationServiceSteps.getResponseEntity;
        for (Map<String, String> row : dataTable.getRows())
        {
            if ( d.getDeptLayout().size() <= iter + 1 )
            {

            }
            DeptLayout dl = d.getDeptLayout().get(iter);
            String depid = row.get("departmentId");
            BigInteger rows = new BigInteger(row.get("rows"));
            BigInteger cols = new BigInteger(row.get("cols"));
            int roomCount = Integer.parseInt(row.get("roomCount"));

            Assert.assertEquals("Department Id", depid, dl.getId());
            Assert.assertEquals("Total rows", rows, dl.getRows());
            Assert.assertEquals("Total cols", cols, dl.getColumns());
            Assert.assertEquals("Total rooms", roomCount, dl.getRooms().size());
            iter++;
        }
    }

    @When("the service.postDepartmentLayout url is invoked: $dataTable")
    public static void invokePostRestEndpoint(ExamplesTable dataTable)
    {

        DepartmentLayoutConfiguration postEntity = ConfigurationServiceSteps.getResponseEntity;

        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);

        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
                restParams.getRestEndpoint(), restParams.getQueryParams(), postEntity);
        ConfigurationServiceSteps.postServiceResponse = response.getStatus();

        Assert.assertEquals("Response is OK", HttpResponseCodes.SC_NO_CONTENT,
                ConfigurationServiceSteps.postServiceResponse);
    }
}
