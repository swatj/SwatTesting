/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinathj
 * 
 */
public class Configurator
{
    private static Logger logger = Logger.getLogger(Configurator.class);

    public static void openConfiguratorApplication()

    {

        try
        {
            SeleniumUtility.getInstance().navigateTo("ConfiguratorUrl");
            int timeout = 0;

            // wait for Sign in button to display
            while (!(SeleniumUtility.getInstance().elementDisplayedByXpath("signin")) && timeout <= 10)
            {
                SeleniumUtility.getInstance().navigateTo("ConfiguratorUrl");

                logger.debug("LocalizationSteps:EnterCredentials1 waiting for Sign in button to display=" + timeout);
                timeout++;
                Thread.sleep(5000);
            }
            Thread.sleep(1000);
            SeleniumUtility.getInstance().waitForPageToLoad();
            SeleniumUtility.getInstance().sendKeys("Username", Constants.CONFIGURATOR_USER);
            SeleniumUtility.getInstance().sendKeys("Password", Constants.CONFIGURATOR_USER_PWD);
            PatientList.getInstance().clickOnlogin();
            logger.debug("Configurator:openConfiguratorApplication: opening the Configurator Application");
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.openConfiguratorApplication", e);
        }

    }

    /**
     * 
     */
    public static String getActiveTabName()
    {
        return getText("configurator_active_tab");

    }

    /**
     * 
     */
    public static String getSecondTabName()
    {

        return getText("second_tab");

    }

    /**
     * 
     */
    public static String getSelectedDepartment()
    {

        return getText("departmentDropdown");

    }

    /**
     * 
     */
    public static int getDefaultColsNo()
    {
        return Integer.parseInt(getText("column_no"));

    }

    /**
     * 
     */
    public static int getDefaultRowsNo()
    {

        return Integer.parseInt(getText("row_no"));
    }

    /**
     * 
     */
    public static int getLayoutColsNo()
    {
        List<WebElement> cols = null;
        try
        {
            cols = SeleniumUtility.getInstance().findElements("gridcolumncount");

        }
        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getLayoutColsNo", e);
        }
        logger.debug("Configurator:getLayoutColsNo: get layout cols number");
        return cols.size();
    }

    /**
     * 
     */
    public static int getLayoutRowsNo()
    {

        List<WebElement> rows = null;
        try
        {
            rows = SeleniumUtility.getInstance().findElements("gridrowcount");

        }
        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getLayoutRowsNo", e);
        }
        logger.debug("Configurator:getLayoutRowsNo: get layout rows number");
        return rows.size();

    }

    /**
     * 
     */
    public static String getSelectedRoom()
    {

        return getText("roomDropdown");
    }

    /**
     * 
     */
    public static List<String> getRoomsFromDropDown()
    {
        List<String> roomList = new ArrayList<String>();
        roomList.clear();
        try
        {
            List<WebElement> rooms = SeleniumUtility.getInstance().findElements("allroomsfromdropdown");

            for (WebElement room : rooms)
            {
                if ( !("".equalsIgnoreCase(room.getText().trim())) )
                {
                    roomList.add(room.getText().trim());
                    logger.debug(
                            "Configurator:getRoomsFromDropDown: get room from room dropdown " + room.getText().trim());
                }
            }

        }
        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getRoomsFromDropDown", e);
        }
        logger.debug("Configurator:getRoomsFromDropDown: get room from room dropdown " + roomList.toString());
        return roomList;

    }

    /**
     * 
     */
    public static String getFirstTabName()
    {

        return getText("first_tab");

    }

    /**
     * 
     */
    public static List<String> getAllDepartments()
    {
        List<String> departmentList = new ArrayList<String>();
        try
        {
            List<WebElement> departments = SeleniumUtility.getInstance().findElements("alldepartmentsfromdropdown");

            for (WebElement department : departments)
            {
                departmentList.add(department.getText().trim());
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getAllDepartments", e);

        }
        logger.debug("Configurator:getAllDepartments: get departments from department dropdown "
                + departmentList.toString());
        return departmentList;
    }

    private static String getText(String objectName)
    {
        String objectText = "";
        try
        {
            objectText = SeleniumUtility.getInstance().get_text(objectName).trim();
        }
        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getText", e);
        }
        logger.debug("Configurator:getText: get the text of element " + objectText);
        return objectText;
    }

    /**
     * 
     */
    public static void waitForPageToload()
    {
        try
        {
            SeleniumUtility.getInstance().waitTextToBePresentInElement("first_tab",
                    Constants.CONFIGURATOR_FIRST_TAB_NAME, Constants.HIGH_TIMEOUT);
            Thread.sleep(500);
        }

        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.waitForPageToload", e);
        }

    }

    /**
     * 
     */
    public static void setRowNumber(String rowno)
    {
        try
        {
            int expRowNumber = Integer.parseInt(rowno);
            int actRowNumber = Configurator.getDefaultRowsNo();
            if ( expRowNumber > actRowNumber )
            {
                for (int i = 1; i <= expRowNumber - actRowNumber; i++)
                {
                    // clicks on plus icon
                    SeleniumUtility.getInstance().elementClick("add_row");
                    waitForPageToload();
                }
            }
            else if ( actRowNumber > expRowNumber )
            {
                for (int i = 1; i <= actRowNumber - expRowNumber; i++)
                {
                    // clicks on minus icon
                    SeleniumUtility.getInstance().elementClick("remove_row");
                    waitForPageToload();
                }
            }
        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.setRowNumber", e);
        }

    }

    /**
     * @param colNumber
     */
    public static void setColumnNumber(String colNumber)
    {
        try
        {
            int expColNumber = Integer.parseInt(colNumber);
            int actColNumber = Configurator.getDefaultColsNo();
            if ( expColNumber > actColNumber )
            {
                for (int i = 1; i <= expColNumber - actColNumber; i++)
                {
                    // clicks on plus icon
                    SeleniumUtility.getInstance().elementClick("add_col");
                    waitForPageToload();
                }
            }
            else if ( actColNumber > expColNumber )
            {
                for (int i = 1; i <= actColNumber - expColNumber; i++)
                {
                    // clicks on minus icon
                    SeleniumUtility.getInstance().elementClick("remove_col");
                    waitForPageToload();
                }
            }
        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.setColumnNumber", e);
        }

    }

    /**
     * @param department
     */
    public static void selectDepartment(String department)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("departmentDropdown");
            List<WebElement> departments = SeleniumUtility.getInstance().findElements("alldepartmentsfromdropdown");

            for (WebElement eachdepartment : departments)
            {
                if ( department.equalsIgnoreCase(eachdepartment.getText().trim()) )
                {

                    eachdepartment.click();
                    logger.debug("Configurator:selectDepartment: select the department " + department);
                    break;
                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.selectDepartment", e);

        }
    }

    /**
     * @param room
     */
    public static void selectRoom(String room)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("roomDropdown");
            List<WebElement> rooms = SeleniumUtility.getInstance().findElements("allroomsfromdropdown");
            for (WebElement eachRoom : rooms)
            {
                if ( room.equalsIgnoreCase(eachRoom.getText().trim()) )
                {
                    eachRoom.click();
                    logger.debug("Configurator:selectRoom: select the room " + room);
                    break;
                }
            }
        }

        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.selectRoom", e);
        }

    }

    /**
     * @param rowNo
     * @param colNo
     */
    public static void clickOnCell(String rowNo, String colNo)
    {
        try
        {
            String cell = PropertyFileHelper.getObjectIdentifier("gridcell");
            cell = cell.replace("ROWNO", rowNo);
            cell = cell.replace("COLNO", colNo);
            SeleniumUtility.getInstance().findElementbyXpath(cell).click();
            Thread.sleep(1000);
        }
        catch (InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.clickOnCell", e);
        }

    }

    /**
     * 
     */
    public static List<String> getBedsNameFromContextMenu()
    {
        List<String> bedList = new ArrayList<String>();
        try
        {

            List<WebElement> beds = SeleniumUtility.getInstance().findElements("bed_context_menu");

            for (WebElement bed : beds)
            {
                String bedName = bed.getText().trim();
                bedName = bedName.replace(Constants.NEWLINE_SEPERATOR, "");
                bedList.add(bedName);
                logger.debug("Configurator:getBedsNameFromContextMenu: get bed name from context menu " + bedName);
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getBedsNameFromContextMenu", e);

        }

        return bedList;
    }

    /**
     * @param rowNo
     * @param colNo
     * @param bedName
     */
    public static void assignBed(String rowNo, String colNo, String bedName)
    {

        List<WebElement> beds;
        try
        {
            if ( !isContextMenuDisplayed() )
            {
                clickOnCell(rowNo, colNo);
            }
            beds = SeleniumUtility.getInstance().findElements("bed_context_menu");
            for (WebElement bed : beds)
            {

                if ( bedName.equalsIgnoreCase(bed.getText().trim()) )
                {
                    bed.click();
                    logger.debug("Configurator:assignBed: assigned bed " + bedName + "  at row =" + rowNo
                            + ", at cols =" + colNo);
                    break;
                }
            }
        }
        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.assignBed", e);
        }

    }

    /**
     * @param rowNo
     * @param colNo
     */
    public static String getBedName(String rowNo, String colNo)
    {

        String cell = PropertyFileHelper.getObjectIdentifier("bedname_oncell");
        cell = cell.replace("ROWNO", rowNo);
        cell = cell.replace("COLNO", colNo);
        logger.debug("Configurator:getBedName: get bed name from  row =" + rowNo + " , cols =" + colNo);
        return SeleniumUtility.getInstance().findElementbyXpath(cell).getText().trim();
    }

    /**
     * @param rowNo
     * @param colNo
     */
    public static String getRoomName(String rowNo, String colNo)
    {
        String cell = PropertyFileHelper.getObjectIdentifier("roomname_oncell");
        cell = cell.replace("ROWNO", rowNo);
        cell = cell.replace("COLNO", colNo);
        logger.debug("Configurator:getRoomName: get room name from  row =" + rowNo + " , cols =" + colNo);
        return SeleniumUtility.getInstance().findElementbyXpath(cell).getText().trim();

    }

    /**
     * @param rowNo
     * @param colNo
     */
    public static void removeBed(String rowNo, String colNo)
    {

        try
        {

            int counter = 0;
            while (!(SeleniumUtility.getInstance().elementDisplayedByXpath("remove_bed")) && counter <= 6)
            {
                logger.debug("Configurator:removeBed: waiting for  remove bed option=" + counter);

                clickOnCell(rowNo, colNo);
                counter++;
            }

            SeleniumUtility.getInstance().elementClick("remove_bed");
            logger.debug("Configurator:removeBed: bed removed from row=" + rowNo + " , col=" + colNo);

        }

        catch (IOException e)

        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.removeBed", e);
        }

    }

    /**
     * @param rowNo
     * @param colNo
     */
    public static boolean isBedRemovable(String rowNo, String colNo)
    {

        boolean isRemovable = false;
        try
        {
            clickOnCell(rowNo, colNo);
            isRemovable = SeleniumUtility.getInstance().elementDisplayedByXpath("remove_bed");
            SeleniumUtility.getInstance().elementClick("add_row");
            SeleniumUtility.getInstance().elementClick("remove_row");
        }
        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.isBedRemovable", e);
        }

        return isRemovable;
    }

    /**
     * @return
     */
    public static boolean isContextMenuDisplayed()
    {
        try
        {
            return SeleniumUtility.getInstance().elementDisplayedByXpath("bed_context_menu");
        }
        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.isContextMenuDisplayed", e);
            return false;
        }

    }

    /**
     * @param tabName
     * @throws IOException
     */
    public static void selectTab(String tabName)
            throws IOException
    {
        switch (tabName)
        {
            case Constants.CONFIGURATOR_FIRST_TAB_NAME:
                SeleniumUtility.getInstance().getElementByXPath("first_tab").click();
                break;
            case Constants.CONFIGURATOR_SECOND_TAB_NAME:

                SeleniumUtility.getInstance().getElementByXPath("second_tab").click();
                break;
            default:

                break;
        }

    }

    /**
     * @return
     */
    public static boolean isGridDisplay()
    {
        try
        {

            return SeleniumUtility.getInstance().elementDisplayedByXpath("ConfiguratorDataGrid");

        }

        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.isGridDisplay", e);
            return false;
        }
    }

    /**
     * 
     */
    public static String getErrorMessage()
    {
        return getText("row_col_remove_error");

    }

    /**
     * @param propertykey
     * @return PropertyName
     */
    public static String getPropertyName(String propertykey)

    {
        System.out.println("xpath for pro name=" + "//td[@translate='" + propertykey + "']");
        return SeleniumUtility.getInstance().findElementbyXpath("//td[@translate='" + propertykey + "']").getText()
                .trim();
    }

    /**
     * @param propertykey
     * @return PropertyValue
     */
    public static String getPropertyValue(String propertykey)
    {
        System.out.println("xpath for pro val=" + "//td[@translate='" + propertykey + "']//following-sibling::td[1]");
        return SeleniumUtility.getInstance()
                .findElementbyXpath("//td[@translate='" + propertykey + "']//following-sibling::td[1]").getText().trim()
                .replace(Constants.NEWLINE_SEPERATOR, " ");
    }

    /**
     * @param propertykey
     * @param propertyname
     * @param propertyvalue
     * @throws IOException
     * @throws
     *             @throws
     */
    public static void changeCheckBoxProperty(String propertyname, String propertyvalue)
            throws IOException
    {
        WebElement SaveColumnOrderProperty = SeleniumUtility.getInstance().getElementByXPath(propertyname);
        if ( propertyvalue.equalsIgnoreCase("true") )
        {
            if ( !SaveColumnOrderProperty.isSelected() )
            {
                SaveColumnOrderProperty.click();
            }

        }
        else
        {
            if ( SaveColumnOrderProperty.isSelected() )
            {
                SaveColumnOrderProperty.click();
            }
        }

    }

    public static void selectConfigurationLink()
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Configuration").click();

    }

    public static void selectSummaryLink()
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Summary").click();

    }

    /**
     * @param string
     * @param propertyvalue
     * @throws IOException
     */
    public static void changeSelectDropDownProperty(String propertyname, String propertyvalue)
            throws IOException
    {
        try
        {
            SeleniumUtility.getInstance().elementClick(propertyname);
            List<WebElement> options = SeleniumUtility.getInstance().findElements("all" + propertyname);
            for (WebElement option : options)
            {
                System.out.println(option.getText().trim());
            }

            for (WebElement option : options)
            {
                if ( propertyvalue.equalsIgnoreCase(option.getText().trim()) )
                {

                    option.click();
                    logger.debug("Configurator:changeSelectDropDownProperty: select the value from dropdown "
                            + propertyvalue);
                    break;

                }
            }

        }
        catch (IOException |

        InterruptedException e)

        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.changeSelectDropDownProperty", e);

        }

    }

    /**
     * @throws IOException
     * 
     */
    public static void clickOnSaveButton()
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Save_Button").click();

    }

    /**
     * @param string
     * @return
     * @throws
     * @throws WebDriverException
     * @throws
     */
    public static String getAllDropDownValues(String DropDownName)
    {
        String Values = "";
        List<WebElement> DropDownValues;
        try
        {

            DropDownValues = SeleniumUtility.getInstance().findElements(DropDownName);
            for (WebElement DropDownValue : DropDownValues)
            {
                if ( Values == "" )
                {
                    Values = DropDownValue.getText().trim();
                }
                else
                {
                    Values = Values + "," + DropDownValue.getText().trim();
                }

            }

        }

        catch (IOException | WebDriverException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.Configurator.getAllDropDownValues", e);
        }
        return Values;

    }

    /**
     * @param sortedDropDownValues
     */
    public static void sort(String[] sortedDropDownValues)
    {

    }
}
