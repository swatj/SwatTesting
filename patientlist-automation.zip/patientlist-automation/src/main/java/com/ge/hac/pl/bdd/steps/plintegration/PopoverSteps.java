/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.functions.Popover;
import com.ge.hac.pl.bdd.utility.Constants;

/**
 * @author pandharinathj
 * 
 */
public class PopoverSteps
{
    @When("user clicks on <column> cell for patient id <Patient_ID>")
    public void clickOnProcedureCell(@Named("column") String columnToClick, @Named("Patient_ID") String Patient_ID)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, Patient_ID);
        Popover.getInstance().invokePopover(columnToClick, 1);
    }

    @Then("Patient list should display a popover with all <column> (s)")
    public void verifyProcedurePopoverData(@Named("column") String columnToClick,
            @Named("Popoverdata") String expectedPopoverdata)
                    throws Exception
    {

        String actualPopoverdata = Popover.getInstance().getPopoverData();
        Assert.assertEquals("Popover displayed successfully with all " + columnToClick + "(s)", expectedPopoverdata,
                actualPopoverdata);
    }

    @Then("clicking on same cell popover will remain open")
    public void verifyPopoverDisappeared(@Named("column") String columnToClick)
            throws Exception
    {
        Popover.getInstance().invokePopover(columnToClick, 1);
        boolean popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should not display for column " + columnToClick, true, popOverDisplayed);
    }

    @Then("Patient list should display only one $procedure on UI and should show a count of remaining $procedure (s)")
    public void verifyProcedure(@Named("column") String column, @Named("Patient_ID") String Patient_ID,
            @Named("expectedData") String expectedData)
                    throws Exception
    {
        // make column visible on table
        List<String> patientListColumnHeaderList = new ArrayList<String>();
        patientListColumnHeaderList.add(column);
        PatientListData.getInstance().makeColumnVisible(patientListColumnHeaderList);
        // get column position
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, Patient_ID);
        if ( column.equalsIgnoreCase(Constants.PROCEDURE_COLUMN) )
        {
            PatientListData.getInstance().verifyProcedure(1, patientListColumnHeaderList, expectedData);
        }
        if ( column.equalsIgnoreCase(Constants.DIAGNOSIS_COLUMN) )
        {
            PatientListData.getInstance().verifyDiagnosis(1, patientListColumnHeaderList, expectedData);
        }
        if ( column.equalsIgnoreCase(Constants.SURGEON_COLUMN) )
        {
            PatientListData.getInstance().verifySurgeon(1, patientListColumnHeaderList, expectedData);
        }
        if ( column.equalsIgnoreCase(Constants.NURSE_COLUMN) )
        {
            PatientListData.getInstance().verifyNurse(1, patientListColumnHeaderList, expectedData);
        }
        if ( column.equalsIgnoreCase(Constants.ANESTHESIA_COLUMN) )
        {
            PatientListData.getInstance().verifyAnesthesia(1, patientListColumnHeaderList, expectedData);
        }

    }

    @Then("Clicking anywhere should result in the popover disappearing, if it is displayed")
    public void verifyPopoverAppearedDisappeared(@Named("column") String columnToClick,
            @Named("Patient_ID") String Patient_ID)
                    throws Exception
    {
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, Patient_ID);
        Popover.getInstance().invokePopover(columnToClick, 1);
        boolean popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should display for column " + columnToClick, true, popOverDisplayed);

        PatientList.getInstance().clickOnSearch();
        Thread.sleep(1000);
        popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should display for column " + columnToClick, false, popOverDisplayed);
    }

    @When("user clicks on <column> column, popover will display")
    public void invokePopover(@Named("column") String columnToClick, @Named("Patient_ID") String Patient_ID)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, Patient_ID);
        Popover.getInstance().invokePopover(columnToClick, 1);

        boolean popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should display for column " + columnToClick, true, popOverDisplayed);
    }

    @When("user remove the <column> from column configuration")
    public void removeColumn(@Named("column") String columnToRemove)
            throws Exception
    {

        PatientList.getInstance().removeColumnFromColumnList(columnToRemove);

    }

    @Then("Patinet list should not display popover")
    public void verifyPopover()
            throws Exception
    {

        boolean popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should not display", false, popOverDisplayed);
    }

    @Then("Patinet list should not display popover on addaing same <column> column again")
    public void addColumn(@Named("column") String columnName)
            throws Exception
    {

        PatientList.getInstance().addColumnToColumnList(columnName);
        boolean popOverDisplayed = Popover.getInstance().PopoverDisplayed();
        Assert.assertEquals("Popover should not display", false, popOverDisplayed);

    }

}
