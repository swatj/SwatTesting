package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.functions.UpdateDate;
import com.ge.hac.pl.bdd.utility.Constants;

public class AutoRefreshStep
{

    @Then("verify the patient's data in the Patient list before auto refresh")
    public void verifyPatientListDataBeforeRefresh(@Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("TimeEvent") String timeEvent,
            @Named("FileName") String XmlFileName, @Named("time") String time)
            throws Exception
    {
        UpdateDate.getInstance().updateXML(timeEvent, XmlFileName, time);
        Thread.sleep(3000);

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);

        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);
        System.out.println("RowID and PatientID " + patientIDRowNumber);
        PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);

    }

    @Then("verify the patient's data in the Patient list after auto refresh")
    public void verifyPatientListDataAfterRefresh(@Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("TimeEvent") String timeEvent,
            @Named("FileName") String XmlFileName, @Named("time") String time)
            throws Exception
    {
        UpdateDate.getInstance().updateXML(timeEvent, XmlFileName, time);
        Thread.sleep(Constants.AUTO_REFRESH_INTERVAL);

        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);

        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);
        System.out.println("RowID and PatientID " + patientIDRowNumber);
        PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
    }
}
