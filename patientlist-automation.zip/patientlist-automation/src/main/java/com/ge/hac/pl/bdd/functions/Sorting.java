/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinathj
 * 
 */
public class Sorting
{
    private static Logger          logger   = Logger.getLogger(Sorting.class);
    private static SeleniumUtility selUtility;
    private static Sorting         instance = null;

    private Sorting()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("Sorting() - error initializing web browser.", e);
        }

    }

    public static Sorting getInstance()
    {
        if ( instance == null )
        {
            instance = new Sorting();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    public boolean sortColumnData(String sortingColumn, String sortType)
            throws Exception
    {
        boolean bSorted = false;
        String columnName = null;
        // make column visible on grid
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(sortingColumn);
        PatientListData.getInstance().makeColumnVisible(headerNames);
        WebElement columnToSort = null;
        // find the column to be sort on Grid
        List<WebElement> patientListCoulmnHeader = selUtility.findElements("allColumns");
        // Map<String, Integer> patientListColumnsHeaderIndexMap = PatientListData.getInstance()
        // .getPatientListColumnsPosition(headerNames);
        // int columnPosition = patientListColumnsHeaderIndexMap.get(sortingColumn);
        for (int i = 0; i < patientListCoulmnHeader.size(); i++)
        {
            columnName = patientListCoulmnHeader.get(i).getText();

            if ( columnName.equals(sortingColumn) )
            {
                // exit if column found
                columnToSort = patientListCoulmnHeader.get(i);
                break;
            }

        }
        // if column found then apply sorting
        if ( null != columnToSort )
        {
            // if column found then click on column to apply default (Ascending)sorting
            columnToSort.click();
            // verify which sorting applied
            if ( selUtility.elementDisplayedByXpath("sortAscending") && sortType.equalsIgnoreCase(Constants.DESC_SORT) )
            {
                // perform descending sort
                selUtility.getElementByXPath("sortAscending").click();
            }
            if ( selUtility.elementDisplayedByXpath("sortDescending") && sortType.equalsIgnoreCase(Constants.ASC_SORT) )
            {
                // perform Ascending sort
                selUtility.getElementByXPath("sortDescending").click();
            }
            bSorted = true;
        }
        else
        {
            Assert.fail("Column not found on patient list header=" + sortingColumn);
        }
        return bSorted;
    }

    public static String[] Sort(String[] sortedColumnData)
    {
        int j;
        boolean flag = true;   // set flag to true to begin first pass
        String temp;   // holding variable
        Collator en_USCollator = Collator.getInstance(new Locale("en", "US"));
        while (flag)
        {
            flag = false;    // set flag to false awaiting a possible swap
            for (j = 0; j < sortedColumnData.length - 1; j++)
            {

                if ( en_USCollator.compare(sortedColumnData[j], sortedColumnData[j + 1]) > 0 )   // change to > for ascending sort
                {

                    temp = sortedColumnData[j];
                    sortedColumnData[j] = sortedColumnData[j + 1];// swap elements
                    sortedColumnData[j + 1] = temp;
                    flag = true;
                }
            }
        }
        return sortedColumnData;

    }

    public boolean verifySortedColumnData(String sortingColumn, String sortType)
            throws Exception
    {
        // read column data from UI
        boolean bSorted = false;
        ArrayList<String> columnActualData = new ArrayList<String>();
        // get row count
        List<WebElement> allRows = selUtility.findElements("allRows");
        if ( allRows.size() == 0 )
        {
            Assert.fail("No data available for column=" + sortingColumn);
        }
        else
        {
            // make column visible on grid
            List<String> headerNames = new ArrayList<String>();
            headerNames.add(sortingColumn);
            PatientListData.getInstance().makeColumnVisible(headerNames);
            // Initialize array to hold sorted data
            String[] SortedColumnData = new String[allRows.size()];
            Map<String, Integer> patientListColumnsHeaderIndexMap = PatientListData.getInstance()
                    .getPatientListColumnsPosition(headerNames);
            int columnPosition = patientListColumnsHeaderIndexMap.get(sortingColumn);
            // read data from UI for sorted column
            for (int rowNumber = 0; rowNumber < allRows.size(); rowNumber++)
            {
                String columnValue = PatientListData.getInstance().getCellValue(rowNumber + 1, columnPosition);
                // getCellValue function return entire cell value
                // patient column sorting is happing on patient name only and not on DOB,Gender
                // hence removing that from cell value
                // if ( sortingColumn.equalsIgnoreCase(Constants.PATIENT_COLUMN) )
                // {
                String[] columnValueTemp = columnValue.split("\n");
                columnValue = columnValueTemp[0].trim();
                // }
                SortedColumnData[rowNumber] = columnValue;
                columnActualData.add(rowNumber, columnValue);

            }
            // sort temp data in ascending order
            String[] sortedPatientData = Sort(SortedColumnData);
            // verify order in sorted array and on UI
            if ( sortType.equalsIgnoreCase(Constants.ASC_SORT) || sortType.equalsIgnoreCase(Constants.DESC_SORT) )
            {
                // verify ascending sort
                if ( sortType.equalsIgnoreCase(Constants.ASC_SORT) )
                {
                    for (int k = 0; k < sortedPatientData.length; k++)
                    {
                        Assert.assertEquals("Verify sorted " + sortType + " order for " + sortingColumn
                                + " column at row =" + k + 1, sortedPatientData[k].toString(),
                                columnActualData.get(k).toString());
                        bSorted = true;
                    }
                }
                if ( sortType.equalsIgnoreCase(Constants.DESC_SORT) )
                {
                    // verify descending sort
                    int j = 0;
                    for (int k = sortedPatientData.length - 1; k > 0; k--)
                    {
                        Assert.assertEquals("Verify sorted " + sortType + " order for " + sortingColumn
                                + " column at row =" + j + 1, sortedPatientData[k].toString(),
                                columnActualData.get(j).toString());
                        j++;
                        bSorted = true;
                    }
                }

            }
            else
            {
                Assert.fail("invalid sort type. possible values are " + Constants.ASC_SORT + "  and "
                        + Constants.DESC_SORT);
            }
        }
        return bSorted;

    }

    public String getSortedAppliedColumnName()
            throws Exception
    {
        selUtility.elementDisplayedByXpath("Active_Sorted_column");
        return selUtility.get_text("Active_Sorted_column");
    }

    public String getSortedAppliedColumnOrder()
            throws Exception
    {
        selUtility.elementDisplayedByXpath("Active_Sorted_Order");
        return selUtility.getElementByXPath("Active_Sorted_Order").getAttribute("class").toString();
    }

    public boolean verifySecondaySortedColumnData(String PrimarySortingColumn, String SecondarySortingColumn,
            String sortType)
            throws Exception
    {
        // read column data from UI
        boolean bSorted = false;
        ArrayList<String> PrimaryColumnActualData = new ArrayList<String>();
        ArrayList<String> SecondaryColumnActualData = new ArrayList<String>();

        // get row count
        selUtility.waitForPageToLoad();
        List<WebElement> allRows = selUtility.findElements("allRows");
        if ( allRows.size() == 0 )
        {
            Assert.fail("No data available for column=" + PrimarySortingColumn);
        }
        else
        {
            // make column visible on grid
            List<String> headerNames = new ArrayList<String>();
            headerNames.add(PrimarySortingColumn);
            headerNames.add(SecondarySortingColumn);
            PatientListData.getInstance().makeColumnVisible(headerNames);
            // Initialize array to hold sorted data
            // String[] PrimarySortedColumnData = new String[allRows.size()];

            Map<String, Integer> patientListColumnsHeaderIndexMap = PatientListData.getInstance()
                    .getPatientListColumnsPosition(headerNames);
            int PrimaryColumnPosition = patientListColumnsHeaderIndexMap.get(PrimarySortingColumn);
            int SecondaryColumnPosition = patientListColumnsHeaderIndexMap.get(SecondarySortingColumn);
            // read data from UI for sorted column
            for (int rowNumber = 0; rowNumber < allRows.size(); rowNumber++)
            {
                String PrimaryColumnValue = PatientListData.getInstance().getCellValue(rowNumber + 1,
                        PrimaryColumnPosition);
                String[] PrimaryColumnValueTemp = PrimaryColumnValue.split("\n");
                PrimaryColumnValue = PrimaryColumnValueTemp[0].trim();
                PrimaryColumnActualData.add(rowNumber, PrimaryColumnValue);
                String SecondaryColumnValue = PatientListData.getInstance().getCellValue(rowNumber + 1,
                        SecondaryColumnPosition);
                // String[] SecondaryColumnValueTemp = SecondaryColumnValue.split("\n");
                // SecondaryColumnValue = SecondaryColumnValueTemp[0].trim();
                SecondaryColumnActualData.add(rowNumber, SecondaryColumnValue);

            }

            int startingPositionOfSecondColumn = 0;
            int loopCounter = 0;
            String firstValue = "";
            for (int rowNumber = 0; rowNumber < SecondaryColumnActualData.size(); rowNumber++)
            {

                firstValue = PrimaryColumnActualData.get(rowNumber);

                String[] SecondarySortedColumnData = null;
                // verify sorting of second column based on first column
                while (rowNumber < PrimaryColumnActualData.size())
                {
                    if ( PrimaryColumnActualData.get(rowNumber).equalsIgnoreCase(firstValue) )
                    {
                        rowNumber++;

                    }
                    else
                    {
                        break;
                    }
                }
                SecondarySortedColumnData = new String[rowNumber - startingPositionOfSecondColumn];
                for (int secondrowNumber = startingPositionOfSecondColumn; secondrowNumber <= rowNumber
                        - 1; secondrowNumber++)

                {

                    // get second column data from secondrowNumber to rowNumber
                    SecondarySortedColumnData[loopCounter] = SecondaryColumnActualData.get(secondrowNumber);
                    loopCounter++;

                }
                // sort temp data in ascending order
                String[] sortedPatientData = Sort(SecondarySortedColumnData);
                // verify order in sorted array and on UI
                if ( sortType.equalsIgnoreCase(Constants.ASC_SORT) || sortType.equalsIgnoreCase(Constants.DESC_SORT) )
                {
                    // verify ascending sort
                    if ( sortType.equalsIgnoreCase(Constants.ASC_SORT) )
                    {
                        for (int k = 0; k < sortedPatientData.length; k++)
                        {
                            Assert.assertEquals(
                                    "Verify sorted " + sortType + " order for " + SecondarySortingColumn
                                            + " column at row =" + k + 1,
                                    sortedPatientData[k].toString(), SecondarySortedColumnData[k].toString());
                            bSorted = true;
                        }
                    }
                    if ( sortType.equalsIgnoreCase(Constants.DESC_SORT) )
                    {
                        // verify descending sort
                        int j = 0;
                        for (int k = sortedPatientData.length - 1; k > 0; k--)
                        {
                            Assert.assertEquals(
                                    "Verify sorted " + sortType + " order for " + SecondarySortingColumn
                                            + " column at row =" + j + 1,
                                    sortedPatientData[k].toString(), SecondarySortedColumnData[k].toString());
                            j++;
                            bSorted = true;
                        }
                    }

                }
                else
                {
                    Assert.fail("invalid sort type. possible values are " + Constants.ASC_SORT + "  and "
                            + Constants.DESC_SORT);
                }

                startingPositionOfSecondColumn = rowNumber;
                loopCounter = 0;
                rowNumber--;
            }// rowNumber

        }// allRows.size() == 0
        return bSorted;
    } // function
}
