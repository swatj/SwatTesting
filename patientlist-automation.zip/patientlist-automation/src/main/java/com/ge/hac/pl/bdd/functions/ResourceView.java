package com.ge.hac.pl.bdd.functions;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class ResourceView
{
    private static Logger logger = Logger.getLogger(ResourceView.class);

    public static boolean isResourceViewDisplayed()
            throws IOException
    {
        return SeleniumUtility.getInstance().elementDisplayedByXpath("ResourceView");
    }

    /* get error message for bed layout configuration */
    public static String getBedLayoutNotConfiguredErrorMessage()
            throws IOException, InterruptedException
    {
        return SeleniumUtility.getInstance().getElementByXPath("warningMessage").getText().trim();

    }
}
