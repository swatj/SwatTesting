/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plservices;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;

/**
 * @author 305014106
 *
 */
public class PlaceholderSteps
{
    @Given("a placeholder step")
    public static void placeHolderGiven()
    {
        System.out.println("com.ge.hac.pl.bdd.steps.plservices.PlaceholderSteps - given place holder");
    }
    @Then("do nothing")
    public static void doNothing()
    {
        System.out.println("com.ge.hac.pl.bdd.steps.plservices.PlaceholderSteps.doNothing() - then do nothing");
    }

}
