/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class BedParams
{
    String isManagingDevices;
    String id;
    String abbreviation;
    String name;
    String mapcode;
    String mapname;
    String description;

    /**
     * 
     */
    public BedParams()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param isManagingDevices
     * @param id
     * @param abbreviation
     * @param name
     * @param mapcode
     * @param mapname
     * @param description
     */
    public BedParams(String isManagingDevices, String id, String abbreviation, String name, String mapcode,
            String mapname, String description)
    {
        super();
        this.isManagingDevices = isManagingDevices;
        this.id = id;
        this.abbreviation = abbreviation;
        this.name = name;
        this.mapcode = mapcode;
        this.mapname = mapname;
        this.description = description;
    }

    /**
     * @return the isManagingDevices
     */
    public String getIsManagingDevices()
    {
        return this.isManagingDevices;
    }

    /**
     * @param isManagingDevices the isManagingDevices to set
     */
    public void setIsManagingDevices(String isManagingDevices)
    {
        this.isManagingDevices = isManagingDevices;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return this.id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the abbreviation
     */
    public String getAbbreviation()
    {
        return this.abbreviation;
    }

    /**
     * @param abbreviation the abbreviation to set
     */
    public void setAbbreviation(String abbreviation)
    {
        this.abbreviation = abbreviation;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the mapcode
     */
    public String getMapcode()
    {
        return this.mapcode;
    }

    /**
     * @param mapcode the mapcode to set
     */
    public void setMapcode(String mapcode)
    {
        this.mapcode = mapcode;
    }

    /**
     * @return the mapname
     */
    public String getMapname()
    {
        return this.mapname;
    }

    /**
     * @param mapname the mapname to set
     */
    public void setMapname(String mapname)
    {
        this.mapname = mapname;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return this.description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "BedParams [isManagingDevices=" + isManagingDevices + ", id=" + id + ", abbreviation=" + abbreviation
                + ", name=" + name + ", mapcode=" + mapcode + ", mapname=" + mapname + ", description=" + description
                + "]";
    }

}
