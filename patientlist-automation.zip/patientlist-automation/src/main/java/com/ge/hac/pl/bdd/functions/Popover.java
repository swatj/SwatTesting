/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinathj
 * 
 */
public class Popover
{
    private static Logger   logger   = Logger.getLogger(Popover.class);
    private SeleniumUtility selUtility;
    private static Popover  instance = null;

    private Popover()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("Popover() - error initializing web browser.", e);
        }

    }

    public static Popover getInstance()
    {
        if ( instance == null )
        {
            instance = new Popover();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    public boolean invokePopover(String columnName, int rowNumber)
            throws Exception
    {
        // make column visible on table
        List<String> patientListColumnHeaderList = new ArrayList<String>();
        patientListColumnHeaderList.add(columnName);
        PatientListData.getInstance().makeColumnVisible(patientListColumnHeaderList);
        // get column position
        int columnNumber = PatientListData.getInstance().getColumnPosition(patientListColumnHeaderList, columnName);
        // create xpath by using rowNumber and columnNumber and retrive element
        String cellValueXpath = "[" + rowNumber + "]//td[" + columnNumber + "]//div";
        List<WebElement> cellData = selUtility.findElementsUsingDynamicPath("allRows", cellValueXpath);
        // click on cell
        cellData.get(0).click();
        return true;

    }

    public boolean closePopover()
            throws Exception
    {
        selUtility.elementClick("currentDateLable");
        return true;
    }

    public String getPopoverData()
            throws Exception
    {
        return selUtility.get_text("Popover").replace(Constants.NEWLINE_SEPERATOR,
                Constants.COMMA_SEPERATOR);

    }

    public boolean PopoverDisplayed()
            throws Exception
    {
        Thread.sleep(1000);
        return selUtility.elementDisplayedByXpath("Popover");
    }
}
