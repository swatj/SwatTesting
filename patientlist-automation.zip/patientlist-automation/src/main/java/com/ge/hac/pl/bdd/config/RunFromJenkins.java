/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.config;

import org.junit.runner.JUnitCore;

public class RunFromJenkins
{

    public static void main(String args[])
    {

        JUnitCore.runClasses(BatchRunner.class);
        System.exit(1);
    }
}
