package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.ResourceView;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class DepartmentSteps
{

    @When("the user selects date from from date field")
    public void selectFromDate(@Named("fromdate") String fdate)
            throws Exception

    {
        PatientList.getInstance().setDateCalender("from", fdate);

    }

    @Then("the user chooses <fromdate> in From Date field")
    public void chooseFromDate(@Named("fromdate") String fdate)
            throws Exception

    {
        PatientList.getInstance().setDateCalender("from", fdate);

    }

    @When("the user selects date from to date field")
    public void selectToDate(@Named("todate") String tdate)
            throws Exception
    {
        PatientList.getInstance().setDateCalender("to", tdate);
    }

    @Then("the user chooses <todate> in To Date field")
    public void chooseToDate(@Named("todate") String tdate)
            throws Exception
    {
        PatientList.getInstance().setDateCalender("to", tdate);
    }

    @When("the user clicks on the search button")
    public void clickSearchButton()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().clickOnSearch();
    }

    @Then("the user clicks on the date search button")
    public void clickGoButton()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().clickOnSearch();
    }

    @Then("the user clicks on continue button")
    public void clickContinueButton()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().clickOnContinue();
        Thread.sleep(1000);
    }

    @Then("the user clicks on refine search button")
    public void clickRefineSearchButton()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().clickOnRefineSearch();
        Thread.sleep(1000);
    }

    @Then("the Patient List should display the departments - <departments><numberOfDept>")
    public void verifyDisplayOfDepartment(@Named("departments") String departments,
            @Named("numberOfDept") String noOfDept)
                    throws IOException, InterruptedException
    {
        String[] deptList = departments.split(",");
        for (int i = 0; i < deptList.length; i++)
        {
            String deptName = deptList[i];
            boolean bStatus = Site.getInstance().verifyDepartment(deptName);
            Assert.assertEquals("Verify Department on department tab = " + deptName, true, bStatus);
        }

        // verify number of displayed department
        Assert.assertEquals("Verify nuumber of displayed departments on department tab", Integer.parseInt(noOfDept),
                Site.getInstance().getNoOfDisplayedDept());

    }

    @When("the user selects <department> from department tab")
    @Alias("user select <department> Anesthesia department")
    @Then("the user selects <department> from department tab")
    public void selectDepartment(@Named("department") String department)
            throws IOException, InterruptedException
    {
        Site.getInstance().selectDepartment(department);
    }

    @Then("the departments are displayed in alphabetical order")
    public void verifyDepartmentOrder()
            throws IOException, InterruptedException
    {
        Site.getInstance().verifyDepartmentOrder();

    }

    @Then("the <departments> are displayed by department type order")
    @Alias("the user should able to view the 'All' and only ICU departments")
    public void verifyDepartmentsOrderByType(@Named("departments") String departments)
            throws IOException, InterruptedException
    {
        String deptListOdr = Site.getInstance().getDepartmentOrder();
        Assert.assertEquals("Verify Departments are displayed by dept type order. actual= " + deptListOdr
                + " expected =" + departments, departments.toUpperCase(), deptListOdr.toUpperCase());

    }

    @Then("the last department tab displayed will have a drop down available")
    public void verifyDepartmentDropDownIndication()
            throws IOException, InterruptedException
    {
        boolean bStatus = Site.getInstance().verifyDepartmentDropDownIndication();
        Assert.assertEquals("Verify deprtment dropdown indication", bStatus, true);

    }

    @Then("the user will be able to view the other departments on selecting the department drop down")
    @Aliases(values =
    {
            "the last department which had the drop down will be replaced with selected department from the drop down",

            "Patient list should retain last saved department configuration",
            "Department configurstion will be retained on site change",
            "Department configurstion will be retained on date change"
    })
    public void verifyDepartmentInDropdown(@Named("DepartmentsInDropdown") String departments)
            throws IOException, InterruptedException
    {

        String[] deptList = departments.split(",");
        for (int i = 0; i < deptList.length; i++)
        {
            String deptName = deptList[i];
            boolean bStatus = Site.getInstance().verifyDepartmentInDropdown(deptName);
            Assert.assertEquals("Verify Department on department dropdown = " + deptName, true, bStatus);
        }

    }

    @Then("the <departments> of the site are displayed")
    public void verifyDepartments(@Named("departments") String departments)
            throws IOException, InterruptedException
    {

        String[] deptList = departments.split(",");
        for (int i = 0; i < deptList.length; i++)
        {
            String deptName = deptList[i];
            boolean bStatus = Site.getInstance().verifyDepartment(deptName);
            Assert.assertEquals("Verify Department on department dropdown = " + deptName, true, bStatus);
        }

    }

    @When("the user selects <department> from department dropdown")
    public void selectDepartmentInDropdown(@Named("department") String department)
            throws Exception
    {
        boolean bStatus = Site.getInstance().selectDepartment(department);
        Assert.assertEquals("select Department on department dropdown = " + department, true, bStatus);

    }

    @When("refresh the browser")
    @Aliases(values =
    {
            "the user refreshes the browser"
    })
    public void whenRefreshTheBrowser()
            throws IOException, InterruptedException
    {
        SeleniumUtility.getInstance().browserRefresh();
        boolean gridDisplayed = SeleniumUtility.getInstance().elementDisplayedByXpath("datagrid");
        Assert.assertEquals("user is able to view the Patient List grid", true, gridDisplayed);
        Thread.sleep(6000);
    }

    @When("the user select <diffsite> from site dropdown")
    public void whenUserSelectDifferentsiteFromAddSiteDropdown(@Named("diffsite") String site)
            throws IOException, InterruptedException
    {
        boolean bStatus = Site.getInstance().verifyActiveSite(site);
        if ( !bStatus )
        {
            Site.getInstance().clickAddSite();
            bStatus = Site.getInstance().AddSite(site);
            Thread.sleep(6000);
            PatientList.getInstance().waitForElementToAppear("add_site", site, Constants.HIGH_TIMEOUT);
        }

        Assert.assertEquals("select Site From Add Site dropdown = " + site, true, bStatus);
        bStatus = Site.getInstance().verifyActiveSite(site);
        Assert.assertEquals("select Site From Add Site dropdown = " + site, true, bStatus);
    }

    @When("refresh the browser after server restart")
    public void RefreshTheBrowser()
            throws IOException
    {
        SeleniumUtility.getInstance().browserRefresh();
        PatientList.getInstance().waitForElementToAppear("signin", Constants.SIGNIN_BUTTON_LABEL,
                Constants.HIGH_TIMEOUT);

    }

    @Then("the first ICU department[alphabetically] should selected by default and Resource view should display for that department")
    public void verifyICUActiveDepartment(@Named("activeDepartment") String activeDepartment)
            throws IOException, InterruptedException
    {
        Assert.assertEquals(
                "Verify that the first ICU department[alphabetically] was selected by default and Resource view was displayed for that department",
                true, Site.getInstance().verifyActiveDepartment(activeDepartment));
        Assert.assertEquals("Verify that Resource view was displayed.", true, ResourceView.isResourceViewDisplayed());

    }

    @Then("the 'All' tab should not display on department tab")
    public void verifyAllTabIsNotDisplayed()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Verify that All tab iwass not displayed on site/department navigation panel", false,
                Site.getInstance().isAllTabDisplayed());
    }

    @Then("the user resize the application window")
    public void resizeWindow()
            throws Exception
    {

        PatientList.getInstance().resizeWindow();

    }
}
