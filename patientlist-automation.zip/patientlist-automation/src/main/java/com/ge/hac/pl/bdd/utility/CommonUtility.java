/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Prithy       30 May 2014         Contains all the Constants
 */

package com.ge.hac.pl.bdd.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.jbehave.core.model.ExamplesTable;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;

import com.ge.hac.ca.common.objectmapping.PolymorphicDtoMixIn;
import com.ge.hac.ca.common.objectmapping.PolymorphicEntityChangeMixIn;
import com.ge.hac.common.ea.dto.DataTransferObject;
import com.ge.hac.common.ea.dto.configuration.LocaleConfig;
import com.ge.hac.common.ea.synchronization.DataChange;

public class CommonUtility
{
    private static Logger logger = Logger.getLogger(CommonUtility.class);
    /**
     * Get the Driver based on browser type
     * 
     * @param browserType
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    static WebDriver      driver = null;

    public static WebDriver getDriver(String browserType)
            throws FileNotFoundException, IOException, UnreachableBrowserException, WebDriverException,
            SecurityException
    {
        File file = null;
        String browserPath = PropertyFileHelper.getProjectProperty("BrowserPath");
        logger.debug("Getting driver for browser type = " + browserType + " from browser path = " + browserPath);

        if ( "IEExplorer".equalsIgnoreCase(browserType) )
        {
            file = new File(browserPath + "\\IEDriverServer.exe");
            System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
            driver = new InternetExplorerDriver();
        }
        else if ( "Chrome".equalsIgnoreCase(browserType) )
        {
            file = new File(browserPath + "\\chromedriver.exe");
            System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
            driver = new ChromeDriver();
            driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
            Runtime.getRuntime().addShutdownHook(new Thread(new DriverKiller()));
        }
        else
        {
            driver = new FirefoxDriver();
        }
        // Adds Shutdown Hook event listener for killing Selenium driver
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().deleteAllCookies();

        return driver;
    }

    static class DriverKiller
            implements Runnable
    {

        @Override
        public void run()
        {
            if ( driver != null )
            {
                driver.quit();
            }
        }
    }

    public static ObjectMapper getMapperObject()
    {
        ObjectMapper mapper = new ObjectMapper();
        mapper.getDeserializationConfig().addMixInAnnotations(DataTransferObject.class, PolymorphicDtoMixIn.class);
        mapper.getSerializationConfig().addMixInAnnotations(DataTransferObject.class, PolymorphicDtoMixIn.class);
        mapper.getSerializationConfig().addMixInAnnotations(DataChange.class, PolymorphicEntityChangeMixIn.class);
        mapper.getDeserializationConfig().addMixInAnnotations(DataChange.class, PolymorphicEntityChangeMixIn.class);
        return mapper;

    }

    @SuppressWarnings("unchecked")
    public static Object getObjectFromJson(ObjectMapper mapper, String jsonString, Class clazz)
    {
        Object obj = null;
        try
        {
            obj = mapper.readValue(jsonString, clazz);
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.utility.CommonUtility.getObjectFromJson", e);
        }
        return obj;
    }

    /**
     * @param <T>
     * @param mapperObject
     * @param getResponseString
     * @param constructCollectionLikeType
     * @return
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> Object getObjectListFromJson(ObjectMapper mapper, String jsonString, Class<T> collection,
            Class entity)
    {
        try
        {
            return mapper.readValue(jsonString, TypeFactory.defaultInstance()
                    .constructCollectionType((Class<? extends Collection>) collection, entity));
        }
        catch (IOException e)
        {
            logger.error("IOException in com.ge.hac.pl.bdd.utility.CommonUtility.getObjectFromJson", e);
        }
        return null;
    }

    public static Boolean compareLists(List<String> actual, List<String> expected)
    {
        Boolean bReturn = true;

        if ( (actual == null) || (expected == null) )
        {
            return false;
        }

        if ( actual.size() != expected.size() )
        {
            return false;
        }

        for (int itrActual = 0; itrActual < actual.size(); itrActual++)
        {
            String actualVal = actual.get(itrActual);
            for (int itrExpect = 0; itrExpect < expected.size(); itrExpect++)
            {
                if ( actualVal.trim().equalsIgnoreCase(expected.get(itrExpect).trim()) )
                {
                    bReturn = true;
                    break;
                }
                else
                {
                    bReturn = false;
                }
            }

            if ( !bReturn )
            {
                break;
            }
        }

        return bReturn;
    }

    /**
     * @param dataTable
     * @param i
     */
    public static void validateExampleTable(ExamplesTable dataTable, Integer expectedRows)
            throws Exception
    {
        if ( dataTable == null )
        {
            throw new Exception("Empty example table passed");
        }

        if ( dataTable != null )
        {
            if ( (expectedRows != null) && (dataTable.getRowCount() != expectedRows) )
            {
                throw new Exception("Example table doesn't have expected number of rows. Expected: " + expectedRows
                        + ", Actual: " + dataTable.getRowCount());
            }
            else if ( dataTable.getRowCount() == 0 )
            {
                throw new Exception("Empty example table");
            }
        }
    }

    public static boolean isListAlphabeticallySorted(List<String> stringList)
    {
        if ( (stringList != null) && (!stringList.isEmpty()) )
        {
            String prevValue = "";
            for (final String currValue : stringList)
            {
                if ( currValue.compareToIgnoreCase(prevValue) < 0 )
                {
                    return false;
                }
                prevValue = currValue;
            }
            return true;
        }
        return false;
    }

    public static LocaleParams extractLocaleConfig(ExamplesTable dataTable, Integer expectedRowsInTable)
            throws Exception
    {
        LocaleParams localeParams = null;
        String locale = null;
        String dateOrder = null;
        String dateSeparator = null;
        String use24HourFormat = null;
        String decimalSeparator = null;
        boolean bUse24HourFormat = false;
        Character cDateSeparator = null;
        Character cDecimalSeparator = null;

        CommonUtility.validateExampleTable(dataTable, expectedRowsInTable);

        for (Map<String, String> row : dataTable.getRows())
        {
            locale = row.get("locale");
            dateOrder = row.get("dateOrder");
            dateSeparator = row.get("dateSeparator");
            use24HourFormat = row.get("use24HourFormat");
            decimalSeparator = row.get("decimalSeparator");
        }

        bUse24HourFormat = Boolean.parseBoolean(use24HourFormat);

        // there should be only one character for date & decimal separator in feature file
        cDateSeparator = dateSeparator.charAt(0);
        cDecimalSeparator = decimalSeparator.charAt(0);

        localeParams = new LocaleParams(locale, dateOrder, cDateSeparator, bUse24HourFormat, cDecimalSeparator);

        return localeParams;
    }

    public static String createInvalidCurrentDateString(LocaleConfig localeInformation)
    {
        String invalidCurrentDate = "";
        String dateFormat = localeInformation.getDateFormat();
        String currentDate = getDateUsingLocale(localeInformation, "now");
        String dateSeparator = String.valueOf(localeInformation.getDateSeparator());

        List<String> dfList = Arrays.asList(dateFormat.split("\\" + dateSeparator));
        List<String> dateList = Arrays.asList(currentDate.split("\\" + dateSeparator));

        int index = dfList.indexOf("MM");
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < dateList.size(); i++)
        {
            if ( i != index )
            {
                sb.append(dateList.get(i)).append(dateSeparator);
            }
            else
            {
                sb.append("14").append(dateSeparator);
            }
        }

        invalidCurrentDate = sb.toString().substring(0, sb.length() - 1);
        return invalidCurrentDate;
    }

    /**
     * @param getResponseEntity
     * @return
     */
    public static String getDateUsingLocale(LocaleConfig localeInformation, String indicator)
    {
        String dateVal = "";
        switch (indicator.toLowerCase())
        {
            case "now":
            case "current":
            {
                dateVal = getDate(localeInformation);
                break;
            }
            case "future":
                dateVal = getDate(localeInformation, "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("FUTURE_DATE")));
                break;
            case "past":
                dateVal = getDate(localeInformation, "day",
                        Integer.parseInt(PropertyFileHelper.getProjectProperty("PAST_DATE")));
                break;
            case "blank":
                dateVal = "";
                break;
        }
        return dateVal;
    }

    /**
     * @param localeInformation
     * @return
     */
    private static String getDate(LocaleConfig localeInformation, String datePartToChange, Integer durationToChange)
    {
        Calendar now = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat(localeInformation.getPattern(LocaleConfig.Precision.DATE));

        // Modify the date
        if ( "day".equalsIgnoreCase(datePartToChange) )
        {
            now.add(Calendar.DATE, durationToChange);
        }
        else if ( "month".equalsIgnoreCase(datePartToChange) )
        {
            now.add(Calendar.MONTH, durationToChange);
        }
        else if ( "year".equalsIgnoreCase(datePartToChange) )
        {
            now.add(Calendar.YEAR, durationToChange);
        }

        return df.format(now.getTime());
    }

    private static String getDate(LocaleConfig localeInformation)
    {
        Calendar now = Calendar.getInstance();
        return new SimpleDateFormat(localeInformation.getPattern(LocaleConfig.Precision.DATE)).format(now.getTime());
    }

    /**
     * Checks if the string is null or empty
     * 
     * @param stringToTest
     * @return
     */
    public static Boolean isStringEmptyOrNull(String stringToTest)
    {
        if ( (stringToTest == null) || (stringToTest.isEmpty()) )
        {
            return true;
        }

        return false;
    }

    /**
     * Generate an FRID for CA db
     */
    public static String getNewFrid()
    {
        String uuid = UUID.randomUUID().toString().substring(0, 18);
        uuid = "A".concat(uuid.replaceAll("-", ""));
        return uuid.toUpperCase().trim();
    }

    public static List<BedParams> extractBedCreationParamsFromTable(ExamplesTable dataTable)
    {
        List<BedParams> listParams = new ArrayList<BedParams>();

        for (Map<String, String> row : dataTable.getRows())
        {
            String isManagingDevices = row.get("isManagingDevices");
            String id = row.get("id");
            String abbreviation = row.get("abbreviation");
            String name = row.get("name");
            String mapcode = row.get("mapcode");
            String mapname = row.get("mapname");
            String description = row.get("description");

            listParams.add(new BedParams(isManagingDevices, id, abbreviation, name, mapcode, mapname, description));
        }

        return listParams;
    }

    public static List<RoomParams> extractRoomCreationParamsFromTable(ExamplesTable dataTable)
    {
        List<RoomParams> listParams = new ArrayList<RoomParams>();

        for (Map<String, String> row : dataTable.getRows())
        {
            String roomType = row.get("roomType");
            String id = row.get("id");
            String abbreviation = row.get("abbreviation");
            String name = row.get("name");
            String mapcode = row.get("mapcode");
            String mapname = row.get("mapname");
            String description = row.get("description");
            String bedList = row.get("bedList");

            List<String> bedNames = new ArrayList<String>();
            if ( !CommonUtility.isStringEmptyOrNull(bedList) )
            {
                bedNames = Arrays.asList(bedList.split(","));
            }

            listParams.add(new RoomParams(roomType, id, abbreviation, name, mapcode, mapname, description, bedNames));
        }

        return listParams;
    }

    public static List<DepartmentParams> extractDeptCreationParamsFromTable(ExamplesTable dataTable)
    {
        List<DepartmentParams> listParams = new ArrayList<DepartmentParams>();

        for (Map<String, String> row : dataTable.getRows())
        {
            String deptType = row.get("deptType");
            String id = row.get("id");
            String abbreviation = row.get("abbreviation");
            String name = row.get("name");
            String mapcode = row.get("mapcode");
            String mapname = row.get("mapname");
            String description = row.get("description");
            String roomNames = row.get("roomList");

            List<String> roomList = new ArrayList<String>();
            if ( !CommonUtility.isStringEmptyOrNull(roomNames) )
            {
                roomList = Arrays.asList(roomNames.split(","));
            }

            listParams.add(
                    new DepartmentParams(deptType, id, abbreviation, name, mapcode, mapname, description, roomList));
        }

        return listParams;
    }

    public static List<HospitalParams> extractHospitalCreationParamsFromTable(ExamplesTable dataTable)
    {
        List<HospitalParams> listParams = new ArrayList<HospitalParams>();

        for (Map<String, String> row : dataTable.getRows())
        {
            String name = row.get("name");
            String abbreviation = row.get("abbreviation");
            String description = row.get("description");
            String mapcode = row.get("mapcode");
            String mapname = row.get("mapname");
            String id = row.get("id");
            String code = row.get("code");
            String departmentList = row.get("departmentList");

            List<String> departmentNames = new ArrayList<String>();
            if ( !CommonUtility.isStringEmptyOrNull(departmentList) )
            {
                departmentNames = Arrays.asList(departmentList.split(","));
            }

            listParams.add(
                    new HospitalParams(name, abbreviation, description, mapcode, mapname, id, code, departmentNames));
        }

        return listParams;
    }

    /**
     * @param command
     * @param rt
     * @throws IOException
     * @throws InterruptedException
     */
    public static void executeProcess(String command, Runtime rt)
            throws IOException, InterruptedException
    {
        Process p;
        StreamConsumer inputConsumer;
        StreamConsumer outputConsumer;

        p = rt.exec(command);
        inputConsumer = new StreamConsumer(p.getInputStream());
        outputConsumer = new StreamConsumer(p.getErrorStream());
        inputConsumer.start();
        outputConsumer.start();

        int exitVal = p.waitFor();
        System.out.println("Exit value : " + exitVal);

    }

}
