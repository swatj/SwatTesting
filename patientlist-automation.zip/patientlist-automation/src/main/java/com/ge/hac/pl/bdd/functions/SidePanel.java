/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;

import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class SidePanel
{
    // function is used to click on collapse button when side panel is expanded
    public static void clickOnCollapse()
            throws IOException
    {

        SeleniumUtility.getInstance().elementClick("SidePanelCollapseButton");
    }

    // Function is used to click on expand button when side panel is collapsed
    public static void clickOnExpand()
            throws IOException
    {

        SeleniumUtility.getInstance().elementClick("SidePanelExpandButton");
    }

    // This will return true if side panel is collapsed
    public static boolean isSidePanelCollapsed()
            throws IOException
    {
        return SeleniumUtility.getInstance().elementDisplayedByXpath("SidePanelExpandButton");
    }

    // This will return true if side panel is expanded
    public static boolean isSidePanelExpanded()
            throws IOException
    {
        return SeleniumUtility.getInstance().elementDisplayedByXpath("ArrivalTabLabel");

    }

    // This one will return Arrival tab label when side panel is expanded
    public static String getArrivalTabLabelInExpandedMode()
            throws IOException
    {

        return SeleniumUtility.getInstance().get_text("ArrivalTabLabel");

    }

    // This one will return side panel label when it is collapsed
    public static String getArrivalTabLabelInCollapsedMode()
            throws IOException
    {

        return SeleniumUtility.getInstance().get_text("ArrivalLabelInCollapseMode");

    }

    // This function will return true if collapsed button is displayed
    public static boolean isSidePanelCollapseButtonDisplayed()
            throws IOException
    {

        return SeleniumUtility.getInstance().elementDisplayedByXpath("SidePanelCollapseButton");
    }

    // This function will return true if expanded button is displayed
    public static boolean isSidePanelExpandButtonDisplayed()
            throws IOException
    {

        return SeleniumUtility.getInstance().elementDisplayedByXpath("SidePanelExpandButton");
    }

    // This function will return Width of bed layout container.
    public static int getWidthOfBedLayoutContainer()
            throws IOException
    {
        return SeleniumUtility.getInstance().getElementByXPath("BedLayoutContainer").getSize().getWidth();

    }
}
