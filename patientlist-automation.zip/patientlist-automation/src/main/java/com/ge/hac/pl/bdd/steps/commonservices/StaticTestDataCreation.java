/* Copyright (c) 2016 GE Healthcare. All rights reserved.
 * The copyright to the computer software herein is the property of GE Healthcare.
 * The software may be used and/or copied only with the written permission of GE Healthcare or in accordance 
 * with the terms and conditions stipulated in the agreement/contract under which the software has been supplied. */
package com.ge.hac.pl.bdd.steps.commonservices;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.text.SimpleDateFormat;

import org.elasticsearch.action.ClientAction;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.model.ExamplesTable;

import com.ge.hac.ca.bdd.common.assertj.ClientFixture.ClientState;
import com.ge.hac.ca.bdd.common.assertj.ClientFixture.ClientType;
import com.ge.hac.ca.client.AbstractApplication;
import com.ge.hac.ca.client.ApplicationController;
import com.ge.hac.ca.client.IApplication;
import com.ge.hac.dataservice.DefaultDataServiceManager;
import com.ge.hac.ca.bdd.common.assertj.ClientHandler;
import com.ge.hac.ca.bdd.common.assertj.ClinicalClientFixture;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class StaticTestDataCreation
{
    ClinicalClientFixture client;
    String                tomorrowformattedString;
    String                todayFormattedString;
    String                yesterdayFormattedstring;
    String                pastFormattedstring;

    @Given("user will log into the CA IntraOp")
    public void givenUserLogsIntoTheCAIntraOpThickClient()
            throws Exception
    {
        // For closing browser
        PatientList.getInstance().closePatientListBrowser();
        PatientList.closeInstance();
        SeleniumUtility.closeInstance();

        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        ClientHandler.initialize();
        client = (ClinicalClientFixture) ClientHandler.startClientAndSetActive(ClientType.intraop,
                ClientState.loginDialog);

        // Login
        client.loginDialog.waitUntilEnabled(30 * 1000);
        if ( client.loginDialog.isEnabled() )
        {
            client.loginDialog.username.waitUntilEnabled(10 * 1000);
            client.loginDialog.username.setText("Administrator");
            client.loginDialog.password.waitUntilEnabled(10 * 1000);
            client.loginDialog.password.setText("healthcare");
            

            client.loginDialog.department.selectItem(0);
            try
            {
                client.loginDialog.department.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.department.selectItem(0);
            }

            client.loginDialog.location.selectItem(0);
            try
            {
                client.loginDialog.location.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.location.selectItem(0);
            }
            client.loginDialog.loginButton.click();
        }
        client.waitUntilShowing(720 * 1000);
        Date today = new Date();
        todayFormattedString = convertDateToFormattedString(today);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date tommrrow = cal.getTime();
        tomorrowformattedString = convertDateToFormattedString(tommrrow);
        cal.add(Calendar.DAY_OF_MONTH, -2);
        Date yesterday = cal.getTime();
        yesterdayFormattedstring = convertDateToFormattedString(yesterday);
        cal.add(Calendar.DAY_OF_MONTH, -3);
        Date past = cal.getTime();
        pastFormattedstring = convertDateToFormattedString(past);
        System.out.println(todayFormattedString + tomorrowformattedString + yesterdayFormattedstring);
    }

    @Given("user will navigate to the patients and cases display tab")
    public void givenUserNavigatesToThePatientsAndCasesDisplayTab()
    {

        client.selectionMenu.patientListButton.click();
        client.tabbedDisplayFrame.selectPatientsAndCasesTab();

    }

    @Given("user will click on the new patient button")
    public void givenUserClicksOnTheNewPatientButton()
    {

        client.tabbedDisplayFrame.patientsAndCasesDisplay.newPatientButton.click();
    }

    @Given("user will enter patient details: $patientsTable")
    public void whenUserEntersPatientDetails(ExamplesTable patientsTable)
    {

        for (Map<String, String> row : patientsTable.getRows())
        {
            String firstname = row.get("firstname");
            String lastname = row.get("lastname");
            String patientid = row.get("patientid");
            String ssid = row.get("ssid");
            String sex = row.get("sex");

            client.tabbedDisplayFrame.patientInfoDisplay.fill(firstname, lastname, patientid, ssid);
            if ( !sex.equalsIgnoreCase("") && !sex.equalsIgnoreCase(" ") && !sex.equalsIgnoreCase(null) )
            {
                if ( sex.equalsIgnoreCase("male") )
                {
                    client.tabbedDisplayFrame.patientInfoDisplay.male.check();
                }
                else if ( sex.equalsIgnoreCase("female") )
                {
                    client.tabbedDisplayFrame.patientInfoDisplay.female.check();
                }
                else if ( sex.equalsIgnoreCase("other") )
                {
                    client.tabbedDisplayFrame.patientInfoDisplay.otherSex.check();
                }
                else if ( sex.equalsIgnoreCase("unknown") )
                {
                    client.tabbedDisplayFrame.patientInfoDisplay.unknown.check();
                }
            }

            client.tabbedDisplayFrame.patientInfoDisplay.buttonRow.approveAndClose();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.newPatientButton.click();
        }

    }

    @Given("user enters case details for the patients:$caseTable")
    public void givenUserEntersPatientDetails(ExamplesTable caseTable)
            throws InterruptedException
    {

        for (Map<String, String> row : caseTable.getRows())
        {
            String patientid = row.get("patientid");
            String admissionDateField = row.get("admissionDateField");
            String visitIDField = row.get("visitIDField");
            String procedureDateField = row.get("procedureDateField");
            String preopVisitField = row.get("preopVisitField");
            String birthdateField = row.get("birthdateField");
            String service = row.get("service");
            String preOpDepartment = row.get("preOpDepartment");
            String surgicalDepartment = row.get("surgicalDepartment");
            String postOpDepartment = row.get("postOpDepartment");
            String postOpDischargedTo = row.get("postOpDischargedTo");
            String plannedSurgeon = row.get("plannedSurgeon");
            String plannedAnesthesiologist = row.get("plannedAnesthesiologist");
            String heightNweight = row.get("height&weight");

            if ( procedureDateField.equalsIgnoreCase("Today") )
            {
                procedureDateField = todayFormattedString;
            }
            else if ( procedureDateField.equalsIgnoreCase("Yesterday") )
            {
                procedureDateField = yesterdayFormattedstring;
            }
            else if ( procedureDateField.equalsIgnoreCase("Tomorrow") )
            {
                procedureDateField = tomorrowformattedString;
            }
            System.out.println("procedureDateField" + procedureDateField);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.newVisitAndCaseButton.click();

            // Create a new case
            client.tabbedDisplayFrame.displayNewCaseFixture.admissionDate.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.displayNewCaseFixture.admissionDate.setText(admissionDateField);
            try
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.admissionDate.requireText(admissionDateField);
            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.admissionDate.enterText(admissionDateField);
            }
            client.tabbedDisplayFrame.displayNewCaseFixture.visitId.setText(visitIDField);
            client.tabbedDisplayFrame.displayNewCaseFixture.schedProcedureDate.setText(procedureDateField);
            try
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.schedProcedureDate.requireText(procedureDateField);
            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.schedProcedureDate.enterText(procedureDateField);
            }
            client.tabbedDisplayFrame.displayNewCaseFixture.preopVisitDate.setText(preopVisitField);
            try
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.preopVisitDate.requireText(preopVisitField);
            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.preopVisitDate.enterText(preopVisitField);
            }
            if ( !birthdateField.equalsIgnoreCase("") && !birthdateField.equalsIgnoreCase(" ")
                    && !birthdateField.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.birthdate.setText(birthdateField);
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.birthdate.requireText(birthdateField);
                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.birthdate.enterText(birthdateField);
                }
            }
            if ( !heightNweight.equalsIgnoreCase("") && !heightNweight.equalsIgnoreCase(" ")
                    && !heightNweight.equalsIgnoreCase(null) )
            {
                String[] heightAndweight = heightNweight.split(",");
                String height = heightAndweight[0];
                String weight = heightAndweight[1];
                client.tabbedDisplayFrame.displayNewCaseFixture.height.setText(height);
                client.tabbedDisplayFrame.displayNewCaseFixture.weight.setText(weight);

            }
            if ( !service.equalsIgnoreCase("") && !service.equalsIgnoreCase(" ") && !service.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.service.selectItem(Integer.parseInt(service));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.service.requireSelection(Integer.parseInt(service));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.service.selectItem(Integer.parseInt(service));
                }

            }
            if ( !preOpDepartment.equalsIgnoreCase("") && !preOpDepartment.equalsIgnoreCase(" ")
                    && !preOpDepartment.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.preOpDepartment.waitUntilShowing();
                client.tabbedDisplayFrame.displayNewCaseFixture.preOpDepartment.waitUntilEnabled();
                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.preOpDepartment
                        .selectItem(Integer.parseInt(preOpDepartment));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.preOpDepartment
                            .requireSelection(Integer.parseInt(preOpDepartment));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.preOpDepartment
                            .selectItem(Integer.parseInt(preOpDepartment));
                }

            }
            if ( !surgicalDepartment.equalsIgnoreCase("") && !surgicalDepartment.equalsIgnoreCase(" ")
                    && !surgicalDepartment.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.displayNewCaseFixture.surgicalDepartment.waitUntilShowing();
                client.tabbedDisplayFrame.displayNewCaseFixture.surgicalDepartment.waitUntilEnabled();
                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.surgicalDepartment
                        .selectItem(Integer.parseInt(surgicalDepartment));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.surgicalDepartment
                            .requireSelection(Integer.parseInt(surgicalDepartment));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.surgicalDepartment
                            .selectItem(Integer.parseInt(surgicalDepartment));
                }

            }
            if ( !postOpDepartment.equalsIgnoreCase("") && !postOpDepartment.equalsIgnoreCase(" ")
                    && !postOpDepartment.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.displayNewCaseFixture.postOpDepartment.waitUntilShowing();
                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.postOpDepartment
                        .selectItem(Integer.parseInt(postOpDepartment));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.postOpDepartment
                            .requireSelection(Integer.parseInt(postOpDepartment));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.postOpDepartment
                            .selectItem(Integer.parseInt(postOpDepartment));
                }

            }

            if ( !postOpDischargedTo.equalsIgnoreCase("") && !postOpDischargedTo.equalsIgnoreCase(" ")
                    && !postOpDischargedTo.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.postOpDischargedTo
                        .selectItem(Integer.parseInt(postOpDischargedTo));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.postOpDischargedTo
                            .requireSelection(Integer.parseInt(postOpDischargedTo));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.postOpDischargedTo
                            .selectItem(Integer.parseInt(postOpDischargedTo));
                }

            }
            if ( !plannedSurgeon.equalsIgnoreCase("") && !plannedSurgeon.equalsIgnoreCase(" ")
                    && !plannedSurgeon.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.plannedSurgeon
                        .selectItem(Integer.parseInt(plannedSurgeon));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.plannedSurgeon
                            .requireSelection(Integer.parseInt(plannedSurgeon));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.plannedSurgeon
                            .selectItem(Integer.parseInt(plannedSurgeon));
                }

            }
            if ( !plannedAnesthesiologist.equalsIgnoreCase("") && !plannedAnesthesiologist.equalsIgnoreCase(" ")
                    && !plannedAnesthesiologist.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.displayNewCaseFixture.click();
                client.tabbedDisplayFrame.displayNewCaseFixture.plannedAnesthesiologist
                        .selectItem(Integer.parseInt(plannedAnesthesiologist));
                try
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.plannedAnesthesiologist
                            .requireSelection(Integer.parseInt(plannedAnesthesiologist));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.displayNewCaseFixture.plannedAnesthesiologist
                            .selectItem(Integer.parseInt(plannedAnesthesiologist));
                }
            }

            client.tabbedDisplayFrame.displayNewCaseFixture.buttonRow.saveAndBackButton.click();
        }
    }

    @Given("user changes case details for the patients:$caseInfoTable")
    public void givenUserEditsPatientDetails(ExamplesTable caseInfoTable)
            throws InterruptedException
    {
        for (Map<String, String> row : caseInfoTable.getRows())
        {
            String patientid = row.get("patientid");
            String operatingRoom = row.get("operatingRoom");
            String postopRoom = row.get("postopRoom");
            String postopBed = row.get("postopBed");
            String cancelledDate = row.get("cancelledDate");
            String isolation = row.get("isolation");
            if ( cancelledDate != null && cancelledDate.equalsIgnoreCase("Today") )
            {
                cancelledDate = todayFormattedString;
            }
            else if ( cancelledDate != null && cancelledDate.equalsIgnoreCase("Yesterday") )
            {
                cancelledDate = yesterdayFormattedstring;
            }
            else if ( cancelledDate != null && cancelledDate.equalsIgnoreCase("Tomorrow") )
            {
                cancelledDate = tomorrowformattedString;
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.click();

            if ( !cancelledDate.equalsIgnoreCase("") && !cancelledDate.equalsIgnoreCase(" ")
                    && !cancelledDate.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.caseInfoDisplay.privateNo.waitUntilShowing(180 * 1000);
                client.tabbedDisplayFrame.caseInfoDisplay.privateNo.click();
                client.tabbedDisplayFrame.caseInfoDisplay.cancelDate.waitUntilShowing(180 * 1000);
                client.tabbedDisplayFrame.caseInfoDisplay.cancelDate.setText(cancelledDate);
                try
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.cancelDate.requireText(cancelledDate);
                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.cancelDate.enterText(cancelledDate);
                }

            }
            if ( !operatingRoom.equalsIgnoreCase("") && !operatingRoom.equalsIgnoreCase(" ")
                    && !operatingRoom.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.caseInfoDisplay.operatingRoom.selectItem(Integer.parseInt(operatingRoom));
                try
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.operatingRoom
                            .requireSelection(Integer.parseInt(operatingRoom));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.operatingRoom.selectItem(Integer.parseInt(operatingRoom));
                }
            }
            if ( !postopRoom.equalsIgnoreCase("") && !postopRoom.equalsIgnoreCase(" ")
                    && !postopRoom.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.caseInfoDisplay.postOpRoom.selectItem(Integer.parseInt(postopRoom));
                try
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.postOpRoom.requireSelection(Integer.parseInt(postopRoom));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.postOpRoom.selectItem(Integer.parseInt(postopRoom));
                }
            }
            if ( !postopBed.equalsIgnoreCase("") && !postopBed.equalsIgnoreCase(" ")
                    && !postopBed.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.caseInfoDisplay.postopBed.waitUntilEnabled();
                client.tabbedDisplayFrame.caseInfoDisplay.postopBed.waitUntilShowing();
                client.tabbedDisplayFrame.caseInfoDisplay.postopBed.selectItem(Integer.parseInt(postopBed));
                try
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.postopBed.requireSelection(Integer.parseInt(postopBed));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.postopBed.selectItem(Integer.parseInt(postopBed));
                }
            }
            if ( !isolation.equalsIgnoreCase("") && !isolation.equalsIgnoreCase(" ")
                    && !isolation.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.caseInfoDisplay.isolationPrecautions.waitUntilEnabled();
                client.tabbedDisplayFrame.caseInfoDisplay.isolationPrecautions.waitUntilShowing();
                client.tabbedDisplayFrame.caseInfoDisplay.isolationPrecautions.selectItem(Integer.parseInt(isolation));
                try
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.isolationPrecautions
                            .requireSelection(Integer.parseInt(isolation));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoDisplay.isolationPrecautions
                            .selectItem(Integer.parseInt(isolation));
                }
            }
            client.tabbedDisplayFrame.caseInfoDisplay.buttonRow.approveAndClose();
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
        }

    }

    @Given("user fills dignosis and procedure data for cases:$caseDignosisProcedureTable")
    public void givenUserEditsDiagnosisProcedureInfoTable(ExamplesTable caseDignosisProcedureTable)
            throws InterruptedException
    {
        if ( client.messageBox.isShowing() )
        {
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.yesButton.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
        }
        for (Map<String, String> row : caseDignosisProcedureTable.getRows())
        {
            String patientid = row.get("patientid");
            String diagnosis = row.get("diagnosis");
            String procedure = row.get("procedure");
            String type = row.get("type");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }

            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.workList.waitUntilEnabled(180 * 1000);
            client.selectionMenu.caseButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.caseButton.click();
            client.selectionMenu.items.diagnosesAndProceduresMenuItem.waitUntilShowing(180 * 1000);
            client.selectionMenu.items.diagnosesAndProceduresMenuItem.click();

            if ( !diagnosis.equalsIgnoreCase("") && !diagnosis.equalsIgnoreCase(" ")
                    && !diagnosis.equalsIgnoreCase(null) )
            {
                String[] diagnosisList = diagnosis.split(",");

                for (String val : diagnosisList)
                {
                    client.dignosesProcedureTables.operativeDiagnoses.newbutton.waitUntilShowing(180 * 1000);
                    client.dignosesProcedureTables.operativeDiagnoses.newbutton.click();
                    client.tabbedDisplayFrame.operativeDiagnosisDisplay.diagnosis.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.operativeDiagnosisDisplay.diagnosis
                                .requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.operativeDiagnosisDisplay.diagnosis.selectItem(Integer.parseInt(val));
                    }
                    client.tabbedDisplayFrame.operativeDiagnosisDisplay.buttonRow.approveAndClose();
                }

            }

            if ( !procedure.equalsIgnoreCase("") && !procedure.equalsIgnoreCase(" ")
                    && !procedure.equalsIgnoreCase(null) )
            {

                String[] procedureList = procedure.split(",");

                for (String val : procedureList)
                {
                    if ( !type.equalsIgnoreCase("") && !type.equalsIgnoreCase(" ") && !type.equalsIgnoreCase(null) )
                    {
                        if ( type.equalsIgnoreCase("primary") )
                        {
                            client.dignosesProcedureTables.surgicalProcedure.newbutton.waitUntilShowing(180 * 1000);
                            client.dignosesProcedureTables.surgicalProcedure.newbutton.click();
                            client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure
                                    .selectItem(Integer.parseInt(val));
                            try
                            {
                                client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure
                                        .requireSelection(Integer.parseInt(val));

                            }
                            catch (AssertionError e)
                            {
                                client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure
                                        .selectItem(Integer.parseInt(val));
                            }
                            client.tabbedDisplayFrame.surgicalProceduresDisplay.primaryProcedure.click();
                            client.tabbedDisplayFrame.surgicalProceduresDisplay.buttonRow.approveAndClose();
                        }
                        else if ( type.equalsIgnoreCase("planned") )
                        {
                            client.dignosesProcedureTables.operativeDiagnoses.newbutton.waitUntilShowing(180 * 1000);
                            client.tabbedDisplayFrame.selectTab("Preop Diagnosis and Planned Procedure");
                            client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.preOperativeDiagnosis
                                    .selectItem(0);
                            try
                            {
                                client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.preOperativeDiagnosis
                                        .requireSelection(0);

                            }
                            catch (AssertionError e)
                            {
                                client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.preOperativeDiagnosis
                                        .selectItem(0);
                            }
                            client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.plannedProcedure
                                    .selectItem(Integer.parseInt(val));
                            try
                            {
                                client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.plannedProcedure
                                        .requireSelection(Integer.parseInt(val));

                            }
                            catch (AssertionError e)
                            {
                                client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.plannedProcedure
                                        .selectItem(Integer.parseInt(val));
                            }
                            client.tabbedDisplayFrame.preopDiagnosisAndPlannedProcedure.buttonRow.approveAndClose();

                        }

                    }
                    else
                    {
                        client.dignosesProcedureTables.surgicalProcedure.newbutton.waitUntilShowing(180 * 1000);
                        client.dignosesProcedureTables.surgicalProcedure.newbutton.click();
                        client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure.selectItem(Integer.parseInt(val));
                        try
                        {
                            client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure
                                    .requireSelection(Integer.parseInt(val));

                        }
                        catch (AssertionError e)
                        {
                            client.tabbedDisplayFrame.surgicalProceduresDisplay.procedure
                                    .selectItem(Integer.parseInt(val));
                        }
                        client.tabbedDisplayFrame.surgicalProceduresDisplay.buttonRow.approveAndClose();
                    }

                }

            }
            client.dignosesProcedureTables.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();
        }

    }

    @Given("user fills preop plan summary data for cases:$casePreopPlanSummaryTable")
    public void givenUserEditsPreopPlanSummaryTable(ExamplesTable casePreopPlanSummaryTable)
            throws InterruptedException
    {
        for (Map<String, String> row : casePreopPlanSummaryTable.getRows())
        {
            String patientid = row.get("patientid");
            String operability = row.get("operability");
            String asa = row.get("asa");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }

            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.workList.waitUntilEnabled(180 * 1000);
            client.selectionMenu.summariesButton.click();
            client.selectionMenu.items.preopPlanSummaryMenuItem.click();
            if ( !operability.equalsIgnoreCase("") && !operability.equalsIgnoreCase(" ")
                    && !operability.equalsIgnoreCase(null) )
            {
                if ( operability.equalsIgnoreCase("notReadyForOperation") )
                {
                    client.tabbedDisplayFrame.preopSummaryplan.notReadyForOperation.waitUntilShowing(180 * 1000);
                    client.tabbedDisplayFrame.preopSummaryplan.notReadyForOperation.check();
                }

            }
            if ( !asa.equalsIgnoreCase("") && !asa.equalsIgnoreCase(" ") && !asa.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.preopSummaryplan.asa.selectItem(Integer.parseInt(asa));
                try
                {
                    client.tabbedDisplayFrame.preopSummaryplan.asa.requireSelection(Integer.parseInt(asa));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.preopSummaryplan.asa.selectItem(Integer.parseInt(asa));
                }

            }
            client.tabbedDisplayFrame.preopSummaryplan.buttonRow.approveAndClose();
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();

        }
    }

    @Given("user fills Surgeon ,Anestheologist and  PACU RN data for cases:$caseRolesTable")
    public void givenUserEditscaseRolesTable(ExamplesTable caseRolesTable)
            throws InterruptedException
    {
        if ( client.messageBox.isShowing() )
        {
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.yesButton.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
        }
        for (Map<String, String> row : caseRolesTable.getRows())
        {
            String patientid = row.get("patientid");
            String surgeon = row.get("surgeon");
            String anestheologist = row.get("anestheologist");
            String pacuRN = row.get("pacuRN");
            String type = row.get("type");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }

            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.workList.waitUntilEnabled(180 * 1000);
            client.selectionMenu.caseButton.click();
            client.selectionMenu.items.personnelItemMenuItem.waitUntilShowing(180 * 1000);
            client.selectionMenu.items.personnelItemMenuItem.click();
            if ( !surgeon.equalsIgnoreCase("") && !surgeon.equalsIgnoreCase(" ") && !surgeon.equalsIgnoreCase(null) )
            {
                String[] roleList = surgeon.split(",");

                for (String val : roleList)
                {
                    client.tabbedDisplayFrame.personnel.newButton.waitUntilShowing(180 * 1000);
                    client.tabbedDisplayFrame.personnel.newButton.click();
                    client.tabbedDisplayFrame.personnel.role.selectItem(11);
                    try
                    {
                        client.tabbedDisplayFrame.personnel.role.requireSelection(11);

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.role.selectItem(11);
                    }
                    client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.personnel.name.requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    }
                    if ( !type.equalsIgnoreCase("") && !type.equalsIgnoreCase(" ") && !type.equalsIgnoreCase(null) )
                    {
                        if ( type.equalsIgnoreCase("primary") )
                        {
                            client.tabbedDisplayFrame.personnel.primary.click();
                        }

                    }
                    client.tabbedDisplayFrame.personnel.addButton.click();

                }

            }
            if ( !anestheologist.equalsIgnoreCase("") && !anestheologist.equalsIgnoreCase(" ")
                    && !anestheologist.equalsIgnoreCase(null) )
            {
                String[] roleList = anestheologist.split(",");

                for (String val : roleList)
                {
                    client.tabbedDisplayFrame.personnel.newButton.click();
                    client.tabbedDisplayFrame.personnel.role.selectItem(0);
                    try
                    {
                        client.tabbedDisplayFrame.personnel.role.requireSelection(0);

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.role.selectItem(0);
                    }
                    client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.personnel.name.requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    }
                    if ( !type.equalsIgnoreCase("") && !type.equalsIgnoreCase(" ") && !type.equalsIgnoreCase(null) )
                    {
                        if ( type.equalsIgnoreCase("primary") )
                        {
                            client.tabbedDisplayFrame.personnel.primary.click();
                        }

                    }
                    client.tabbedDisplayFrame.personnel.addButton.click();

                }
            }
            if ( !pacuRN.equalsIgnoreCase("") && !pacuRN.equalsIgnoreCase(" ") && !pacuRN.equalsIgnoreCase(null) )
            {
                String[] roleList = pacuRN.split(",");

                for (String val : roleList)
                {
                    client.tabbedDisplayFrame.personnel.newButton.click();
                    client.tabbedDisplayFrame.personnel.role.selectItem(9);
                    try
                    {
                        client.tabbedDisplayFrame.personnel.role.requireSelection(9);

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.role.selectItem(9);
                    }
                    client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.personnel.name.requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.name.selectItem(Integer.parseInt(val));
                    }
                    if ( !type.equalsIgnoreCase("") && !type.equalsIgnoreCase(" ") && !type.equalsIgnoreCase(null) )
                    {
                        if ( type.equalsIgnoreCase("primary") )
                        {
                            client.tabbedDisplayFrame.personnel.primary.click();
                        }

                    }
                    client.tabbedDisplayFrame.personnel.addButton.waitUntilShowing(180 * 1000);
                    client.tabbedDisplayFrame.personnel.addButton.click();

                }
            }
            client.tabbedDisplayFrame.personnel.buttonRow.saveAndBackButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.personnel.buttonRow.approveAndClose();
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();
        }

    }

    @Given("user will chart time event in intra op for the patients:$eventsTable")
    public void givenUserEntersEventsDetails(ExamplesTable eventsTable)
            throws InterruptedException
    {
        if ( client.messageBox.isShowing() )
        {
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.OkButton.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( client.messageBox.yesButton.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
        }
        for (Map<String, String> row : eventsTable.getRows())
        {
            String patientid = row.get("patientid");
            String type = row.get("type");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();

            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.workList.waitUntilEnabled(180 * 1000);
            if ( type.equalsIgnoreCase("Patient in preop holding") )
            {
                client.workList.preparationsElement.click();
                client.tabbedDisplayFrame.displayPatientPreOpHolding.patientInPreop.setText("11:14");
                client.tabbedDisplayFrame.displayPatientPreOpHolding.saveAndBackButton.click();
            }
            if ( type.equalsIgnoreCase("Patient in OR") )
            {
                client.workList.patientInORElement.nowLabel.click();
            }
            if ( type.equalsIgnoreCase("Patient out of OR") )
            {
                client.workList.patientOutOfORElement.nowLabel.click();
            }
            if ( type.equalsIgnoreCase("Primary Ane Technique") )
            {
                client.selectionMenu.summariesButton.click();
                client.selectionMenu.items.anesthesiaSummary.click();
                client.tabbedDisplayFrame.displayAnesthesiaSummary.primaryAneTechniqueLink.waitUntilShowing(10 * 1000);
                client.tabbedDisplayFrame.displayAnesthesiaSummary.primaryAneTechniqueLink.click();
                client.tabbedDisplayFrame.inductionDisplay.waitUntilShowing(10 * 1000);
                client.tabbedDisplayFrame.inductionDisplay.nowButton.click();
                client.tabbedDisplayFrame.inductionDisplay.primaryTechnique.selectItem(2);
                try
                {
                    client.tabbedDisplayFrame.inductionDisplay.primaryTechnique.requireSelection(2);

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.inductionDisplay.primaryTechnique.selectItem(2);
                }
                client.tabbedDisplayFrame.inductionDisplay.buttonRow.approveAndClose();

            }
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();

        }

    }

    @Then("Quit the client")
    public void QuitClient()
    {
        ClientHandler.teardown();
    }

    @Given("POC service is restarted")
    public void restartPocService()
    {
        String startService = PropertyFileHelper.getProjectProperty("command.start.poc");
        String stopService = PropertyFileHelper.getProjectProperty("command.stop.poc");
        System.out.println(startService + "************************************************************");
        Runtime rt = Runtime.getRuntime();

        try
        {
            System.out.println("Stopping service ....");
            CommonUtility.executeProcess(stopService, rt);
            Thread.sleep(3000);

            System.out.println("Starting service ....");
            CommonUtility.executeProcess(startService, rt);
            Thread.sleep(100000);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Given("user will log into the CA Postop")
    public void givenUserLogsIntoTheCAPostopThickClient()
            throws Exception
    {
        // For closing browser
        PatientList.getInstance().closePatientListBrowser();
        PatientList.closeInstance();
        SeleniumUtility.closeInstance();

        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        ClientHandler.initialize();
        client = (ClinicalClientFixture) ClientHandler.startNewClientAndSetActive(ClientType.postop,
                ClientType.postop.name() + "1", ClientState.loginDialog);

        // Login
        client.loginDialog.waitUntilEnabled(50 * 1000);
        if ( client.loginDialog.isEnabled() )
        {
            client.loginDialog.username.waitUntilEnabled(20 * 1000);
            client.loginDialog.username.setText("Administrator");
            client.loginDialog.password.waitUntilEnabled(20 * 1000);
            client.loginDialog.password.setText("healthcare");

            client.loginDialog.department.selectItem(0);
            try
            {
                client.loginDialog.department.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.department.selectItem(0);
            }

            client.loginDialog.location.selectItem(0);
            try
            {
                client.loginDialog.location.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.location.selectItem(0);
            }
            client.loginDialog.loginButton.click();
        }
        client.waitUntilShowing(720 * 1000);
        Date today = new Date();
        todayFormattedString = convertDateToFormattedString(today);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date tommrrow = cal.getTime();
        tomorrowformattedString = convertDateToFormattedString(tommrrow);
        cal.add(Calendar.DAY_OF_MONTH, -2);
        Date yesterday = cal.getTime();
        yesterdayFormattedstring = convertDateToFormattedString(yesterday);
        cal.add(Calendar.DAY_OF_MONTH, -3);
        Date past = cal.getTime();
        pastFormattedstring = convertDateToFormattedString(past);

    }

    @Given("user will chart time event in post op for the patients:$eventsTable")
    public void givenUserEntersEventsDetailsPostop(ExamplesTable eventsTable)
            throws InterruptedException
    {
        for (Map<String, String> row : eventsTable.getRows())
        {
            String patientid = row.get("patientid");
            String type = row.get("type");
            String date = row.get("date");
            if ( date != null && date.equalsIgnoreCase("Today") )
            {
                date = todayFormattedString;
            }
            else if ( date != null && date.equalsIgnoreCase("Yesterday") )
            {
                date = yesterdayFormattedstring;
            }
            else if ( date != null && date.equalsIgnoreCase("Tomorrow") )
            {
                date = tomorrowformattedString;
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.workList.waitUntilEnabled(180 * 1000);
            if ( type.equalsIgnoreCase("Discharged Time") )
            {

                if ( !date.equalsIgnoreCase("") && !date.equalsIgnoreCase(" ") && !date.equalsIgnoreCase(null) )
                {
                    client.workList.dischargeTimeElement.click();
                    client.dateAndTimeEntryDialog.dateField.enterText(date);
                    client.dateAndTimeEntryDialog.ok_Button.click();
                }
                else
                {
                    client.workList.dischargeTimeElement.nowLabel.click();
                }

            }
            if ( type.equalsIgnoreCase("PACU Admission Time") )
            {
                client.workList.admissionTimeElement.nowLabel.click();
                if ( client.messageBox.isShowing() )
                {
                    if ( client.messageBox.OkButton.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                    }
                    if ( client.messageBox.yesButton.isShowing() )
                    {
                        client.messageBox.yesButton.click();
                    }
                }
            }
            if ( type.equalsIgnoreCase("PACU Phase 2") )
            {
                client.workList.pacuPhase2Element.nowLabel.click();
            }
            if ( type.equalsIgnoreCase("End case") )
            {
                client.workList.endCaseElement.click();
                client.tabbedDisplayFrame.endCaseDisplay.printOptionNothing.click();
                client.tabbedDisplayFrame.endCaseDisplay.lockCase.click();
                if ( client.messageBox.isShowing() )
                {
                    client.messageBox.yesButton.click();
                }
                if ( client.messageBox.isShowing() )
                {
                    client.messageBox.yesButton.click();
                }

            }
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();

        }
    }

    @Given("user will log into the CA PreOp")
    public void givenUserLogsIntoTheCAPreOpThickClient()
            throws Exception
    {
        // For closing browser
        PatientList.getInstance().closePatientListBrowser();
        PatientList.closeInstance();
        SeleniumUtility.closeInstance();

        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        ClientHandler.initialize();
        client = (ClinicalClientFixture) ClientHandler.startNewClientAndSetActive(ClientType.preop,
                ClientType.preop.name() + "1", ClientState.loginDialog);

        // Login
        client.loginDialog.waitUntilEnabled(30 * 1000);
        if ( client.loginDialog.isEnabled() )
        {
            client.loginDialog.username.waitUntilEnabled(10 * 1000);
            client.loginDialog.username.setText("Administrator");
            client.loginDialog.password.waitUntilEnabled(10 * 1000);
            client.loginDialog.password.setText("healthcare");

            client.loginDialog.department.selectItem(0);
            try
            {
                client.loginDialog.department.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.department.selectItem(0);
            }

            client.loginDialog.location.selectItem(0);
            try
            {
                client.loginDialog.location.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.location.selectItem(0);
            }
            client.loginDialog.loginButton.click();
        }
        client.waitUntilShowing(720 * 1000);
        Date today = new Date();
        todayFormattedString = convertDateToFormattedString(today);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date tommrrow = cal.getTime();
        tomorrowformattedString = convertDateToFormattedString(tommrrow);
        cal.add(Calendar.DAY_OF_MONTH, -2);
        Date yesterday = cal.getTime();
        yesterdayFormattedstring = convertDateToFormattedString(yesterday);
        cal.add(Calendar.DAY_OF_MONTH, -3);
        Date past = cal.getTime();
        pastFormattedstring = convertDateToFormattedString(past);
    }

    @Given("user will chart infection information in preOp for the patients:$patientsTable")
    public void givenUserEntersInfectionDetailsPreop(ExamplesTable patientsTable)
            throws InterruptedException
    {
        for (Map<String, String> row : patientsTable.getRows())
        {
            String patientid = row.get("patientid");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.selectionMenu.statusButton.waitUntilEnabled(180 * 1000);
            client.selectionMenu.statusButton.click();
            client.selectionMenu.items.currentStateMenuItem.click();
            client.tabbedDisplayFrame.displayCurrentState.msra.click();
            client.tabbedDisplayFrame.displayCurrentState.buttonRow.approveAndClose();
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.yesButton.click();
            }
            client.selectionMenu.patientListButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientListButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();
        }
    }

    public static String convertDateToFormattedString(Date day)
    {
        SimpleDateFormat formatter = new SimpleDateFormat(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
        String date = formatter.format(day);
        return date;
    }

}
