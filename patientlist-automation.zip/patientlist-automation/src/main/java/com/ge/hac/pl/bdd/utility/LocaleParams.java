/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class LocaleParams
{
    private String    locale;
    private String    dateOrder;
    private Character dateSeparator;
    private boolean   use24HourFormat;
    private Character decimalSeparator;

    /**
     * 
     */
    public LocaleParams()
    {
        super();
    }

    /**
     * @param locale
     * @param dateOrder
     * @param dateSeparator
     * @param use24HourFormat
     * @param decimalSeparator
     */
    public LocaleParams(String locale, String dateOrder, Character dateSeparator, boolean use24HourFormat,
            Character decimalSeparator)
    {
        super();
        this.locale = locale;
        this.dateOrder = dateOrder;
        this.dateSeparator = dateSeparator;
        this.use24HourFormat = use24HourFormat;
        this.decimalSeparator = decimalSeparator;
    }

    /**
     * @return the locale
     */
    public String getLocale()
    {
        return this.locale;
    }

    /**
     * @param locale the locale to set
     */
    public void setLocale(String locale)
    {
        this.locale = locale;
    }

    /**
     * @return the dateOrder
     */
    public String getDateOrder()
    {
        return this.dateOrder;
    }

    /**
     * @param dateOrder the dateOrder to set
     */
    public void setDateOrder(String dateOrder)
    {
        this.dateOrder = dateOrder;
    }

    /**
     * @return the dateSeparator
     */
    public Character getDateSeparator()
    {
        return this.dateSeparator;
    }

    /**
     * @param dateSeparator the dateSeparator to set
     */
    public void setDateSeparator(Character dateSeparator)
    {
        this.dateSeparator = dateSeparator;
    }

    /**
     * @return the use24HourFormat
     */
    public boolean isUse24HourFormat()
    {
        return this.use24HourFormat;
    }

    /**
     * @param use24HourFormat the use24HourFormat to set
     */
    public void setUse24HourFormat(boolean use24HourFormat)
    {
        this.use24HourFormat = use24HourFormat;
    }

    /**
     * @return the decimalSeparator
     */
    public Character getDecimalSeparator()
    {
        return this.decimalSeparator;
    }

    /**
     * @param decimalSeparator the decimalSeparator to set
     */
    public void setDecimalSeparator(Character decimalSeparator)
    {
        this.decimalSeparator = decimalSeparator;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "LocaleParams [locale=" + locale + ", dateOrder=" + dateOrder + ", dateSeparator=" + dateSeparator
                + ", use24HourFormat=" + use24HourFormat + ", decimalSeparator=" + decimalSeparator + "]";
    }

}
