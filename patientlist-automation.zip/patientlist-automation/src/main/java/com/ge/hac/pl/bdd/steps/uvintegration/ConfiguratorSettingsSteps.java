/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Configurator;
import com.ge.hac.pl.bdd.functions.ConfiguratorSettings;

/**
 * @author 305019267
 * 
 */
public class ConfiguratorSettingsSteps
{
    @Given("that Configurator application is launched")
    public static void openConfiguratorApplication()
    {
        Configurator.openConfiguratorApplication();
        Configurator.waitForPageToload();
    }

    @When("user selects <tab>")
    public static void selectTab(@Named("tab") String tabName)
            throws IOException
    {

        ConfiguratorSettings.selectTab(tabName);

    }

    @Then("verify the links selected by default - <settings> <summary>")
    public static void verifyDefault(@Named("settings") String settings, @Named("summary") String summary)
    {
        boolean isSettingsDisplayed = ConfiguratorSettings.isLinkDisplay();
        Assert.assertEquals("Verify that Settings Link is displayed", true, isSettingsDisplayed);
        boolean isSummaryDisplayed = ConfiguratorSettings.isDefaultDisplay();
        Assert.assertEquals("Verify that Summary Link is displayed", true, isSummaryDisplayed);
    }

    @Then("verify the <Navigation> selected by default")
    public static void verifyNavigationDefault(@Named("Navigation") String Navigation)
    {
        boolean isGenealDisplayed = ConfiguratorSettings.isGeneralDisplay();
        Assert.assertEquals("Verify that Settings Link is displayed", true, isGenealDisplayed);
    }

    @Then("the <link> Summary and Configuration are displayed")
    public static void verifyLinks(@Named("link") String linkName)
            throws IOException
    {
        boolean isDisplayed = ConfiguratorSettings.isLinkDisplay();
        Assert.assertTrue("Verify that Summary Link is displayed", isDisplayed);
    }

    @Then("the <link> Configuration are displayed")
    public static void verifyConfiguration(@Named("link") String linkName)
            throws IOException
    {
        boolean isConfigurationDisplayed = ConfiguratorSettings.isConfigurationDisplay();
        Assert.assertTrue("Verify that Summary Link is displayed", isConfigurationDisplayed);
    }

    @When("the user selects <link>")
    public static void selectLink(@Named("link") String linkName)
            throws IOException
    {
        ConfiguratorSettings.selectLink(linkName);

    }

    @When("the user selects Configuration <link>")
    public static void selectConfigurationLink(@Named("link") String linkName)
            throws IOException, InterruptedException
    {
        ConfiguratorSettings.selectConfigurationLink(linkName);
        Thread.sleep(5000);

    }

    // @Then("verify the Common System Properties:$DataTable")
    // public void verifyCommonSystemPropertiesTable(ExamplesTable dataTable)
    // throws IOException, InterruptedException
    //
    // {
    // ConfiguratorSettings.getInstance().verifyCommonConfigurationPropertyName(dataTable);
    //
    // }

    @Then("verify the Patient List System Properties:$DataTable")
    public void verifyPatientListSystemPropertiesTable(ExamplesTable dataTable)
            throws IOException, InterruptedException

    {
        ConfiguratorSettings.getInstance().verifyPatientListConfigurationPropertyName(dataTable);

    }

    @When("user selects <LogginNameUserFormat> from loggin_name_user_format dropdown")
    public static void selectLoginNameUserFormat(@Named("LogginNameUserFormat") String UserFormat)
    {
        ConfiguratorSettings.getInstance().selectLoginNameUserFormat(UserFormat);
        System.out.println("The selected value" + UserFormat);
    }

    @When("user selects <PatientNameFormat> from patient_name_format dropdown")
    public static void selectPatientNameFormat(@Named("PatientNameFormat") String PatientFormat)
    {
        ConfiguratorSettings.getInstance().selectPatientNameFormat(PatientFormat);
        System.out.println("The selected value" + PatientFormat);
    }

    @When("user selects <StaffNameFormat> from staff_name_format dropdown")
    public static void selectStaffNameFormat(@Named("StaffNameFormat") String StaffFormat)
    {
        ConfiguratorSettings.selectStaffNameFormat(StaffFormat);
        System.out.println("The selected value" + StaffFormat);
    }

    @When("user selects Remove_trailing_zeros_from_time checkbox")
    public static void selectRemoveStrip()
    {
        ConfiguratorSettings.getInstance().selectRemoveStrip();
    }

    @When("user unselects Remove_trailing_zeros_from_time checkbox")
    public static void unSelectRemoveStrip()
    {
        ConfiguratorSettings.getInstance().unSelectRemoveStrip();
    }

    @When("user selects Similar_name_indication_criteria FirstNamecheckbox <SimilarFirstName>")
    public static void selectSimilarNameIndicationFirstName(@Named("SimilarFirstName") String SimilarName)
            throws Exception
    {
        boolean SelectedCheckbox = ConfiguratorSettings.getInstance().selectSimilarNameIndicationFirstName(SimilarName);
        Assert.assertEquals("user is able to select checkbox=" + SimilarName + " on Similar Name indication", true,
                SelectedCheckbox);

    }

    @When("user selects Similar_name_indication_criteria LastNamecheckbox <SimilarLastName>")
    public static void selectSimilarNameIndicationLastName(@Named("SimilarLastName") String SimilarName)
            throws Exception
    {
        boolean SelectedCheckbox = ConfiguratorSettings.getInstance().selectSimilarNameIndicationLastName(SimilarName);
        Assert.assertEquals("user is able to select checkbox=" + SimilarName + " on Similar Name indication", true,
                SelectedCheckbox);

    }

    @When("user clicks Save button")
    public static void clickOnSave()
            throws Exception

    {
        ConfiguratorSettings.selectSaveButton();

    }

    @Then("verify the save message <message>")
    public void verifySaveMessage(@Named("message") String message)
            throws Exception
    {

        String SaveMessage = ConfiguratorSettings.getInstance().getSavedMessage(message);

        Assert.assertEquals("Verify the error message for invalid date", SaveMessage, message);
    }

    @When("user selects <PacuArrivingTimeEvent> from Time_event_to_show_case_on_PACU_bed dropdown")
    public static void selectPacuArrivingTimeEvent(@Named("PacuArrivingTimeEvent") String pacuArrivingTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectPacuArrivingTimeEvent(pacuArrivingTimeEvent);
        System.out.println("The selected value" + pacuArrivingTimeEvent);
    }

    @When("user selects <PacuAdmissionTimeEvent> from Time_indicating_admission_to_PACU_department dropdown")
    public static void selectPacuAdmissionTimeEvent(@Named("PacuAdmissionTimeEvent") String pacuAdmissionTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectPacuAdmissionTimeEvent(pacuAdmissionTimeEvent);
        System.out.println("The selected value" + pacuAdmissionTimeEvent);
    }

    @When("user selects <PacuReadyDischargeTimeEvent> from Time_indicating_readiness_of_discharge_from_PACU_department dropdown")
    public static void selectPacuReadyDischargeTimeEvent(
            @Named("PacuReadyDischargeTimeEvent") String pacuReadyDischargeTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectPacuReadyDischargeTimeEvent(pacuReadyDischargeTimeEvent);
        System.out.println("The selected value" + pacuReadyDischargeTimeEvent);
    }

    @When("user selects <PacuDischargeTimeEvent> from Time_indicating_discharge_from_PACU_department dropdown")
    public static void selectPacuDischargeTimeEvent(@Named("PacuDischargeTimeEvent") String pacuDischargeTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectPacuDischargeTimeEvent(pacuDischargeTimeEvent);
        System.out.println("The selected value" + pacuDischargeTimeEvent);
    }

    @When("user selects <ICUAdmissionTimeEvent> from Time_indicating_admission_to_ICU department dropdown")
    public static void selectICUAdmissionTimeEvent(@Named("ICUAdmissionTimeEvent") String iCUAdmissionTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectICUAdmissionTimeEvent(iCUAdmissionTimeEvent);
        System.out.println("The selected value" + iCUAdmissionTimeEvent);
    }

    @When("user selects <ICUReadyDischargeTimeEvent> from Time_indicating_readiness_of_discharge_from_ICU department dropdown")
    public static void selectICUReadyDischargeTimeEvent(
            @Named("ICUReadyDischargeTimeEvent") String iCUReadyDischargeTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectICUReadyDischargeTimeEvent(iCUReadyDischargeTimeEvent);
        System.out.println("The selected value" + iCUReadyDischargeTimeEvent);
    }

    @When("user selects <ICUDischargeTimeEvent> from Time_indicating_discharge_from_ICU_department dropdown")
    public static void selectICUDischargeTimeEvent(@Named("ICUDischargeTimeEvent") String iCUDischargeTimeEvent)
    {
        ConfiguratorSettings.getInstance().selectICUDischargeTimeEvent(iCUDischargeTimeEvent);
        System.out.println("The selected value" + iCUDischargeTimeEvent);
    }

    @When("user selects Show_birth_name_of_patient checkbox")
    public static void SelectBirthName()
    {
        ConfiguratorSettings.getInstance().SelectBirthName();
    }

    @When("user unselect Show_birth_name_of_patient checkbox")
    public static void unSelectBirthName()
    {
        ConfiguratorSettings.getInstance().unSelectBirthName();
    }

}
