package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.Site;

public class DateLabelSteps
{
    @Then("From date displays current date")
    public void verifyFromDateCurrent()
            throws Exception
    {
        Thread.sleep(3000);
        String actFromdate = PatientList.getInstance().getFromDate();
        Assert.assertEquals("Verify From date should display current date", PatientList.getInstance()
                .getCurrentPastFutureDate("now"), actFromdate);

    }

    @Then("To date displays current date")
    public void verifyToDateCurrent()
            throws Exception
    {
        String actTodate = PatientList.getInstance().getToDate();
        Assert.assertEquals("Verify To date should display current date", PatientList.getInstance()
                .getCurrentPastFutureDate("now"), actTodate);

    }

    @Then("the current date label displays the current date")
    @Alias("the current date label displays the <current date>")
    public void verifyLableCurrent()
            throws Exception
    {
        String actCurrentDateLabel = PatientList.getInstance().getCurrentDateLable();
        String expCurrentDate = "Current Date" + "\n" + PatientList.getInstance().getCurrentPastFutureDate("now");
        Assert.assertEquals("Verify Current date lable should display current Date", expCurrentDate,
                actCurrentDateLabel.trim());
    }

    @Then("the search button will be disabled")
    public void verifySearchButtonDisable()
            throws InterruptedException, IOException
    {
        Assert.assertEquals("Search button should be disabled", "true", Site.getInstance().verifySerchButtonEnabled());
    }

    @Then("verify that the calendar should not open after clicking on date labels")
    public void verifyCalendarNotOpen()
            throws InterruptedException, IOException
    {
        Site.getInstance().ClickOnDateLabel("fromLabel");
        Assert.assertEquals("Calendar should not open after clicking on From date label", false, Site.getInstance()
                .verifyCalendarOpen());
        Site.getInstance().ClickOnDateLabel("toDateLabel");
        Assert.assertEquals("Calendar should not open after clicking on To date label", false, Site.getInstance()
                .verifyCalendarOpen());

    }

    @When("user enter <invalid> month in date range")
    public void enterInvalidMonth(@Named("invalid month") String invalidMonth)
            throws IOException, InterruptedException
    {
        // DateLabel.DATELABEL.enterMonthInFromDate(invalidMonth);
        PatientList.getInstance().changeAndSetDateInFrom("month", invalidMonth);
    }

    @When("the user sets current date in date range")
    public void setCurrentInFrom()
            throws Exception
    {
        PatientList.getInstance().clickTodayLink();
    }

    @When("user enter <invalid> year in date range")
    public void enterInvalidYear(@Named("invalid year") String invalidYear)
            throws IOException, InterruptedException
    {
        PatientList.getInstance().changeAndSetDateInFrom("year", invalidYear);
        // DateLabel.DATELABEL.enterYearInFromDate(invalidYear);
    }

    @When("user enter <invalid> day in date range")
    public void enterInvalidDate(@Named("invalid day") String invalidDay)
            throws IOException, InterruptedException
    {
        PatientList.getInstance().changeAndSetDateInFrom("day", invalidDay);
    }

}
