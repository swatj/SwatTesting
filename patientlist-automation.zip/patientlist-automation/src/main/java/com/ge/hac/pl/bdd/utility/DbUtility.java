/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * @author 305014106
 *
 */
public class DbUtility
{
    private static Logger logger = Logger.getLogger(DbUtility.class);

    public static Connection getConnection(String driverClass, String driverUrl)
    {
        Connection conn = null;
        if ( CommonUtility.isStringEmptyOrNull(driverClass) || CommonUtility.isStringEmptyOrNull(driverUrl) )
        {
            return null;
        }

        try
        {
            Class.forName(driverClass);
            conn = DriverManager.getConnection(driverUrl);
        }
        catch (ClassNotFoundException | SQLException e)
        {
            logger.error(e);
        }

        return conn;
    }

}
