/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.Constants;

public class SiteSteps
{

    @When("the user clicks on the site dropdown")
    public void clickOnAddSite()
            throws IOException, InterruptedException
    {
        Site.getInstance().clickAddSite();
    }

    @Then("the site drop down displays the sites that the logged in user has access to:$datatable")
    public void verifyListInAddSite(ExamplesTable datatable)
            throws Exception
    {
        boolean bStatus = false;
        CommonUtility.validateExampleTable(datatable, null);
        List<String> expectedSiteList = new ArrayList<String>();

        for (Map<String, String> row : datatable.getRows())
        {
            expectedSiteList.add(row.get("Sites"));
        }

        bStatus = Site.getInstance().verifySiteList(expectedSiteList);
        Assert.assertEquals("Verify sites that the logged in user has access to.", true, bStatus);
        Site.getInstance().clickAddSite();
    }

    @Then("Patient List should display the first $activesite site from the site dropdown by default on first login")
    @Alias("site drop down displays <activesite> viewed on previous login")
    public void verifyDefaultSiteDepartment(@Named("activesite") String activeSite)
            throws IOException, InterruptedException
    {
        boolean actActiveSite = Site.getInstance().verifyActiveSite(activeSite);
        Assert.assertEquals("Verify active site on site dropdown : " + activeSite, true, actActiveSite);
    }

    @Then("the selected <site> is: $dataTable")
    public void verifySelectedSite(ExamplesTable dataTable)
            throws Exception
    {
        String siteName = null;
        CommonUtility.validateExampleTable(dataTable, 1);

        for (Map<String, String> row : dataTable.getRows())
        {
            siteName = row.get("site");
        }
        boolean actActiveSite = Site.getInstance().verifyActiveSite(siteName);
        Assert.assertEquals("Verify active site on site dropdown : " + siteName, true, actActiveSite);

    }

    @Then("the departments of the site are rendered:$datatable")
    public void verifyDeptList(ExamplesTable datatable)
            throws Exception
    {
        boolean bStatus = false;

        CommonUtility.validateExampleTable(datatable, null);

        List<String> expectedDeptList = new ArrayList<String>();
        for (Map<String, String> row : datatable.getRows())
        {
            expectedDeptList.add(row.get("departments"));
        }

        bStatus = Site.getInstance().verifyDeptList(expectedDeptList);
        Assert.assertEquals("Verify all departments are displayed for a site.", bStatus, true);

    }

    @Then("the departments of the site are displayed:$datatable")
    public void verifyDepartmentsRendered(ExamplesTable datatable)
            throws Exception
    {
        String Deptname = null;
        boolean bStatus = false;

        List<Map<String, String>> dtRows = datatable.getRows();

        for (Map<String, String> row : dtRows)
        {
            bStatus = false;
            Deptname = row.get("departments");
            bStatus = Site.getInstance().verifyDepartment(Deptname);
            Assert.assertEquals("Verify departments displayed for a site:" + Deptname, true, bStatus);
        }
    }

    public void verifyActiveSite(@Named("ActiveSite") String site)
            throws IOException, InterruptedException
    {
        boolean bStatus = false;

        bStatus = Site.getInstance().verifyActiveSiteOnSitesTab(site);
        Assert.assertEquals("Verify active site on site tab = " + site, true, bStatus);

    }

    @Then("the All tab is chosen by default")
    public void verifyDefaultDepartment()
            throws IOException, InterruptedException
    {
        boolean bStatus = false;
        String activeDeptname = Constants.ALL_TAB_NAME;

        bStatus = Site.getInstance().verifyActiveDepartment(activeDeptname);
        Assert.assertEquals("Verify Department on department tab = " + activeDeptname, true, bStatus);

    }

    @Then("Add Site dropdown should get enabled if there at least one site exist in dropdown")
    public void verifyAddSiteDropdownEnabled()
            throws Exception
    {

        boolean bStatus = false;

        bStatus = Site.getInstance().verifyAddSiteDropdownEnabled();

        Assert.assertEquals("Add Site dropdown  is enabled ", true, bStatus);
    }

    @Then("the user gets a login error <message>")
    public void verifyLoginMessage(@Named("message") String message)
            throws Exception
    {
        String errorMsg = PatientList.getInstance().getLoginErrorMessage(message);
        Assert.assertEquals("Verify the error message for invalid users or those who do not have access", errorMsg,
                message);

    }

    @Then("the user gets an application <message>")
    public void verifyApplicationMessage(@Named("message") String message)
            throws Exception
    {

        String errorMsg = PatientList.getInstance().getLoginErrorMessage(message);

        Assert.assertEquals("Verify the error message for users who do not have access to the application", errorMsg,
                message);
    }

    @Then("the user gets an error <message>")
    public void verifyErrorMessage(@Named("message") String message)
            throws Exception
    {

        String errorMsg = PatientList.getInstance().getErrorMessage(message);

        Assert.assertEquals("Verify the error message for users who do not have access to any department", errorMsg,
                message);
    }

    @Then("the user gets an alert error <message>")
    public void verifyAlertMessage(@Named("message") String message)
            throws Exception
    {

        String errorMsg = PatientList.getInstance().getBigDateRangeAlert(message);

        Assert.assertEquals("Verify the error message when data range search is outside the default value", errorMsg,
                message);
    }

    @Then("the user gets a date validation error <message>")
    public void verifyDateErrorMessage(@Named("message") String message)
            throws Exception
    {

        String errorMsg = PatientList.getInstance().getDateErrorMessage(message);

        Assert.assertEquals("Verify the error message for invalid date", message, errorMsg);
    }

    @Then("the site drop down displays the sites in alphabetical order")
    public void verifSiteAlphabeticalOrder()
            throws IOException, InterruptedException
    {
        Site.getInstance().clickAddSite();
        List<String> actualSiteList = Site.getInstance().getAllSites();// get site list from the drop down
        Site.getInstance().clickAddSite(); // close the site drop down

        boolean bReturn = CommonUtility.isListAlphabeticallySorted(actualSiteList);
        Assert.assertTrue("Verify site list is sorted alphabetically", bReturn);
    }

    @Then("the selected $highlighted is highlighted")
    public void verifySelectedSiteInDropDown(@Named("highlighted") String SelectedSiteInDropDown)
            throws IOException, InterruptedException
    {

        Assert.assertEquals("Verify selected site is highlighted in dropdown", SelectedSiteInDropDown,
                Site.getInstance().getSelectedSiteInDropDown());
    }

    @Then("Patient List should select the first site from the site dropdown by default on first login:$datatable")
    public void verifyDefaultSite(ExamplesTable datatable)
            throws Exception
    {

        List<Map<String, String>> dtRows = datatable.getRows();
        Map<String, String> row1 = dtRows.get(0);
        String exptActiveSite = row1.get("ActiveSite");

        boolean actActiveSite = Site.getInstance().verifyActiveSite(exptActiveSite);
        Assert.assertEquals("Verify default site on first time login=" + exptActiveSite, true, actActiveSite);

    }

    @Then("toggle view button should not display on site/department navigation panel")
    public void verifyThatToggleViewButtonIsNotDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that toggle view button was not displayed  on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("ToggleView"));
    }

    @Then("toggle view button should display on site/department navigation panel with PatientList view icon")
    public void verifyThatToggleViewButtonIsDisplayedWithPatientListIcon()
            throws IOException
    {
        Assert.assertEquals("Verify that toggle view button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("ToggleView"));
        Assert.assertEquals(
                "Verify that toggle view button was displayed  on site/department navigation panel with PatientList view icon",
                Constants.PATIENTLIST_VIEW_ICON, Site.getInstance().geToggleViewButtonIconName());
    }

    @Then("toggle view button should display on site/department navigation panel with Resource view icon")
    public void verifyThatToggleViewButtonIsDisplayedWithResourceViewIcon()
            throws IOException
    {
        Assert.assertEquals("Verify that toggle view button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("ToggleView"));
        Assert.assertEquals(
                "Verify that toggle view button was displayed on site/department navigation panel with Resource view icon",
                Constants.RESOURCE_VIEW_ICON, Site.getInstance().geToggleViewButtonIconName());
    }

    @Then("From,To date controls,Go,column pool,default sort and resize buttons should display on site/department navigation panel")
    public void verifyThatPLButtonsDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that From date control was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("fromDateTextbox"));
        Assert.assertEquals("Verify that To date control was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("toDateTextbox"));
        Assert.assertEquals("Verify that Go button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("search_button"));
        Assert.assertEquals("Verify that column pool button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("togglebutton"));
        Assert.assertEquals("Verify that column reorder button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("reorderbutton"));
        // Assert.assertEquals("Verify that default sort button was displayed on site/department navigation panel", true,
        // Site.getInstance().isButtonDisplayed("resetDefaultSort"));
    }

    @Then("From,To date controls,Go,toggle view,column pool,default sort and resize buttons should not display on site/department navigation panel")
    public void verifyThatPLButtonsNotDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that From date control was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("fromDateTextbox"));
        Assert.assertEquals("Verify that To date control was not displayed on site/department navigation panel", false,
                Site.getInstance().isButtonDisplayed("toDateTextbox"));
        Assert.assertEquals("Verify that Go button was not displayed on site/department navigation panel", false,
                Site.getInstance().isButtonDisplayed("search_button"));
        Assert.assertEquals("Verify that toggle view button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("reorderbutton"));
        Assert.assertEquals("Verify that column pool button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("togglebutton"));
        Assert.assertEquals("Verify that column reorder button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("reorderbutton"));
        Assert.assertEquals("Verify that default sort button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("resetDefaultSort"));
    }

    @Then("From,To date controls,Go,column pool,default sort and resize buttons should not display on site/department navigation panel")
    public void verifyThatPLButtonsIsNotDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that From date control was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("fromDateTextbox"));
        Assert.assertEquals("Verify that To date control was not displayed on site/department navigation panel", false,
                Site.getInstance().isButtonDisplayed("toDateTextbox"));
        Assert.assertEquals("Verify that Go button was not displayed on site/department navigation panel", false,
                Site.getInstance().isButtonDisplayed("search_button"));
        Assert.assertEquals("Verify that column pool button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("togglebutton"));
        Assert.assertEquals("Verify that column reorder button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("reorderbutton"));
        Assert.assertEquals("Verify that default sort button was not displayed on site/department navigation panel",
                false, Site.getInstance().isButtonDisplayed("resetDefaultSort"));
    }

    @Then("From,To date controls,Go,toggle view,column pool,default sort and resize buttons should display on site/department navigation panel")
    public void verifyThatPLDefaultButtonsDisplayed()
            throws IOException
    {
        Assert.assertEquals("Verify that From date control was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("fromDateTextbox"));
        Assert.assertEquals("Verify that To date control was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("toDateTextbox"));
        Assert.assertEquals("Verify that Go button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("search_button"));
        Assert.assertEquals("Verify that toggle view button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("ToggleView"));
        Assert.assertEquals("Verify that column pool button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("togglebutton"));
        Assert.assertEquals("Verify that column reorder button was displayed on site/department navigation panel", true,
                Site.getInstance().isButtonDisplayed("reorderbutton"));
        // Assert.assertEquals("Verify that default sort button was displayed on site/department navigation panel", true,
        // Site.getInstance().isButtonDisplayed("resetDefaultSort"));
    }
}
