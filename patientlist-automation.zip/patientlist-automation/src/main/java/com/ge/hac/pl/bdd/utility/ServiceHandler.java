/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.ws.rs.core.Response;

import org.jbehave.core.model.ExamplesTable;

import com.ge.hac.ca.bdd.common.CAHelper;

/**
 * @author 305014106
 *         Helper class to invoke REST services and return the response
 */
public class ServiceHandler
{

    private ServiceHandler()
    {

    }

    /**
     * Returns the response object after invoking a REST end point
     * 
     * @param requestType REST request method (GET, POST, PUT, DELETE)
     * @param url the REST end point to be invoked. Base starts at /service
     * @param queryParams string representation of query parameters. Key value pair separated by ";"
     * @param postEntity object to be posted as part of the request body
     * @return javax.ws.rs.core.Response
     */

    public static Response invokeAndGetResponse(String requestType, String url, String queryParams, Object postEntity)
    {
        Response response = null;
        Map<String, Object[]> queryParamsMap = null;

        if ( isEmptyString(requestType) || isEmptyString(url) )
        {
            return response;
        }

        /* If query parameters exist, create the parameter map */

        if ( queryParams != null && !isEmptyString(queryParams) )
        {
            queryParamsMap = parseQueryParams(queryParams);
        }

        if ( requestType.equalsIgnoreCase(RequestType.GET.getRequestType()) )
        {
            if ( queryParamsMap != null && queryParamsMap.size() > 0 )
            {
                response = CAHelper.httpGet(url, null, queryParamsMap);
            }
            else
            {
                response = CAHelper.httpGet(url);
            }
        }
        else if ( requestType.equalsIgnoreCase(RequestType.POST.getRequestType()) )
        {
            if ( queryParamsMap != null && queryParamsMap.size() > 0 )
            {
                response = CAHelper.httpPost(url, postEntity, null, queryParamsMap);
            }
            else
            {
                response = CAHelper.httpPost(url, postEntity);
            }
        }
        else if ( requestType.equalsIgnoreCase(RequestType.PUT.getRequestType()) )
        {
            if ( queryParamsMap != null && queryParamsMap.size() > 0 )
            {
                response = CAHelper.httpPut(url, postEntity, null, queryParamsMap);
            }
            else
            {
                response = CAHelper.httpPut(url, postEntity);
            }
        }
        

        return response;
    }

    /**
     * Return the values required to invoke a REST endpoint as supplied in the feature file
     * 
     * @param dataTable table in feature file with values for resolving the REST end point to be called
     * @return com.ge.hac.pl.bdd.utility.RestParams
     */

    public static RestParams extractRestParamsFromTable(ExamplesTable dataTable)
    {
        String requestType = null;
        String queryParams = null;
        String postEntity = null;
        String restEndpoint = null;

        for (Map<String, String> row : dataTable.getRows())
        {
            requestType = row.get("type");
            queryParams = row.get("queryParams");
            postEntity = row.get("postParams");
            restEndpoint = PropertyFileHelper.getProjectProperty(row.get("url"));
        }

        return new RestParams(requestType, queryParams, postEntity, restEndpoint);
    }

    private static Map<String, Object[]> parseQueryParams(String queryParams)
    {
        String[] queryParamsArray = queryParams.split(";");

        Map<String, Object[]> paramMap = new HashMap<String, Object[]>();

        for (int i = 0; i < queryParamsArray.length; i++)
        {
            if ( queryParamsArray[i] != null && !queryParamsArray[i].isEmpty() )
            {
                String[] param = queryParamsArray[i].split("=");
                if ( param != null && param.length == 2 )
                {
                    paramMap.put(param[0], new String[]
                    {
                        Objects.toString(param[1], "")
                    });
                }
            }
        }

        return paramMap;
    }

    private static boolean isEmptyString(String input)
    {
        if ( (input == null) || (input.trim().isEmpty()) )
        {
            return true;
        }
        return false;
    }

}
