package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

public class CurrentViewSteps
{

    @Then("verify PL should not display elapsed duration if the last time event(PACU discharge time) is documented")
    @Alias("Verify PL should not display elapsed duration if WorkflowEndTime flag set to PACU discharge time and PACU discharge time is documented for case")
    public void verifyPatientLOSNotDisplayed(@Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        Filter.getInstance().verifyFilteredData(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            String patientLOS = PatientListData.getInstance().getPatientLOS();
            Assert.assertEquals("Verify elapsed duration=" + patientLOS + " was  not displayed for Patient ID="
                    + patientIDValue, patientLOS.isEmpty(), true);
        }

    }

    @Then("verify PL should display elapsed duration if the last time event(PACU discharge time) is not documented.")
    @Alias("Verify PL should display elapsed duration if WorkflowEndTime flag not set to PACU discharge time and PACU discharge time is documented for case")
    public void verifyPatientLOSDisplayed(@Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.STATUS_LOS_COLUMN);

        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        Filter.getInstance().verifyFilteredData(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            String patientLOS = PatientListData.getInstance().getPatientLOS();

            Assert.assertEquals("Verify elapsed duration=" + patientLOS + " was displayed for Patient ID="
                    + patientIDValue, patientLOS.isEmpty(), false);

        }

    }

}
