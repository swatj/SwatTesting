/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.functions.Sorting;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinathj
 * 
 */
public class FilteringAndSortingSteps
{

    @When("apply <sorttype> sorting on <column> column")
    public void sortColumnData(@Named("sorttype") String sortType, @Named("column") String columnToSort)
            throws Exception
    {
        Filter.getInstance().clearAllFilter();
        boolean bStatus = Sorting.getInstance().sortColumnData(columnToSort, sortType);
        Assert.assertEquals("Verify sorted " + sortType + " order for " + columnToSort + " column", true, bStatus);
    }

    @Then("PatientList should display sorted data")
    public void verifySortedColumnData(@Named("sorttype") String sortType, @Named("column") String columnToSort)
            throws Exception
    {
        Thread.sleep(3000);
        boolean bStatus = Sorting.getInstance().verifySortedColumnData(columnToSort, sortType);
        Assert.assertEquals("Verify sorted " + sortType + " order for " + columnToSort + " column", true, bStatus);
    }

    @Then("Patient List should display data with default ascending sort on schedule time")
    public void verifyDefaultSorting()
            throws Exception
    {
        PatientList.getInstance().addColumnToColumnList(Constants.SCHED_TIME_COLUMN);
        String SortedAppliedColumnName = Sorting.getInstance().getSortedAppliedColumnName();
        Assert.assertEquals("Verify default sorted column name", Constants.SCHED_TIME_COLUMN,
                SortedAppliedColumnName);
        String SortedAppliedColumnOrder = Sorting.getInstance().getSortedAppliedColumnOrder();
        Assert.assertEquals("Verify default sorted order", "sort-up", SortedAppliedColumnOrder);
    }

    @Then("Patient List should display data with default descending sort on schedule time")
    public void verifyesendingSorting()
            throws Exception
    {
        PatientList.getInstance().addColumnToColumnList(Constants.SCHED_TIME_COLUMN);
        String SortedAppliedColumnName = Sorting.getInstance().getSortedAppliedColumnName();
        Assert.assertEquals("Verify default sorted column name", Constants.SCHED_TIME_COLUMN,
                SortedAppliedColumnName);
        String SortedAppliedColumnOrder = Sorting.getInstance().getSortedAppliedColumnOrder();
        Assert.assertEquals("Verify default sorted order", "sort-down", SortedAppliedColumnOrder);
    }

    @Then("After login ,patient list should display data with default sorting on Sched time and OR  in ascending order")
    public void verifDefaultSorting(@Named("sorttype") String sortType, @Named("column") String PrimarySortingColumn,
            @Named("SecondarySortingColumn") String SecondarySortingColumn)
            throws Exception
    {
        Sorting.getInstance().verifySecondaySortedColumnData(PrimarySortingColumn, SecondarySortingColumn, sortType);
    }

    @Then("Reset default sort button will be hidden")
    public void verifyResetSortButtonhidden()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Reset default sort button will be hidden", false, Site.getInstance()
                .verifyResetSortButton());
    }

    @Then("Reset default sort button will be visible")
    public void verifyResetSortButtonvisible()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Reset default sort button will be visible", true, Site.getInstance()
                .verifyResetSortButton());
    }

    @When("the user clicks on reset Default Sort button")
    public void clickResetSortButton()
            throws IOException, InterruptedException
    {
        SeleniumUtility.getInstance().elementClick("resetDefaultSort");
    }
}
