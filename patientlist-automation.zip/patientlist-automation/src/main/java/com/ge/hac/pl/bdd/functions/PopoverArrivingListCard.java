/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

/**
 * @author pandharinathj
 *
 */
public class PopoverArrivingListCard extends Bed
{
    ArrivingListCard      card;
    public PopoverArrivingListCard()
    {
        super();
        initializeBed( "//div[contains(@class,'popover-content')]//*");
    }
    
}

