package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

public class PastViewSteps
{
    //TODO
    @Then("verify the patient's past view data in the Patient list")
    public void verifyPastViewData(@Named("Care phase") String carePhaseValue, @Named("OR") String ORValue,
            @Named("Patient ID") String patientIDValue, @Named("Patient") String patientValue,
            @Named("Sched time") String schedTimeValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        headerNames.add(Constants.OR_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            PatientListData.getInstance().verifyOR(patientIDRowNumber, headerNames, ORValue);
            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
            PatientListData.getInstance().verifyCarePhase(patientIDRowNumber, headerNames, carePhaseValue);
            PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);
        }

    }

    //TODO
    @Then("verify PL should display care phase as completed for past discharged locked case")
    @Alias("verify PL should display care phase as pending for past discharged unlocked case")
    public void verifyCarePhase(@Named("Care phase") String carePhaseValue, @Named("Patient ID") String patientIDValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {

            PatientListData.getInstance().verifyCarePhase(patientIDRowNumber, headerNames, carePhaseValue);

        }

    }

}
