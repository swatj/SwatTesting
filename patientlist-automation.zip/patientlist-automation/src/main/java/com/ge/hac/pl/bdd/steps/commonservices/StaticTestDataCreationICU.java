/* Copyright (c) 2016 GE Healthcare. All rights reserved.
 * The copyright to the computer software herein is the property of GE Healthcare.
 * The software may be used and/or copied only with the written permission of GE Healthcare or in accordance 
 * with the terms and conditions stipulated in the agreement/contract under which the software has been supplied. */
package com.ge.hac.pl.bdd.steps.commonservices;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.text.SimpleDateFormat;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.model.ExamplesTable;

import com.ge.hac.ca.bdd.common.assertj.ClientFixture.ClientState;
import com.ge.hac.ca.bdd.common.assertj.ClientFixture.ClientType;
import com.ge.hac.ca.bdd.common.assertj.ClientHandler;
import com.ge.hac.ca.bdd.common.assertj.ClinicalClientFixture;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class StaticTestDataCreationICU
{
    ClinicalClientFixture client;
    String                tomorrowformattedString;
    String                todayFormattedString;
    String                yesterdayFormattedstring;
    String                pastFormattedstring;

    @Given("user will log into the CA ICUApp")
    public void givenUserLogsIntoTheCAIntraOpThickClient()
            throws Exception
    {
        // For closing browser
        PatientList.getInstance().closePatientListBrowser();
        PatientList.closeInstance();
        SeleniumUtility.closeInstance();

        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        ClientHandler.initialize();
        client = (ClinicalClientFixture) ClientHandler.startNewClientAndSetActive(ClientType.icu,
                ClientType.icu.name() + "1", ClientState.loginDialog);

        // Login
        client.loginDialog.waitUntilEnabled(50 * 1000);
        if ( client.loginDialog.isEnabled() )
        {
            client.loginDialog.username.waitUntilEnabled(20 * 1000);
            client.loginDialog.username.setText("Administrator");
            client.loginDialog.password.waitUntilEnabled(20 * 1000);
            client.loginDialog.password.setText("healthcare");

            client.loginDialog.department.selectItem(0);
            try
            {
                client.loginDialog.department.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.department.selectItem(0);
            }

            client.loginDialog.location.selectItem(0);
            try
            {
                client.loginDialog.location.requireSelection(0);

            }
            catch (AssertionError e)
            {
                client.loginDialog.location.selectItem(0);
            }
            client.loginDialog.loginButton.click();
        }
        client.waitUntilShowing(720 * 1000);
        Date today = new Date();
        todayFormattedString = convertDateToFormattedString(today);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date tommrrow = cal.getTime();
        tomorrowformattedString = convertDateToFormattedString(tommrrow);
        cal.add(Calendar.DAY_OF_MONTH, -2);
        Date yesterday = cal.getTime();
        yesterdayFormattedstring = convertDateToFormattedString(yesterday);
        cal.add(Calendar.DAY_OF_MONTH, -3);
        Date past = cal.getTime();
        pastFormattedstring = convertDateToFormattedString(past);
    }

    @Given("user will navigate to the patients and cases display tab in ICUApp")
    public void givenUserNavigatesToThePatientsAndCasesDisplayTab()
    {

        client.selectionMenu.patientlistICUButton.click();
        client.tabbedDisplayFrame.selectPatientsAndCasesTab();
    }

    @Given("user enters case details for the patients in ICUApp:$caseTable")
    public void givenUserEntersPatientDetails(ExamplesTable caseTable)
            throws InterruptedException
    {

        for (Map<String, String> row : caseTable.getRows())
        {
            String patientid = row.get("patientid");
            String icuAdmissionDateField = row.get("icuAdmissionDateField");
            String birthdateField = row.get("birthdateField");
            String department = row.get("department");
            String room = row.get("room");
            String bed = row.get("bed");

            if ( icuAdmissionDateField.equalsIgnoreCase("Today") )
            {
                icuAdmissionDateField = todayFormattedString;
            }
            else if ( icuAdmissionDateField.equalsIgnoreCase("Yesterday") )
            {
                icuAdmissionDateField = yesterdayFormattedstring;
            }
            else if ( icuAdmissionDateField.equalsIgnoreCase("Tomorrow") )
            {
                icuAdmissionDateField = tomorrowformattedString;
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }

            // new case with same visit id
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseToVisitBtn.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.items.addCaseToSelectedVisitButton.click();

            // Create a new case
            client.tabbedDisplayFrame.newCaseICU.icuAdmissionDate.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.newCaseICU.icuAdmissionDate.setText(icuAdmissionDateField);
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            client.tabbedDisplayFrame.newCaseICU.privateNA.click();
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( !birthdateField.equalsIgnoreCase("") && !birthdateField.equalsIgnoreCase(" ")
                    && !birthdateField.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.newCaseICU.birthdate.setText(birthdateField);
            }
            if ( !department.equalsIgnoreCase("") && !department.equalsIgnoreCase(" ")
                    && !department.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.newCaseICU.department.selectItem(Integer.parseInt(department));
                try
                {
                    client.tabbedDisplayFrame.newCaseICU.department.requireSelection(Integer.parseInt(department));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.newCaseICU.department.selectItem(Integer.parseInt(department));
                }

            }
            if ( !room.equalsIgnoreCase("") && !room.equalsIgnoreCase(" ") && !room.equalsIgnoreCase(null) )
            {
                client.tabbedDisplayFrame.newCaseICU.room.waitUntilShowing();
                client.tabbedDisplayFrame.newCaseICU.room.waitUntilEnabled();
                client.tabbedDisplayFrame.newCaseICU.click();
                client.tabbedDisplayFrame.newCaseICU.room.selectItem(Integer.parseInt(room));
                try
                {
                    client.tabbedDisplayFrame.newCaseICU.room.requireSelection(Integer.parseInt(room));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.newCaseICU.room.selectItem(Integer.parseInt(room));
                }

            }
            if ( !bed.equalsIgnoreCase("") && !bed.equalsIgnoreCase(" ") && !bed.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.newCaseICU.bed.waitUntilShowing();
                client.tabbedDisplayFrame.newCaseICU.bed.waitUntilEnabled();
                client.tabbedDisplayFrame.newCaseICU.click();
                client.tabbedDisplayFrame.newCaseICU.bed.selectItem(Integer.parseInt(bed));
                try
                {
                    client.tabbedDisplayFrame.newCaseICU.bed.requireSelection(Integer.parseInt(bed));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.newCaseICU.bed.selectItem(Integer.parseInt(bed));
                }

            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
            }

            client.tabbedDisplayFrame.newCaseICU.buttonRow.saveAndBackButton.click();
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
                client.tabbedDisplayFrame.caseInfoICU.buttonRow.approveAndClose();
            }
        }
    }

    @Given("user changes case details for the patients in ICUApp:$caseInfoTable")
    public void givenUserEditsPatientDetails(ExamplesTable caseInfoTable)
            throws InterruptedException
    {
        for (Map<String, String> row : caseInfoTable.getRows())
        {
            String patientid = row.get("patientid");
            String readyForDischarge = row.get("readyForDischarge");
            String isolationPrecautions = row.get("isolationPrecautions");
            String reasonForAdmission = row.get("reasonForAdmission");
            if ( readyForDischarge != null && readyForDischarge.equalsIgnoreCase("Today") )
            {
                readyForDischarge = todayFormattedString;
            }
            else if ( readyForDischarge != null && readyForDischarge.equalsIgnoreCase("Yesterday") )
            {
                readyForDischarge = yesterdayFormattedstring;
            }
            else if ( readyForDischarge != null && readyForDischarge.equalsIgnoreCase("Tomorrow") )
            {
                readyForDischarge = tomorrowformattedString;
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            if ( !client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.isEnabled() )
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(1);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.click();
            client.tabbedDisplayFrame.caseInfoICU.reasonForAdmission.setText(reasonForAdmission);
            client.tabbedDisplayFrame.caseInfoICU.privateNo.click();

            if ( !readyForDischarge.equalsIgnoreCase("") && !readyForDischarge.equalsIgnoreCase(" ")
                    && !readyForDischarge.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.caseInfoICU.readyForDischarge.setText(readyForDischarge);

            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            if ( !isolationPrecautions.equalsIgnoreCase("") && !isolationPrecautions.equalsIgnoreCase(" ")
                    && !isolationPrecautions.equalsIgnoreCase(null) )
            {

                client.tabbedDisplayFrame.caseInfoICU.isolationPrecautions
                        .selectItem(Integer.parseInt(isolationPrecautions));
                try
                {
                    client.tabbedDisplayFrame.caseInfoICU.isolationPrecautions
                            .requireSelection(Integer.parseInt(isolationPrecautions));

                }
                catch (AssertionError e)
                {
                    client.tabbedDisplayFrame.caseInfoICU.isolationPrecautions
                            .selectItem(Integer.parseInt(isolationPrecautions));
                }
            }
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
            }
            client.tabbedDisplayFrame.caseInfoICU.buttonRow.approveAndClose();
            if ( client.messageBox.isShowing() )
            {
                client.messageBox.OkButton.click();
                client.tabbedDisplayFrame.caseInfoICU.buttonRow.approveAndClose();
            }

        }

    }

    @Given("user fills personnel ,infection and acuity details for cases:$caseRolesTable")
    public void givenUserEditscaseRolesTable(ExamplesTable caseRolesTable)
            throws InterruptedException
    {
        for (Map<String, String> row : caseRolesTable.getRows())
        {
            String patientid = row.get("patientid");
            String intensivists = row.get("intensivists");
            String nurse = row.get("nurse");
            String infection = row.get("infection");
            String acuity = row.get("acuity");
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.click();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilShowing();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.waitUntilEnabled();
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            try
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.requireSelection(2);

            }
            catch (AssertionError e)
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchBy.selectItem(2);
            }

            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchField.setText(patientid);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.searchPanel.searchButton.click();
            int len = client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.rowCount();
            for (int i = 0; i < len; i++)
            {
                if ( client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.valueAt(i, 3).trim()
                        .equalsIgnoreCase(patientid) )
                {
                    client.tabbedDisplayFrame.patientsAndCasesDisplay.patientsTable.selectRows(i);
                    break;
                }
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.patientInfoButton.waitUntilEnabled(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(0);
            if ( !client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.isEnabled() )
            {
                client.tabbedDisplayFrame.patientsAndCasesDisplay.casesTable.selectRows(1);
            }
            client.tabbedDisplayFrame.patientsAndCasesDisplay.caseInfoButton.waitUntilShowing(180 * 1000);
            client.tabbedDisplayFrame.patientsAndCasesDisplay.openRecordButton.click();
            if ( client.caseStartDialog.isShowing() )
            {
                client.caseStartDialog.start(false);
            }

            if ( client.messageBox.isShowing() )
            {
                if ( client.messageBox.OkButton.isShowing() )
                {
                    client.messageBox.OkButton.click();
                }
                if ( client.messageBox.yesButton.isShowing() )
                {
                    client.messageBox.yesButton.click();
                }
            }
            client.selectionMenu.careStayButton.waitUntilEnabled(180 * 1000);
            client.selectionMenu.careStayButton.click();
            client.selectionMenu.items.personnelItemMenuItem.click();
            if ( !intensivists.equalsIgnoreCase("") && !intensivists.equalsIgnoreCase(" ")
                    && !intensivists.equalsIgnoreCase(null) )
            {
                String[] roleList = intensivists.split(",");

                for (String val : roleList)
                {
                    client.tabbedDisplayFrame.personnel.newButton.click();
                    client.tabbedDisplayFrame.personnel.roleICU.selectItem(1);
                    try
                    {
                        client.tabbedDisplayFrame.personnel.roleICU.requireSelection(1);

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.roleICU.selectItem(1);
                    }
                    client.tabbedDisplayFrame.personnel.nameICU.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.personnel.nameICU.requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.nameICU.selectItem(Integer.parseInt(val));
                    }
                    client.tabbedDisplayFrame.personnel.startDateField.setText(todayFormattedString);
                    if ( client.messageBox.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                    }
                    if ( client.tabbedDisplayFrame.personnel.addButton.isShowing() )
                    {
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }
                    if ( client.messageBox.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }
                    if ( client.tabbedDisplayFrame.personnel.addButton.isShowing() )
                    {
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }

                }

            }
            if ( !nurse.equalsIgnoreCase("") && !nurse.equalsIgnoreCase(" ") && !nurse.equalsIgnoreCase(null) )
            {
                String[] roleList = nurse.split(",");

                for (String val : roleList)
                {
                    client.tabbedDisplayFrame.personnel.newButton.click();
                    client.tabbedDisplayFrame.personnel.roleICU.selectItem(0);
                    try
                    {
                        client.tabbedDisplayFrame.personnel.roleICU.requireSelection(0);

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.roleICU.selectItem(0);
                    }
                    client.tabbedDisplayFrame.personnel.nameICU.selectItem(Integer.parseInt(val));
                    try
                    {
                        client.tabbedDisplayFrame.personnel.nameICU.requireSelection(Integer.parseInt(val));

                    }
                    catch (AssertionError e)
                    {
                        client.tabbedDisplayFrame.personnel.nameICU.selectItem(Integer.parseInt(val));
                    }
                    client.tabbedDisplayFrame.personnel.startDateField.setText(todayFormattedString);
                    if ( client.messageBox.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                    }
                    if ( client.tabbedDisplayFrame.personnel.addButton.isShowing() )
                    {
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }
                    if ( client.messageBox.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }
                    if ( client.tabbedDisplayFrame.personnel.addButton.isShowing() )
                    {
                        client.tabbedDisplayFrame.personnel.addButton.click();
                    }

                }
            }
            client.tabbedDisplayFrame.personnel.buttonRow.approveAndClose();
            // infection

            if ( infection.equalsIgnoreCase("yes") )
            {
                client.headerLeft.moreLink.click();
                client.tabbedDisplayFrame.selectTab("Allergies - History - Infections");
                client.tabbedDisplayFrame.allergyHistoryICU.msra.click();
                client.tabbedDisplayFrame.allergyHistoryICU.buttonRow.approveAndClose();
                if ( client.messageBox.isShowing() )
                {
                    if ( client.messageBox.OkButton.isShowing() )
                    {
                        client.messageBox.OkButton.click();
                    }
                    if ( client.messageBox.yesButton.isShowing() )
                    {
                        client.messageBox.yesButton.click();
                    }
                }
            }

            // Acuity
            if ( !acuity.equalsIgnoreCase("") && !acuity.equalsIgnoreCase(" ") && !acuity.equalsIgnoreCase(null) )
            {
                client.selectionMenu.careStayButton.waitUntilEnabled(180 * 1000);
                client.selectionMenu.careStayButton.click();
                client.selectionMenu.items.admissionButton.click();
                client.workList.waitUntilEnabled(180 * 1000);
                client.workList.admissionPlanElement.click();
                client.tabbedDisplayFrame.selectTab("Acuity (manual)");
                client.tabbedDisplayFrame.displayAcuity.acuityField.setText(acuity).click();
                client.tabbedDisplayFrame.displayAcuity.buttonRow.approveAndClose();
            }
            client.selectionMenu.patientlistICUButton.waitUntilShowing(180 * 1000);
            client.selectionMenu.patientlistICUButton.click();
            client.tabbedDisplayFrame.selectPatientsAndCasesTab();
        }

    }

    @Then("Quit the ICU client")
    public void QuitClient()
    {
        ClientHandler.teardown();

    }

    public static String convertDateToFormattedString(Date day)
    {
        SimpleDateFormat formatter = new SimpleDateFormat(PropertyFileHelper.getProjectProperty("DATE_FORMAT"));
        String date = formatter.format(day);
        return date;
    }

}
