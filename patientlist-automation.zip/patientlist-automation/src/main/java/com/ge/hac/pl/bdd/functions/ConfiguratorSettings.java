/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.UnreachableBrowserException;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author 305019267
 * 
 */
public class ConfiguratorSettings
{
    private static Logger               logger   = Logger.getLogger(ConfiguratorSettings.class);
    private SeleniumUtility             selUtility;
    private static ConfiguratorSettings instance = null;

    public static ConfiguratorSettings getInstance()
    {
        if ( instance == null )
        {
            instance = new ConfiguratorSettings();
        }
        return instance;
    }

    private ConfiguratorSettings()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("ConfiguratorSettings() - error initializing web browser.", e);
        }

    }

    public static void openConfiguratorApplication()

    {

        try
        {
            SeleniumUtility.getInstance().navigateTo("ConfiguratorUrl");
            PatientList.getInstance().enterCredentials(Constants.CONFIGURATOR_USER, Constants.CONFIGURATOR_USER_PWD);
            PatientList.getInstance().clickOnlogin();
            logger.debug("ConfiguratorSettings:openConfiguratorApplication: opening the Configurator Application");
        }
        catch (IOException | InterruptedException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.openConfiguratorApplication",
                    e);
        }

    }

    public static void selectTab(String tabName)
            throws IOException
    {
        switch (tabName)
        {
            case Constants.CONFIGURATOR_FIRST_TAB_NAME:
                SeleniumUtility.getInstance().getElementByXPath("first_tab").click();
                break;
            case Constants.CONFIGURATOR_SECOND_TAB_NAME:

                SeleniumUtility.getInstance().getElementByXPath("second_tab").click();
                break;
            default:

                break;
        }

    }

    public static boolean isLinkDisplay()
    {
        try
        {

            return SeleniumUtility.getInstance().elementDisplayedByXpath("first_tab");

        }

        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.isLinkDisplay", e);
            return false;
        }
    }

    public static boolean isDefaultDisplay()
    {
        try
        {

            return SeleniumUtility.getInstance().elementDisplayedByXpath("Summary");

        }

        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.isDefaultDisplay", e);
            return false;
        }
    }

    public static boolean isConfigurationDisplay()
    {
        try
        {

            return SeleniumUtility.getInstance().elementDisplayedByXpath("Configuration");

        }

        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.isConfigurationDisplay", e);
            return false;
        }
    }

    public static boolean isGeneralDisplay()
    {
        try
        {

            return SeleniumUtility.getInstance().elementDisplayedByXpath("General");

        }

        catch (IOException e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.isGeneralDisplay", e);
            return false;
        }
    }

    public static void selectLink(String linkName)
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Summary").click();
    }

    public static void selectConfigurationLink(String linkName)
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Configuration").click();

    }

    // public void verifyCommonConfigurationPropertyName(ExamplesTable dataTable)
    // throws IOException, UnreachableBrowserException, WebDriverException, InterruptedException
    // {
    // // boolean replaceNamedParameters = true;
    // // String Values = dataTable.getRowAsParameters(0, replaceNamedParameters).valueAs("Values", String.class);
    // // expect 3000
    // List<WebElement> allRows = SeleniumUtility.getInstance().findElements("allRowsCommonSystemPropertiesTable");
    // System.out.println("The number of rows" + allRows.size());
    // // List<WebElement> cellData = selUtility.findElements("allRows");
    // for (WebElement rowElement : allRows)
    // {
    // // String rowNo = rowElement.getText().trim();
    // String PropertyNumber = "";
    // for (Map<String, String> row : dataTable.getRows())
    // {
    // PropertyNumber = row.get("PropertRowNumber");
    // List<WebElement> cellData = selUtility.findElements(
    // WebElement propertyColumn = rowElement
    // .findElement(By.xpath("//td["Key"]);
    // // String a = propertyValueColumn.getText().trim();
    // System.out.println("Test value Property name" + propertyColumn.getText().trim());
    // Assert.assertEquals("Verify in property Name", row.get("Property"), propertyColumn.getText().trim());
    // WebElement propertyValueColumn = rowElement
    // .findElement(By.xpath("//*[@id='systemConfigSummaryView']/form/fieldset[1]/table//tbody//tr["
    // + PropertyNumber + "]//td[2]"));
    // // WebElement propertyDescriptionColumn = rowElement.findElement(By.xpath(
    // // "//*[@id='systemConfigSummaryView']/form/fieldset[1]/table//tbody//tr[" + i + "]//td[3]"));
    // // String a = propertyValueColumn.getText().trim();
    // // System.out.println("Test value column" + propertyColumn.getText().trim());
    // // Assert.assertEquals("Verify in property Name", row.get("Property"), propertyColumn.getText().trim());
    // // System.out.println("Test value column" + propertyColumn.getText().trim());
    // Assert.assertEquals("Verify in property Value", row.get("Value"),
    // propertyValueColumn.getText().trim().replace("\n", " "));
    // System.out.println("Test value column" + propertyValueColumn.getText().trim());
    // // Assert.assertEquals("Verify in property Description", row.get("Description"),
    // // propertyDescriptionColumn.getText().trim());
    //
    // } // row
    // }
    // }

    public void verifyPatientListConfigurationPropertyName(ExamplesTable dataTable)
            throws IOException, UnreachableBrowserException, WebDriverException, InterruptedException
    {
        // boolean replaceNamedParameters = true;
        // String Values = dataTable.getRowAsParameters(0, replaceNamedParameters).valueAs("Values", String.class);
        // expect 3000
        List<WebElement> allRows = SeleniumUtility.getInstance()
                .findElements("allRowsPatientListSystemPropertiesTable");
        System.out.println("The number of rows" + allRows.size());
        // List<WebElement> cellData = selUtility.findElements("allRows");
        for (WebElement rowElement : allRows)
        {
            // String rowNo = rowElement.getText().trim();
            int i = 1;
            for (Map<String, String> row : dataTable.getRows())
            {

                WebElement propertyColumn = rowElement.findElement(
                        By.xpath("//*[@id='systemConfigSummary']/form/fieldset[2]/table//tbody//tr[" + i + "]//td[1]"));
                WebElement propertyValueColumn = rowElement.findElement(
                        By.xpath("//*[@id='systemConfigSummary']/form/fieldset[2]/table//tbody//tr[" + i + "]//td[2]"));
                WebElement propertyDescriptionColumn = rowElement.findElement(
                        By.xpath("//*[@id='systemConfigSummary']/form/fieldset[2]/table//tbody//tr[" + i + "]//td[3]"));
                String a = propertyValueColumn.getText().trim();
                Assert.assertEquals("Verify in property Name", row.get("Property"), propertyColumn.getText().trim());
                System.out.println("Test value column" + propertyValueColumn.getText().trim());
                Assert.assertEquals("Verify in property Value", row.get("Value"),
                        propertyValueColumn.getText().trim().replace("\n", " "));
                System.out.println("Test value column" + propertyValueColumn.getText().trim());
                Assert.assertEquals("Verify in property Description", row.get("Description"),
                        propertyDescriptionColumn.getText().trim());
                i++;
            }                                                                                                // row
        }

    }

    public static void selectLoginNameUserFormat(String UserFormat)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Login_Name_dropdown");
            List<WebElement> loginformats = SeleniumUtility.getInstance().findElements("AllLoginUserNameDropDown");

            for (WebElement eachloginformat : loginformats)
            {
                if ( UserFormat.equalsIgnoreCase(eachloginformat.getText().trim()) )
                {

                    eachloginformat.click();
                    System.out.println("The selected value" + UserFormat);
                    logger.debug("ConfiguratorSettings:selectLoginNameUserFormat: select the UserFormat " + UserFormat);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectLoginNameUserFormat", e);

        }
    }

    public static void selectPatientNameFormat(String PatientFormat)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Patient_NameFormat_dropdown");
            List<WebElement> PatientNameformats = SeleniumUtility.getInstance()
                    .findElements("AllPatientNameFormatDropDown");

            for (WebElement eachpatientNameformat : PatientNameformats)
            {
                if ( PatientFormat.equalsIgnoreCase(eachpatientNameformat.getText().trim()) )
                {

                    eachpatientNameformat.click();
                    System.out.println("The selected value" + PatientFormat);
                    logger.debug(
                            "ConfiguratorSettings:selectPatientNameFormat: select the PatientFormat " + PatientFormat);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectPatientNameFormat", e);

        }
    }

    public static void selectStaffNameFormat(String StaffFormat)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Staff_NameFormat_dropdown");
            List<WebElement> StaffNameformats = SeleniumUtility.getInstance()
                    .findElements("AllStaffNameFormatDropDown");

            for (WebElement eachstaffNameformat : StaffNameformats)
            {
                if ( StaffFormat.equalsIgnoreCase(eachstaffNameformat.getText().trim()) )
                {

                    eachstaffNameformat.click();
                    System.out.println("The selected value" + StaffFormat);
                    logger.debug("ConfiguratorSettings:selectStaffNameFormat: select the StaffFormat " + StaffFormat);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectStaffNameFormat", e);

        }
    }

    public static void selectRemoveStrip()
    {
        try
        {

            WebElement Strip = SeleniumUtility.getInstance().getElementByXPath("Remove_trailing_zeros");
            if ( Strip.isSelected() )
            {
                logger.debug("ConfiguratorSettings:selectRemoveStrip: Strip is selected " + Strip);

            }
            else
            {
                SeleniumUtility.getInstance().elementClick("Remove_trailing_zeros");
            }
        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectRemoveStrip", e);

        }

    }

    public static void unSelectRemoveStrip()
    {
        try
        {
            WebElement Strip = SeleniumUtility.getInstance().getElementByXPath("Remove_trailing_zeros");
            if ( Strip.isSelected() )
            {
                SeleniumUtility.getInstance().elementClick("Remove_trailing_zeros");
            }
            else
            {
                logger.debug("ConfiguratorSettings:UnSelectRemoveStrip: Strip is selected " + Strip);
            }
        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectRemoveStrip", e);

        }

    }

    // * Select Similar name
    // public static void selectSimilarNameIndication1()
    // {
    // try
    // {

    // WebElement Strip = SeleniumUtility.getInstance().getElementByXPath("First_Name");
    // if ( !Strip.isSelected() )
    // {
    // SeleniumUtility.getInstance().elementClick("First_Name");
    // }
    // }
    // catch (IOException e)
    // {

    // logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectSimilarNameIndication",
    // e);

    // }

    // }
    // with List

    public boolean selectSimilarNameIndicationFirstName(String propertyvalue)
            throws Exception
    {
        boolean flag = false;
        WebElement similarFirstNamecheckBox = SeleniumUtility.getInstance()
                .getElementByXPath("Similar_First_Name_Check");

        if ( propertyvalue.equalsIgnoreCase("true") )
        {
            if ( !similarFirstNamecheckBox.isSelected() )
            {
                similarFirstNamecheckBox.click();
                flag = true;
            }

        }
        else
        {
            if ( similarFirstNamecheckBox.isSelected() )
            {
                similarFirstNamecheckBox.click();
                flag = true;
            }
        }
        return flag;
    }

    public boolean selectSimilarNameIndicationLastName(String propertyvalue)
            throws Exception
    {
        boolean flag = false;
        WebElement similarLastNamecheckBox = SeleniumUtility.getInstance().getElementByXPath("Similar_Last_Name_Check");

        if ( propertyvalue.equalsIgnoreCase("true") )
        {
            if ( !similarLastNamecheckBox.isSelected() )
            {
                similarLastNamecheckBox.click();
                flag = true;
            }

        }
        else
        {
            if ( similarLastNamecheckBox.isSelected() )
            {
                similarLastNamecheckBox.click();
                flag = true;
            }
        }
        return flag;

    }

    public static void selectSaveButton()
            throws IOException
    {
        SeleniumUtility.getInstance().getElementByXPath("Save_Button").click();

    }

    public String getSavedMessage(String message)
            throws IOException, InterruptedException
    {
        String SaveMessage;
        ConfiguratorSettings.getInstance().waitForElementToAppear("savedMessage", message, Constants.HIGH_TIMEOUT);
        logger.debug("getSavedMessage: return message not appeared");
        SaveMessage = selUtility.getElementByXPath("savedMessage").getText().trim();
        logger.debug("ConfiguratorSettings:getSavedMessage: get the saved message");
        return SaveMessage;
    }

    public boolean waitForElementToAppear(String objectName, String textTobePresent, int timeout)
            throws IOException
    {
        return selUtility.waitTextToBePresentInElement(objectName, textTobePresent, timeout);
    }

    public static void selectPacuArrivingTimeEvent(String pacuArrivingTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_PACU_Bed_View");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_PACU_Bed_View");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( pacuArrivingTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + pacuArrivingTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + pacuArrivingTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectPacuArrivingTimeEvent",
                    e);

        }
    }

    public static void selectPacuAdmissionTimeEvent(String pacuAdmissionTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_PACU_Time");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance().findElements("All__Indicating_PACU_Time");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( pacuAdmissionTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + pacuAdmissionTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + pacuAdmissionTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectPacuArrivingTimeEvent",
                    e);

        }
    }

    public static void selectPacuReadyDischargeTimeEvent(String pacuReadyDischargeTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_Readiness_Discharge_From_PACU");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_Readiness_Discharge_From_PACU");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( pacuReadyDischargeTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + pacuReadyDischargeTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + pacuReadyDischargeTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error(
                    "Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectPacuReadyDischargeTimeEvent",
                    e);

        }
    }

    public static void selectPacuDischargeTimeEvent(String pacuDischargeTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_Discharge_From_PACU");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_Discharge_From_PACU");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( pacuDischargeTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + pacuDischargeTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + pacuDischargeTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectPacuDischargeTimeEvent",
                    e);

        }
    }

    public static void selectICUAdmissionTimeEvent(String iCUAdmissionTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_ICU_Time");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_ICU_Time");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( iCUAdmissionTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + iCUAdmissionTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + iCUAdmissionTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectICUAdmissionTimeEvent",
                    e);

        }
    }

    public static void selectICUReadyDischargeTimeEvent(String iCUReadyDischargeTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_Readiness_Discharge_From_ICU");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_Readiness_Discharge_From_ICU");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( iCUReadyDischargeTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + iCUReadyDischargeTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + iCUReadyDischargeTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error(
                    "Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectICUReadyDischargeTimeEvent",
                    e);

        }
    }

    public static void selectICUDischargeTimeEvent(String iCUDischargeTimeEvent)
    {

        try
        {
            SeleniumUtility.getInstance().elementClick("Time_Indicating_Discharge_From_ICU");
            List<WebElement> pacuTimeEvents = SeleniumUtility.getInstance()
                    .findElements("All_Time_Indicating_Discharge_From_ICU");

            for (WebElement eachTimeEvent : pacuTimeEvents)
            {
                if ( iCUDischargeTimeEvent.equalsIgnoreCase(eachTimeEvent.getText().trim()) )
                {

                    eachTimeEvent.click();
                    System.out.println("The selected value" + iCUDischargeTimeEvent);
                    logger.debug("ConfiguratorSettings:selectPacuArrivingTimeEvent: select the PACU Time Event "
                            + iCUDischargeTimeEvent);
                    break;

                }
            }

        }
        catch (IOException | InterruptedException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.selectICUDischargeTimeEvent",
                    e);

        }
    }

    public static void SelectBirthName()
    {
        try
        {

            WebElement ShowBirthName = SeleniumUtility.getInstance().getElementByXPath("Show_BirthName");
            if ( ShowBirthName.isSelected() )
            {
                logger.debug("ConfiguratorSettings:selectRemoveStrip: Strip is selected " + ShowBirthName);

            }
            else
            {
                SeleniumUtility.getInstance().elementClick("Show_BirthName");
            }
        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.SelectBirthName", e);

        }

    }

    public static void unSelectBirthName()
    {
        try
        {

            WebElement ShowBirthName = SeleniumUtility.getInstance().getElementByXPath("Show_BirthName");
            if ( ShowBirthName.isSelected() )
            {
                SeleniumUtility.getInstance().elementClick("Show_BirthName");

            }

        }
        catch (IOException e)
        {

            logger.error("Exception in com.ge.hac.pl.bdd.functions.ConfiguratorSettings.unSelectBirthName", e);

        }

    }
}
