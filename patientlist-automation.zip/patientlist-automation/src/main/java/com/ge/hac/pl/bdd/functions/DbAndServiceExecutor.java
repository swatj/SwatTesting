/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * 502391213     01-June-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.ge.hac.ca.bdd.common.Settings;
import com.ge.hac.ca.common.info.ServerInfoSingleton;
import com.ge.hac.ca.common.interfaces.PropertySessionRemote;
import com.ge.hac.ca.common.util.ServiceLocator;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;

public class DbAndServiceExecutor
{
    private static Logger logger = Logger.getLogger(DbAndServiceExecutor.class);

    private DbAndServiceExecutor()
    {

    }

    public static void RemoteC()
    {
        try
        {
            String start = PropertyFileHelper.getProjectProperty("Start");
            String stop = PropertyFileHelper.getProjectProperty("Stop");

            logger.debug("Stopping POC service by running file: " + stop);
            Process proc = Runtime.getRuntime().exec(stop);
            proc.waitFor();
            Thread.sleep(6000);
            logger.debug("Stopped POC service...");
            System.out.println("Stopped POC service...");

            logger.debug("Starting POC service by running file: " + start);
            Process proc1 = Runtime.getRuntime().exec(start);
            proc1.waitFor();
            Thread.sleep(6000);
            logger.debug("Started POC service...");
        }
        catch (Exception e)
        {
            logger.error("Error executing DbAndServiceExecutor.RemoteC()", e);
        }
    }

    public static void dbchanges(String table, String delete, String update, String columnName)
            throws SQLException, ClassNotFoundException
    {
        String DbPath = PropertyFileHelper.getSqlScripts("dbPath");
        String Sql = PropertyFileHelper.getSqlScripts(table);
        String delSql = PropertyFileHelper.getSqlScripts(delete);
        String updSql = PropertyFileHelper.getSqlScripts(update);
        String colmnname = PropertyFileHelper.getSqlScripts(columnName);

        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection conn = DriverManager.getConnection(DbPath);
        logger.debug("Displaying the data of a column");
        Statement sta = conn.createStatement();
        sta.executeUpdate(delSql);
        sta.executeUpdate(updSql);
        ResultSet rsSql = sta.executeQuery(Sql);
        while (rsSql.next())
        {
            logger.debug(rsSql.getString(colmnname));
        }
    }

    // change server locale and restart the server
    public static void changeLocaleAndRestartServer(String locale)

    {
        System.setProperty(javax.naming.Context.PROVIDER_URL, PropertyFileHelper.getProjectProperty("PROVIDER_URL"));
        try
        {
            Settings.initSystemProperties();
            PropertySessionRemote propertyService = (PropertySessionRemote) ServiceLocator
                    .getService(ServiceLocator.Services.PROPERTY);
            if ( locale.trim() == "" )
            {
                locale = PropertyFileHelper.getProjectProperty("Server_Locale");
            }
            propertyService.setProperty(PropertySessionRemote.SYSTEM_LOCALE, locale, "");

            ServerInfoSingleton sis = (ServerInfoSingleton) ServiceLocator
                    .getService(ServiceLocator.Services.SERVERINFO);
            sis.startService();

            Thread.sleep(5000);
        }
        catch (Exception e)
        {

            logger.error(
                    "com.ge.hac.pl.bdd.functions:DbAndServiceExecutor:changeLocaleAndRestartServer - error while restarting the server.",
                    e);
        }

    }

}
