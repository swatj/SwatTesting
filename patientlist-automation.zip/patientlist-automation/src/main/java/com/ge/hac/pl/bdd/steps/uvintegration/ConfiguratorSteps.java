/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.functions.Configurator;
import com.ge.hac.pl.bdd.functions.Sorting;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

/**
 * @author pandharinathj
 * 
 */
public class ConfiguratorSteps
{
    @Given("that Configurator application is launched")
    @When("the Configurator application is launched")
    public static void openConfiguratorApplication()
    {
        Configurator.openConfiguratorApplication();
        Configurator.waitForPageToload();
    }

    @Then("Settings tab should display default active tab on configurator tool")
    public static void verifyActiveTab()
    {
        String activeTab = Configurator.getFirstTabName();
        Assert.assertTrue(
                "Verify that default active tab name on configurator tool" + " expected="
                        + Constants.CONFIGURATOR_FIRST_TAB_NAME + " actual=" + activeTab,
                Constants.CONFIGURATOR_FIRST_TAB_NAME.equalsIgnoreCase(activeTab));
    }

    @Then("the $tabName tab is the $order tab on the Configurator tool")
    public static void verifyTabOrder(String tabName, String order) // throws Exception
    {
        SeleniumUtility slu = SeleniumUtility.getInstance();
        String xpathIdentifier = "";
        String expectedTabName = "";
        WebElement ele = null;

        // Get the xpath id of the tab
        if ( "first".equalsIgnoreCase(order) )
        {
            xpathIdentifier = "first_tab";
        }
        else if ( "second".equalsIgnoreCase(order) )
        {
            xpathIdentifier = "second_tab";
        }

        // Get the tab name
        for (Constants.ConfigToolTabs tab : Constants.ConfigToolTabs.values())
        {
            if ( tab.getTabIdInFeature().equals(tabName) )
            {
                expectedTabName = tab.getTabName();
                break;
            }
        }
        ele = slu.findElementbyXpath(PropertyFileHelper.getObjectIdentifier(xpathIdentifier));
        String actualTabName = ele.getText();
        Assert.assertTrue(tabName + " tab is the " + order + " tab.", actualTabName.equals(expectedTabName));
    }

    @Then("the Settings tab is chosen by default")
    public static void verifyDefaultTab()
    {
        SeleniumUtility slu = SeleniumUtility.getInstance();
        String xpathSummaryTab = ".//*[@id='systemSettingsContainer']/div[1]/div/ul/li[1]/a";
        String xpathConfiguratonTab = ".//*[@id='systemSettingsContainer']/div[1]/div/ul/li[2]/a";

        WebElement ele = null;
        ele = slu.findElementbyXpath(xpathSummaryTab);
        if ( ele != null )
        {
            ele = null;
            ele = slu.findElementbyXpath(xpathConfiguratonTab);
        }

        Assert.assertNotNull("Summary and Configuration tab found indicating that Settings tab is chosen", ele);
    }

    @Then("Settings tab should display first tab on configurator tool")
    public static void verifyFirstTab()
    {
        String firstTab = Configurator.getFirstTabName();
        Assert.assertTrue("Verify that first tab name on configurator tool" + " expected="
                + Constants.CONFIGURATOR_FIRST_TAB_NAME + " actual=" + firstTab,
                Constants.CONFIGURATOR_FIRST_TAB_NAME.equalsIgnoreCase(firstTab));
    }

    @Then("Unit View Layout display second tab on configurator tool")
    public static void verifySecondTab()
    {
        String secondTab = Configurator.getSecondTabName();
        Assert.assertTrue(
                "Verify that second tab name on configurator tool" + " expected="
                        + Constants.CONFIGURATOR_SECOND_TAB_NAME + " actual=" + secondTab,
                Constants.CONFIGURATOR_SECOND_TAB_NAME.equalsIgnoreCase(secondTab));
    }

    @Then("rows text box should display <rowsNumber> value")
    public static void verifyDefaultRowsNo(@Named("rowsNumber") int rowsNumber)
    {
        int actowNumber = Configurator.getDefaultRowsNo();
        Assert.assertTrue(
                "Verify that default value in rows text" + " expected=" + rowsNumber + " actual=" + actowNumber,
                (rowsNumber == actowNumber));
    }

    @Then("cols text box should display <columnsNumber> value")
    public static void verifyDefaultColssNo(@Named("columnsNumber") int columnsNumber)
    {
        int actcolumnsNumber = Configurator.getDefaultColsNo();
        Assert.assertTrue("Verify that default value in columns text" + " expected=" + columnsNumber + " actual="
                + actcolumnsNumber, (columnsNumber == actcolumnsNumber));

    }

    @Then("bed layout grid should display <rowsNumber> rows and <columnsNumber> columns")
    public static void verifyDefaultLayoutRowsAndColsNo(@Named("rowsNumber") int rowsNumber,
            @Named("columnsNumber") int columnsNumber)
    {
        int actcolumnsNumber = Configurator.getLayoutColsNo();
        Assert.assertTrue("Verify grid columns" + " expected=" + columnsNumber + " actual=" + actcolumnsNumber,
                (columnsNumber == actcolumnsNumber));

        int actrowsNumber = Configurator.getLayoutRowsNo();
        Assert.assertTrue("Verify grid rows" + " expected=" + rowsNumber + " actual=" + actrowsNumber,
                (rowsNumber == actrowsNumber));
    }

    @Then("department dropdown should display departments in alphabetically sorted order")
    public static void verifyDepartmentOrder()
    {
        // get actual departments
        List<String> actDepartments = Configurator.getAllDepartments();
        // sort the departments from expected departments
        String[] expDepartments = new String[actDepartments.size()];
        Sorting.Sort(actDepartments.toArray(expDepartments));
        // compare actual order with expected order
        Assert.assertTrue(
                "Verify that department dropdwon contains PACU and ICU department in alphabetically sorted order"
                        + " expected=" + Arrays.asList(expDepartments).toString() + " actual="
                        + actDepartments.toString(),
                Arrays.asList(expDepartments).toString().equalsIgnoreCase(actDepartments.toString()));
    }

    @Then("default selected department in dropdown should be the first alphabetically sorted department")
    public static void verifyActiveDepartment()
    {
        List<String> actDepartments = Configurator.getAllDepartments();
        // sort the departments from expected departments
        String[] expDepartments = new String[actDepartments.size()];
        Sorting.Sort(actDepartments.toArray(expDepartments));
        String selectedDepartment = Configurator.getSelectedDepartment();
        Assert.assertTrue(
                "Verify that default selected department in dropdown is the first alphabetically sorted department"
                        + " expected=" + expDepartments[0] + " actual=" + selectedDepartment,
                expDepartments[0].equalsIgnoreCase(selectedDepartment));
    }

    @Then("room dropdown should display rooms in alphabetically sorted order")
    public static void verifyRoomOrder()
    {
        // get actual rooms
        List<String> actRooms = Configurator.getRoomsFromDropDown();
        // sort the rooms from expected rooms
        String[] expRooms = new String[actRooms.size()];
        Sorting.Sort(actRooms.toArray(expRooms));
        // compare actual oder with expected order

        Assert.assertTrue(
                "Verify that default room dropdown contains rooms in alphabetically sorted order" + " expected="
                        + Arrays.asList(expRooms).toString() + " actual=" + actRooms.toString(),
                Arrays.asList(expRooms).toString().equalsIgnoreCase(actRooms.toString()));
    }

    @Then("department dropdown should display PACU and ICU departments only")
    public static void verifyDepartmentDropdwon(@Named("departemnts") String departemnts)
    {
        String[] arrDepartemnts = departemnts.split(",");
        List<String> actDepartments = Configurator.getAllDepartments();

        for (String department : arrDepartemnts)
        {
            Assert.assertTrue(
                    "verify that " + department + " department is displayed in dropdown " + actDepartments.toString(),
                    actDepartments.contains(department));
        }
    }

    @Then("default selected room in dropdown should be the first alphabetically sorted room for selected department")
    public static void verifyActiveRoom()
    {
        List<String> actRooms = Configurator.getRoomsFromDropDown();
        String[] expRooms = new String[actRooms.size()];
        Sorting.Sort(actRooms.toArray(expRooms));
        String selectedRoom = Configurator.getSelectedRoom();
        Assert.assertTrue(
                "Verify that default selected room in dropdown is the first alphabetically sorted room for selected department"
                        + " expected=" + expRooms[0] + " actual=" + selectedRoom,
                expRooms[0].equalsIgnoreCase(selectedRoom));
    }

    @When("user changes the rows number to <rowsNumber>")
    public static void setRowNumber(@Named("rowsNumber") String rowsNumber)

    {
        Configurator.setRowNumber(rowsNumber);
        Configurator.waitForPageToload();
    }

    @When("user changes the cols number to <columnsNumber>")
    public static void setColumnNumber(@Named("columnsNumber") String columnsNumber)

    {
        Configurator.setColumnNumber(columnsNumber);
        Configurator.waitForPageToload();
    }

    @When("user selects <department> from department dropdown")
    public static void selectDepartment(@Named("department") String department)
    {
        Configurator.selectDepartment(department);
        Configurator.waitForPageToload();
    }

    @When("user selects <room> from room dropdown")
    public static void selectRoom(@Named("room") String room)
    {
        Configurator.selectRoom(room);
        Configurator.waitForPageToload();
    }

    @When("user clicks on any cell <rowno>,<colno> of grid")
    public static void clickOnCell(@Named("rowno") String rowNo, @Named("colno") String colNo)
    {
        Configurator.clickOnCell(rowNo, colNo);
    }

    @Then("<beds> should display on context menu in alphabetically sorted order")
    public static void verifybedsInContextMenu(@Named("beds") String beds)
    {
        List<String> actBedlist = Configurator.getBedsNameFromContextMenu();

        for (String bed : beds.split(","))
        {

            Assert.assertTrue(
                    "Verify the " + bed + " bed list for selected room is displayed in context menu" + actBedlist,
                    actBedlist.contains(bed));
        }

        String[] expBedist = new String[actBedlist.size()];
        Sorting.Sort(actBedlist.toArray(expBedist));
        Assert.assertTrue(
                "Verify that  bed list for selected room is displayed in context menu in alphabetically sorted department"
                        + " expected=" + Arrays.asList(expBedist).toString() + " actual=" + actBedlist.toString(),
                Arrays.asList(expBedist).toString().equalsIgnoreCase(actBedlist.toString()));

    }

    @When("user assigns bed to empty cell of grid")
    public static void assignBed(@Named("rowno") String rowNo, @Named("colno") String colNo,
            @Named("bed") String bedName)
    {
        Configurator.assignBed(rowNo, colNo, bedName);
        Configurator.waitForPageToload();
    }

    @When("user removes the bed from cell <rowno>,<colno> of grid")
    public static void removeBed(@Named("rowno") String rowNo, @Named("colno") String colNo)
    {
        Configurator.removeBed(rowNo, colNo);
        Configurator.waitForPageToload();
    }

    @Then("user should not able to remove bed")
    public static void NotAbleToRemoveBed(@Named("rowno") String rowNo, @Named("colno") String colNo)
    {
        Assert.assertEquals("Verify the that bed on cell (" + rowNo + "," + colNo + ") is not removable", false,
                Configurator.isBedRemovable(rowNo, colNo));

    }

    @Then("cell should display assigned <room> room name and <bed> bed name")
    public static void verifyRoomAndBed(@Named("rowno") String rowNo, @Named("colno") String colNo,
            @Named("room") String roomName, @Named("bed") String bedName)
    {
        String actbedName = Configurator.getBedName(rowNo, colNo);
        Assert.assertTrue("Verify the that bed name on cell (" + rowNo + "," + colNo + ") is displayed" + " expected="
                + bedName + " actual=" + actbedName, bedName.equalsIgnoreCase(actbedName));
        String actroomName = Configurator.getRoomName(rowNo, colNo);
        Assert.assertTrue("Verify the that room name on cell (" + rowNo + "," + colNo + ") is displayed" + " expected="
                + roomName + " actual=" + actroomName, roomName.equalsIgnoreCase(actroomName));

    }

    @Then("removed <bed> bed should not display on grid")
    public static void verifyBed(@Named("rowno") String rowNo, @Named("colno") String colNo,
            @Named("bed") String bedName)
    {
        Assert.assertEquals(
                "Verify the that " + bedName + "bed name on cell (" + rowNo + "," + colNo + ") is not  displayed", "",
                Configurator.getBedName(rowNo, colNo));

    }

    @Then("<bed> name should not display in context menu")
    public static void verifybedInContextMenu(@Named("bed") String bed)
    {

        List<String> actBedlist = Configurator.getBedsNameFromContextMenu();

        Assert.assertTrue(
                "Verify the " + bed + " bed list for selected room is not displayed in context menu" + actBedlist,
                !(actBedlist.contains(bed)));

    }

    @Then("context menu should disappear")
    @Alias("context menu of bed list should not display")
    public static void isContextMenuDisplayed()
    {
        Assert.assertEquals("Verify the that context menu is not displayed", false,
                Configurator.isContextMenuDisplayed());

    }

    @When("user selects <tab>")
    public static void selectTab(@Named("tab") String tabName)
            throws IOException, InterruptedException
    {

        Configurator.selectTab(tabName);
        Configurator.waitForPageToload();
        Thread.sleep(5000);
    }

    @Then("room dropdown should be empty")
    public static void verifyRoomIsEmpty()
    {

        Assert.assertTrue("Verify the that room dropdown is empty", Configurator.getRoomsFromDropDown().isEmpty());
    }

    @Then("configurator tool should get error <message>")
    public static void verifyErrorMessage(@Named("message") String expMessage)
    {
        String actMessage = Configurator.getErrorMessage();
        Assert.assertTrue("Verify the error message on remving the occupied cell from grid," + " expected=" + expMessage
                + " ,actual=" + actMessage, expMessage.equalsIgnoreCase(actMessage));
    }

    // To remove all bed from room
    @When("user remove bed from room")
    public static void clearAllCell()
    {
        int rowNo = Configurator.getDefaultRowsNo();
        int colNo = Configurator.getDefaultColsNo();
        System.out.println("rowno:" + rowNo);
        System.out.println("colNo:" + colNo);

        for (int i = 1; i <= rowNo; i++)
        {
            for (int j = 1; j <= colNo; j++)
            {
                String currentRoom = Configurator.getRoomName(Integer.toString(i), Integer.toString(j));
                System.out.println("currentRoom: " + currentRoom);
                if ( !currentRoom.equalsIgnoreCase("") )
                {
                    selectRoom(currentRoom);
                    removeBed(Integer.toString(i), Integer.toString(j));
                }

            }
        }

        Configurator.waitForPageToload();
    }

    @Then("Patient list application general properties should display with its values")
    public void verifyGeneralProperties(@Named("propertykey") String propertykey,
            @Named("propertyname") String propertyname, @Named("propertyvalue") String propertyvalue)
    {

        String actPropertyName = Configurator.getPropertyName(propertykey);
        String actPropertyValue = Configurator.getPropertyValue(propertykey);
        Assert.assertEquals("Verify property name of property=" + propertykey + " expected=" + propertyname
                + " ,actual=" + actPropertyName, propertyname, actPropertyName);
        Assert.assertEquals("Verify property value of property=" + propertykey + " expected=" + propertyvalue
                + " ,actual=" + actPropertyValue, propertyvalue, actPropertyValue);

    }

    @Then("Patient list application list view properties should display with its values")
    public void verifyListViewProperties(@Named("propertykey") String propertykey,
            @Named("propertyname") String propertyname, @Named("propertyvalue") String propertyvalue)
    {

        String actPropertyName = Configurator.getPropertyName(propertykey);
        String actPropertyValue = Configurator.getPropertyValue(propertykey);
        Assert.assertEquals("Verify property name of property=" + propertykey + " expected=" + propertyname
                + " ,actual=" + actPropertyName, propertyname, actPropertyName);
        Assert.assertEquals("Verify property value of property=" + propertykey + " expected=" + propertyvalue
                + " ,actual=" + actPropertyValue, propertyvalue, actPropertyValue);

    }

    @Then("Patient list application unit view properties should display with its values")
    public void verifyUnitViewProperties(@Named("propertykey") String propertykey,
            @Named("propertyname") String propertyname, @Named("propertyvalue") String propertyvalue)
    {

        String actPropertyName = Configurator.getPropertyName(propertykey);
        String actPropertyValue = Configurator.getPropertyValue(propertykey);
        Assert.assertEquals("Verify property name of property=" + propertykey + " expected=" + propertyname
                + " ,actual=" + actPropertyName, propertyname, actPropertyName);
        Assert.assertEquals("Verify property value of property=" + propertykey + " expected=" + propertyvalue
                + " ,actual=" + actPropertyValue, propertyvalue, actPropertyValue);

    }

    @Then("Change Save order of columns property vlaue to <saveColumnOrder>")
    public void changeSaveColumnOrderProperty(@Named("saveColumnOrder") String propertyvalue)
            throws IOException
    {
        String propertyname = "saveColumnOrder";
        Configurator.changeCheckBoxProperty(propertyname, propertyvalue);

    }

    @Then("Change Remove case from list on care phase completion property vlaue to <dropCaseOnCompletion>")
    public void changeDropCaseOnCompletionProperty(@Named("dropCaseOnCompletion") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("dropCaseOnCompletion", propertyvalue);

    }

    @Then("Change Sort column data in descending order property vlaue to <sortorder>")
    public void changeSortorderProperty(@Named("sortorder") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("sortorder", propertyvalue);

    }

    @Then("Change Patient birth name available for display property vlaue to <birthname>")
    public void changeBirthnameProperty(@Named("birthname") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("birthname", propertyvalue);

    }

    @Then("Change Weight units available for display property vlaue to <weightInkgs>")
    public void changeWeightInKgsProperty(@Named("weightInkgs") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("weightInkgs", propertyvalue);

    }

    @Then("Change Weight units available for display property vlaue to <weightInlbs>")
    public void changeWeightInlbsProperty(@Named("weightInlbs") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("weightInlbs", propertyvalue);

    }

    @Then("Change Height units available for display property vlaue to <heightInCms>")
    public void changeHeightinCmsProperty(@Named("heightInCms") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("heightInCms", propertyvalue);

    }

    @Then("Change Height units available for display property vlaue to <heightInInchs>")
    public void changeHeightInInchsProperty(@Named("heightInInchs") String propertyvalue)
            throws IOException
    {

        Configurator.changeCheckBoxProperty("heightInInchs", propertyvalue);

    }

    @Then("Change Surgeon role name property vlaue to <surgeonRole>")
    public void changeSurgeonRoleProperty(@Named("surgeonRole") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("surgeonRole", propertyvalue);

    }

    @Then("Change Anesthesiologist role name property vlaue to <anesthesiologistRole>")
    public void changeAnesthesiologistRoleProperty(@Named("anesthesiologistRole") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("anesthesiologistRole", propertyvalue);

    }

    @Then("Change Nurse role name property vlaue to <nurseRole>")
    public void changeNurseRoleProperty(@Named("nurseRole") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("nurseRole", propertyvalue);

    }

    @Then("Change Workflow end time property vlaue to <workflowEndTime>")
    public void changeWorkflowEndTimeProperty(@Named("workflowEndTime") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("workflowEndTime", propertyvalue);

    }

    @Then("Change Columns for default primary sorting property vlaue to <primarySorting>")
    public void changePrimarySortingProperty(@Named("primarySorting") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("primarySorting", propertyvalue);

    }

    @Then("Change Columns for default secondary sorting property vlaue to <secondarysorting>")
    public void changeSecondarySortingProperty(@Named("secondarysorting") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("secondarysorting", propertyvalue);

    }

    @Then("Change the time event value to <timeeventsdisplay>")
    public void changeTimeeventsDisplayProperty(@Named("timeeventsdisplay") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("timeeventsdisplay", propertyvalue);

    }

    @Then("Change the first care phase value to <firstcasephase>")
    public void changeFirstCasephaseProperty(@Named("firstcasephase") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("firstcasephase", propertyvalue);

    }

    @Then("Change the second care phase value to <secondcasephase>")
    public void changeSecondCasephaseProperty(@Named("secondcasephase") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("secondcasephase", propertyvalue);

    }

    @Then("Change the third care phase value to <thirdcasephase>")
    public void changethirdCasephaseProperty(@Named("thirdcasephase") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("thirdcasephase", propertyvalue);

    }

    @Then("Change the fourth care phase value to <fourthcasephase>")
    public void changeFourthCasephaseProperty(@Named("fourthcasephase") String propertyvalue)
            throws IOException
    {

        Configurator.changeSelectDropDownProperty("fourthcasephase", propertyvalue);

    }

    @When("the user selects Configuration tab")
    public static void selectConfigurationLink()
            throws IOException
    {
        Configurator.selectConfigurationLink();

    }

    @When("user clicks on summary tab")
    public static void selectSummaryLink()
            throws IOException
    {
        Configurator.selectSummaryLink();

    }

    @Then("user clicks on save button")
    public static void clickOnSaveButton()
            throws IOException
    {
        Configurator.clickOnSaveButton();
        try
        {
            Thread.sleep(5000);
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Then("dropdown values should alphabetically sorted")
    public static void VerifyDropdownValuesOrder(@Named("DropDownName") String DropDownName)
    {

        String[] AllDropDownName = DropDownName.split(",");
        for (int i = 0; i <= AllDropDownName.length - 1; i++)
        {
            String DropDownValues = Configurator.getAllDropDownValues(AllDropDownName[i]);
            String[] actDropDownValues = DropDownValues.split(",");
            String[] sortedDropDownValues = DropDownValues.split(",");
            Arrays.sort(sortedDropDownValues);
            for (int count = 0; count <= sortedDropDownValues.length - 1; count++)
            {

                Assert.assertEquals(
                        "Verify order of " + AllDropDownName[i] + " dropdown at position =" + count + "   expected="
                                + sortedDropDownValues[count].trim() + " ,actual=" + actDropDownValues[count].trim(),
                        sortedDropDownValues[count].trim(), actDropDownValues[count].trim());
            }

        }

    }
}
