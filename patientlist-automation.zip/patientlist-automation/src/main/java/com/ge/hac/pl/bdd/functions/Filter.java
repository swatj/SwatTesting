/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class Filter
{
    private static Logger   logger               = Logger.getLogger(Filter.class);
    private SeleniumUtility selUtility;
    private static Filter   instance             = null;
    private int             beforeFilterRowCount = 0;
    private int             withFilterCardCount  = 0;

    private Filter()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver
                                                        // to seleniumUtility
                                                        // class
        }
        catch (Exception e)
        {
            logger.error("Filter() - error initializing web browser.", e);
        }

    }

    public static Filter getInstance()
    {
        if ( instance == null )
        {
            instance = new Filter();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    // clear filter
    public void clearFilter(String columnName)
            throws IOException
    {
        String filterClearButton = PropertyFileHelper.getObjectIdentifier("filterClearButton");
        filterClearButton = filterClearButton.replace("REPLACE_COLUMNNAME", columnName);
        // click on X to remove filter
        WebElement filterClearElement = selUtility.findElementbyXpath(filterClearButton);
        logger.debug("Filter:clearFilter: clear filter");
        filterClearElement.click();
    }

    // set filter
    public void setFilter(String columnName, String filterValue)
            throws IOException, InterruptedException
    {
        String filterTextbox = PropertyFileHelper.getObjectIdentifier("filterTextbox");
        filterTextbox = filterTextbox.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterTextboxElement = selUtility.findElementbyXpath(filterTextbox);
        logger.debug("Filter:setFilter: set the Filter with value " + filterValue);
        filterTextboxElement.clear();
        filterTextboxElement.sendKeys(filterValue);
        Thread.sleep(3000);
        beforeFilterRowCount = getRowCount();
    }

    // get filter textbox text
    public String getFilterTextBoxText(String columnName)
            throws IOException
    {
        String filterTextbox = PropertyFileHelper.getObjectIdentifier("filterTextbox");
        filterTextbox = filterTextbox.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterTextboxElement = selUtility.findElementbyXpath(filterTextbox);
        String filterValue = filterTextboxElement.getText();
        logger.debug("Filter:getFilterTextBoxText: get filter text box text " + filterValue);
        return filterValue;
    }

    // get visible columns list
    public List<String> getVisibleColumnList()
            throws IOException, InterruptedException
    {
        List<String> visiblecolumnNameList = new ArrayList<String>();
        List<WebElement> visibleColumns = selUtility.findElements("visibleColumns");
        for (int i = 0; i < visibleColumns.size(); i++)
        {
            visiblecolumnNameList.add(visibleColumns.get(i).getText());
        }
        logger.debug("Filter:getVisibleColumnList: visible columnlist");
        return visiblecolumnNameList;
    }

    // check filter textbox present for passed columns
    public boolean isFilterTextBoxPresent(String columnName)
            throws IOException, InterruptedException
    {
        String filterTextbox = PropertyFileHelper.getObjectIdentifier("filterTextbox");
        filterTextbox = filterTextbox.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterTextboxElement = selUtility.findElementbyXpath(filterTextbox);
        logger.debug("Filter:isFilterTextBoxPresent: is filter text box present for column " + columnName + " "
                + filterTextboxElement.isDisplayed());
        return filterTextboxElement.isDisplayed();
    }

    // check filter clear button present for passed columns
    public boolean isFilterClearButtonPresent(String columnName)
            throws IOException, InterruptedException
    {
        String filterClearButton = PropertyFileHelper.getObjectIdentifier("filterClearButton");
        filterClearButton = filterClearButton.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterClearButtonElement = selUtility.findElementbyXpath(filterClearButton);
        logger.debug("Filter:isFilterTextBoxPresent: is filter clear button present for column " + columnName + " "
                + filterClearButtonElement.isDisplayed());
        return filterClearButtonElement.isDisplayed();
    }

    // get Filtered column background color
    public String getFilteredColumnBackgroundColor(String columnName)
            throws IOException, InterruptedException
    {
        String filteredColumnBGColor = null;
        List<WebElement> visibleColumnsList = selUtility.findElements("visibleColumns");
        for (int i = 0; i < visibleColumnsList.size(); i++)
        {
            if ( columnName.equalsIgnoreCase(visibleColumnsList.get(i).getText()) )
            {
                filteredColumnBGColor = PatientList.getInstance()
                        .getBackgroundColor(visibleColumnsList.get(i).findElement(By.xpath("..")));
            }
        }
        logger.debug("Filter:getFilteredColumnBackgroundColor: Filtered column background color is "
                + filteredColumnBGColor);
        return filteredColumnBGColor;
    }

    // this function is used to get filter textbox position
    public Map<String, Integer> getFilterTextBoxesPosition()
            throws IOException, InterruptedException
    {
        String columnName;
        Map<String, Integer> FilterTextBoxIndexMap = new HashMap<String, Integer>();
        List<WebElement> allFilteredTextBox = selUtility.findElements("allfilterTextbox");

        for (int index = 0; index < allFilteredTextBox.size(); index++)
        {
            columnName = allFilteredTextBox.get(index).getAttribute("name").trim();
            FilterTextBoxIndexMap.put(columnName, index + 1);
        }

        logger.debug("Filter:getFilterTextBoxPosition: get map of filter text box with theire position "
                + FilterTextBoxIndexMap);
        return FilterTextBoxIndexMap;
    }

    // clear all applied filter
    public void clearAllFilter()
            throws IOException, InterruptedException
    {
        try
        {
            List<WebElement> allClearButton = selUtility.findElements("allFilterClearButton");
            logger.debug("Filter:clearAllFilter: clear all applied filter");
            for (int i = 0; i < allClearButton.size(); i++)
            {

                allClearButton.get(i).click();
                Thread.sleep(100);

            }
            beforeFilterRowCount = getRowCount();
            logger.debug("Filter:clearAllFilter: clear all filter");
        }
        catch (Exception e)
        {
            logger.error("Filter:clearAllFilter: No data to clear", e);
        }
        Thread.sleep(2000);
    }

    // verify filtered data displayed
    public boolean verifyFilteredData(String columnName, String filterValue)
            throws Exception
    {
        boolean found = false;
        List<String> patientListColumnHeaderList = new ArrayList<String>();
        patientListColumnHeaderList.add(columnName);
        int columnIndex = PatientListData.getInstance().getColumnPosition(patientListColumnHeaderList, columnName);
        List<WebElement> allRows = selUtility.findElements("allRows");
        if ( allRows.size() == 0 )
        {
            Assert.fail("filtered data not available on patient list.Please verify data");
        }
        for (int i = 1; i <= allRows.size(); i++)
        {
            String actValue = PatientListData.getInstance().getCellValue(i, columnIndex);

            if ( actValue.contains(filterValue) )
            {
                found = true;
            }
            else
            {
                if ( !"".equalsIgnoreCase(actValue.trim()) )
                {
                    // verify in to popover if vALUE IS NOT BLANK
                    if ( columnName.equalsIgnoreCase(Constants.SURGEON_COLUMN)
                            || columnName.equalsIgnoreCase(Constants.ANESTHESIA_COLUMN)
                            || columnName.equalsIgnoreCase(Constants.PROCEDURE_COLUMN)
                            || columnName.equalsIgnoreCase(Constants.DIAGNOSIS_COLUMN) )
                    {

                        // invoke popover
                        Popover.getInstance().invokePopover(columnName, i);
                        Assert.assertEquals("verify popover displayed for column=" + columnName,
                                Popover.getInstance().PopoverDisplayed(), true);
                        // read data from popover
                        actValue = Popover.getInstance().getPopoverData();
                        logger.debug("Popover data for column=" + columnName + " was " + actValue);
                        // close popover
                        Popover.getInstance().closePopover();

                        if ( actValue.contains(filterValue) )
                        {
                            found = true;
                        }
                        else
                        {
                            found = false;
                            break;
                        }
                    }
                    else
                    {
                        found = false;
                        break;
                    }
                }
            }
        }
        logger.debug("Filter:verifyFilteredData: verify filter data");
        return found;

    }

    public void verifyAllDataPresent()
            throws IOException, InterruptedException
    {
        // List<WebElement> afterFilterRows =
        // selUtility.findElements("allRows");
        int afterFilterRowCount = getRowCount();
        System.out.println("beforeFilterRowCount :" + beforeFilterRowCount);
        System.out.println("afterFilterRowCount :" + afterFilterRowCount);
        Assert.assertTrue(
                "verify filter is removed by comparing row count" + afterFilterRowCount + " " + beforeFilterRowCount,
                afterFilterRowCount > beforeFilterRowCount);

    }

    // verify no filter error message
    public void verifyNoFilterErrorMessage()
            throws IOException, InterruptedException
    {
        List<WebElement> noFilterImage = selUtility.findElements("noFilterImage");
        Assert.assertEquals("verify no filter image is present or not", true, noFilterImage.get(0).isDisplayed());
        List<WebElement> noFilterText = selUtility.findElements("noFilterText");
        Assert.assertEquals("verify error message", "No results", noFilterText.get(0).getText().trim());
        List<WebElement> refineSearch = selUtility.findElements("refineFilterSearchText");
        Assert.assertEquals("verify error message", "Refine the filters", refineSearch.get(0).getText().trim());
    }

    // verify matching text highlighted
    public void verifyMatchingTextHighlighted(String filterValue)
            throws IOException, InterruptedException
    {
        List<WebElement> matchingHighlightedText = selUtility.findElements("highlightedText");
        for (int i = 0; i < matchingHighlightedText.size(); i++)
        {
            String highlightedText = matchingHighlightedText.get(i).getText();
            Assert.assertEquals("Verify Matching highlighted text", filterValue.toLowerCase(),
                    highlightedText.toLowerCase());
            String highlightedTextBGColor = PatientList.getInstance()
                    .getBackgroundColor(matchingHighlightedText.get(i));
            logger.debug(
                    "Filter:verifyMatchingTextHighlighted: matching text highlighted with " + highlightedTextBGColor);
            Assert.assertEquals("Verify Matching highlighted text background color",
                    Constants.ARRIVING_FILTERED_BGCOLOR, highlightedTextBGColor);
        }
    }

    // --------------------------------------------------------------------------------------------
    // filter textbox present along with cross button
    public void filterElementPresent(String columnName)
            throws IOException, InterruptedException
    {
        WebElement filterClearElement = getFilterClearButton(columnName);
        Assert.assertEquals("By default Filter clear button should not be present", false,
                filterClearElement.isDisplayed());

        // Filter clear button is present after setting value in Filter text box
        setFilter(columnName, "test");

        filterClearElement = getFilterClearButton(columnName);
        Assert.assertEquals("Filter clear button should be present after setting value in Filter text box", true,
                filterClearElement.isDisplayed());

        // clear filter
        clearFilter(columnName);
    }

    public int getRowCount()
            throws IOException, InterruptedException
    {
        return selUtility.findElements("allRows").size();
    }

    public WebElement getFilterClearButton(String columnName)
            throws IOException
    {
        String filterClearButton = PropertyFileHelper.getObjectIdentifier("filterClearButton");
        filterClearButton = filterClearButton.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterClearElement = selUtility.findElementbyXpath(filterClearButton);
        return (filterClearElement);
    }

    public int getFilterTextBoxWidth(String columnName)
    {
        String filterTextbox = PropertyFileHelper.getObjectIdentifier("filterTextbox");
        filterTextbox = filterTextbox.replace("REPLACE_COLUMNNAME", columnName);
        WebElement filterTextboxElement = selUtility.findElementbyXpath(filterTextbox);
        WebElement filterTextBoxParent = filterTextboxElement.findElement(By.xpath(".."));
        int filterTextboxWidth = Integer.parseInt(filterTextBoxParent.getAttribute("style").replaceAll("[^0-9]", ""));
        return filterTextboxWidth;
    }

    public int getColumnWidth(String columnName)
            throws IOException, InterruptedException
    {
        int columnWidth = 0;
        List<WebElement> visibleColumnList = selUtility.findElements("visibleColumns");
        for (int i = 0; i < visibleColumnList.size(); i++)
        {
            if ( columnName.equalsIgnoreCase(visibleColumnList.get(i).getText()) )
            {
                columnWidth = Integer.parseInt(visibleColumnList.get(i).getAttribute("style").replaceAll("[^0-9]", ""));
            }
        }
        return columnWidth;
    }

    // this function is used to click on reorder button
    public void clickReorderButton()
            throws IOException, InterruptedException
    {

        List<WebElement> columnReorderButton = selUtility.findElements("columnReorderButton");
        if ( columnReorderButton.size() == 0 )
        {
            List<WebElement> reorderButton = selUtility.findElements("reorderbutton");
            reorderButton.get(0).click();
        }

    }

    // ArrivingList FilterTextBox functionality

    // check Arriving list filter textbox is present
    public boolean isArrivingListFilterTextBoxPresent()
            throws IOException, InterruptedException
    {
        String xpath = PropertyFileHelper.getObjectIdentifier("ArrivingListFilterTextBox");
        return selUtility.findElementbyXpath(xpath).isDisplayed();

    }

    // This functions is used to set text for arrivinglist filter text box
    public void setArrivingListFilter(String filtertext)
            throws IOException, InterruptedException
    {
        Thread.sleep(1000);
        String arrListFilterTextbox = PropertyFileHelper.getObjectIdentifier("ArrivingListFilterTextBox");

        WebElement arrListFilterTextboxElement = selUtility.findElementbyXpath(arrListFilterTextbox);

        Thread.sleep(1000);

        logger.debug("Filter:setFilter: set the Filter with text " + filtertext);

        arrListFilterTextboxElement.clear();
        arrListFilterTextboxElement.sendKeys(filtertext);
        Thread.sleep(2000);
        withFilterCardCount = Filter.getInstance().getCardCount();
    }

    // This function is used to clear arrivinglist filter text box
    public void clearArrivingListFilter()
            throws IOException
    {
        String arrivingListFilterClearButton = PropertyFileHelper.getObjectIdentifier("ArrivingListClearFilterButton");

        // click on X to remove filter
        WebElement arrivingListFilterClearElement = selUtility.findElementbyXpath(arrivingListFilterClearButton);
        logger.debug("Filter:clearFilter: clear filter");
        arrivingListFilterClearElement.click();
    }

    /**
     * This function will check if clear button is present on arriving list
     * filter text box
     * 
     * @return true if the ArrivingList Filter Clear Button is Present, false
     *         otherwise
     * @throws IOException
     * @throws InterruptedException
     */
    public boolean isArrivingListFilterClearButtonPresent()
            throws IOException, InterruptedException
    {
        String arrivingListfilterClearButton = PropertyFileHelper.getObjectIdentifier("ArrivingListClearFilterButton");

        WebElement filterClearButtonElement = selUtility.findElementbyXpath(arrivingListfilterClearButton);
        logger.debug(" filter clear button present for column " + filterClearButtonElement.isDisplayed());
        return filterClearButtonElement.isDisplayed();

    }

    // This function will check if arriving list is filtered
    public boolean isArrivingListFiltered(String filtertext)
            throws Exception
    {

        String arrivingCardPath = "//div[@class='arrival-patient-list scroll-section-position']//div[contains(@id,'arrivingbed')]";
        List<WebElement> arrivingCardItems = SeleniumUtility.getInstance().findElementsByXpath(arrivingCardPath);
        if ( arrivingCardItems.size() == 0 )
        {
            logger.debug("0 cards displayed with matching criteria");
            return false;

        }

        for (int i = 0; i < arrivingCardItems.size(); i++)
        {
            if ( !(arrivingCardItems.get(i).getText().toLowerCase().contains(filtertext.trim().toLowerCase())) )
            {

                logger.debug("contents of card  at position" + i + "doesn not have any data");
                logger.debug("card content" + arrivingCardItems.get(i).getText());
                logger.debug("filter text =" + filtertext);
                Thread.sleep(5000);
                return false;

            }
        }
        return true;
    }

    public int verifyWithFilterCardCount(String filtertext)
            throws InterruptedException, IOException
    {
        Thread.sleep(5000);
        String arrListFilterTextbox = PropertyFileHelper.getObjectIdentifier("ArrivingListFilterTextBox");

        WebElement arrListFilterTextboxElement = selUtility.findElementbyXpath(arrListFilterTextbox);

        Thread.sleep(5000);

        arrListFilterTextboxElement.clear();
        arrListFilterTextboxElement.sendKeys(filtertext);
        withFilterCardCount = Filter.getInstance().getCardCount();
        return withFilterCardCount;
    }

    // This function will get text from arriving list filter text box
    public String getArrivingListFilterTextBoxText()
            throws IOException
    {
        String arrivingListFilterTextbox = PropertyFileHelper.getObjectIdentifier("ArrivingListFilterTextBox");

        WebElement filterTextboxElement = selUtility.findElementbyXpath(arrivingListFilterTextbox);
        String filtertext = filterTextboxElement.getText();
        logger.debug("Filter:getFilterTextBoxText: get filter text box text " + filtertext);
        return filtertext;
    }

    // This function will verify if all cards are present without any filter
    // applied
    public void verifyAllCardsPresent()
            throws IOException, InterruptedException
    {

        int withoutFilterCardCount = getCardCount();
        Assert.assertTrue("verify filter is removed by comparing card count after filter=" + withFilterCardCount
                + "   without filter=" + withoutFilterCardCount, withoutFilterCardCount > withFilterCardCount);

    }

    public int getCardCount()
            throws IOException, InterruptedException
    {
        return selUtility.findElements("allcards").size();
    }

    // This function will get no filter message and image
    public void noFilterErrorMessageForArrivingListFilter()
            throws IOException, InterruptedException
    {
        Thread.sleep(5000);
        String xPath1 = PropertyFileHelper.getObjectIdentifier("NoArrivingListFilterImage");
        boolean noFilterImage = selUtility.findElementbyXpath(xPath1).isDisplayed();
        Assert.assertEquals("verify no filter image is present or not", true, noFilterImage);
        String xPath2 = PropertyFileHelper.getObjectIdentifier("NoArrivingListFilterText");
        WebElement noFilterText = selUtility.findElementbyXpath(xPath2);
        Assert.assertEquals("verify error message", "No results", noFilterText.getText().trim());

    }
}
