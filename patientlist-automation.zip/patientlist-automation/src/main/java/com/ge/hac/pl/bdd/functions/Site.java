/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.functions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.Constants;
import com.ge.hac.pl.bdd.utility.PropertyFileHelper;
import com.ge.hac.pl.bdd.utility.SeleniumUtility;

public class Site
{
    private static Logger   logger   = Logger.getLogger(Site.class);
    private SeleniumUtility selUtility;
    private static Site     instance = null;

    private Site()
    {
        try
        {
            selUtility = SeleniumUtility.getInstance(); // assigning to driver to seleniumUtility class
        }
        catch (Exception e)
        {
            logger.error("Site() - error initializing web browser.", e);
        }

    }

    public static Site getInstance()
    {
        if ( instance == null )
        {
            instance = new Site();
        }
        return instance;
    }

    public static void closeInstance()
    {
        instance = null;
    }

    // This function click on Add site Drop down.
    public void clickAddSite()
            throws IOException, InterruptedException
    {
        selUtility.elementClick("add_site");
    }

    /*
     * This function verify given site is present in Add site Dropdown or not.
     * Assuming that Add site dropdown is already clicked by using clickAddSite() function
     */

    public boolean verifySiteInAddSiteDropdown(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> SiteList = selUtility.findElements("site_dropdown");
        for (int i = 0; i < SiteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(SiteList.get(i).getText().trim()) )
            {
                // if site name is found then exit from for loop
                bFound = true;
                break;
            }
        }
        return bFound;
    }

    /**
     * @param expectedSiteList
     * @return
     * @throws InterruptedException
     * @throws IOException
     */
    public boolean verifySiteList(List<String> expectedSiteList)
            throws IOException, InterruptedException
    {
        List<WebElement> SiteList = selUtility.findElements("site_dropdown");
        List<String> actualSiteList = new ArrayList<String>();
        for (int i = 0; i < SiteList.size(); i++)
        {
            actualSiteList.add(SiteList.get(i).getText().trim());
        }

        return CommonUtility.compareLists(actualSiteList, expectedSiteList);
    }

    /*
     * This function is used to add site to sites tab.
     * Assuming that Add site dropdown is already clicked by using clickAddSite() function
     */

    public boolean AddSite(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> siteList = selUtility.findElements("site_dropdown");

        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                bFound = true;
                // span tag is not clickable
                // move one level up to get <a> tag
                WebElement siteToSelect = siteList.get(i).findElement(By.xpath(".."));
                siteToSelect.click();
                break;
            }
        }
        return bFound;

    }

    /*
     * add All site from Add Site dropdown
     * Return name of the added sites
     * Assuming that Add site dropdown is already clicked by using click_AddSite() function
     */
    public String[] addAllSite()
            throws Exception
    {

        List<WebElement> siteList = selUtility.findElements("site_dropdown");
        String[] addedSite = new String[siteList.size()];
        for (int i = 0; i < siteList.size(); i++)
        {
            addedSite[i] = siteList.get(i).getText();
            siteList.get(i).click();
        }
        return (addedSite);
    }

    /* verify site on sites tab */
    public boolean verifyActiveSite(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        String selectedSite = selUtility.get_text("add_site");

        // use trim to remove spaces
        if ( siteName.equalsIgnoreCase(selectedSite.trim()) )
        {
            // if site name is found then exit from for loop
            bFound = true;
        }

        return bFound;
    }

    /* verify active site on sites tab */
    public boolean verifyActiveSiteOnSitesTab(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        Thread.sleep(3000);
        List<WebElement> siteList = selUtility.findElements("active_site");
        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                // if site name is found then exit from for loop
                bFound = true;
                break;
            }
        }
        return bFound;
    }

    /* verify department on department tab */
    public boolean verifyDepartment(String DeptName)
            throws IOException, InterruptedException
    {
        boolean bFound = false;
        openDepartmentDropDown();
        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");

        for (int i = 0; i < deptList.size(); i++)
        {
            // use trim to remove spaces
            if ( DeptName.equalsIgnoreCase(deptList.get(i).getText().trim()) )
            {
                bFound = true;
                // if department name is found then exit from for loop
                break;
            }
        }
        return bFound;
    }

    /**
     * @param expectedDeptList
     * @return
     */
    public boolean verifyDeptList(List<String> expectedDeptList)
            throws IOException, InterruptedException
    {
        List<String> actualDeptList = new ArrayList<String>();

        openDepartmentDropDown();

        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");
        for (int i = 0; i < deptList.size(); i++)
        {
            actualDeptList.add(deptList.get(i).getText().trim());
        }

        return CommonUtility.compareLists(actualDeptList, expectedDeptList);

    }

    /* verify active Department on Department tab */
    /* verify active Department on Department tab */
    public boolean verifyActiveDepartment(String DeptName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> siteList = selUtility.findElements("active_department");

        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( DeptName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                // if department name is found then exit from for loop
                bFound = true;
                break;
            }
        }
        return bFound;
    }

    /* close site from sites tab */
    public boolean closeSiteFromSitestab(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> siteList = selUtility.findElements("sites_from_sites_tab");
        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                bFound = true;
                // $x("//ul[@class='nav nav-']//li//a[@class='department-tab-color']//span[text()='ASC']/following-sibling::img")
                String siteTab = PropertyFileHelper.getObjectIdentifier("sites_from_sites_tab");
                siteTab = siteTab + "[text()=" + "\'" + siteName + "\'" + "]/following-sibling::img";
                System.out.println("x path for delete =" + siteTab);
                // click on X to remove site;
                WebElement btnDelete = selUtility.findElementbyXpath(siteTab);
                btnDelete.click();
                break;
            }
        }
        return bFound;
    }

    /* close All site from sites tab */
    public String[] closeAllSiteFromSitestab(String excludeSiteName)
            throws IOException, InterruptedException
    {

        List<WebElement> siteList = selUtility.findElements("sites_from_sites_tab");
        String[] removedSite = new String[siteList.size()];
        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( excludeSiteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                // dont close specified site
            }
            else
            {
                removedSite[i] = siteList.get(i).getText();
                closeSiteFromSitestab(siteList.get(i).getText());

            }
        }
        return (removedSite);
    }

    // select Department on department tab

    public boolean selectDepartment(String deptName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        // open department dropdown
        openDepartmentDropDown();
        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");
        for (int i = 0; i < deptList.size(); i++)
        {
            // use trim to remove spaces
            if ( deptName.equalsIgnoreCase(deptList.get(i).getText().trim()) )
            {
                // if department name is found then exit from for loop
                deptList.get(i).click();
                Thread.sleep(3000);
                bFound = true;
                break;
            }
        }
        return bFound;
    }

    // select site on sites tab

    public boolean selectSiteOnSitesTab(String siteName)
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> siteList = selUtility.findElements("sites_from_sites_tab");
        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                // if department name is found then exit from for loop
                siteList.get(i).click();
                Thread.sleep(3000);
                bFound = true;
                break;
            }
        }
        return bFound;
    }

    // verify that Add Site Dropdown is Disabled or not
    public boolean verifyAddSiteDropdownDisabled()
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> addSiteDisabled = selUtility.findElements("add_site_disabled");
        if ( 1 == addSiteDisabled.size() )
        {
            bFound = true;
        }
        return bFound;
    }

    // verify that Add Site Dropdown is Enabled or not
    public boolean verifyAddSiteDropdownEnabled()
            throws IOException, InterruptedException
    {

        boolean bFound = false;
        List<WebElement> addSiteEnabled = selUtility.findElements("add_site");
        if ( 1 == addSiteEnabled.size() )
        {
            bFound = true;
        }
        return bFound;
    }

    /* check that user can cLose site from site tab or not */
    public boolean canCloseSite(String siteName)
            throws IOException, InterruptedException
    {

        List<WebElement> siteList = selUtility.findElements("sites_from_sites_tab");
        for (int i = 0; i < siteList.size(); i++)
        {
            // use trim to remove spaces
            if ( siteName.equalsIgnoreCase(siteList.get(i).getText().trim()) )
            {
                // $x("//ul[@class='nav nav-']//li//a[@class='department-tab-color']//span[text()='ASC']/following-sibling::img")
                String siteTab = PropertyFileHelper.getObjectIdentifier("sites_from_sites_tab");
                siteTab = siteTab + "[text()=" + "\'" + siteName + "\'"
                        + "]/following-sibling::img[@class='department-img-cancel ng-hide']";
                System.out.println("x path for delete =" + siteTab);
                // click on X to remove site;
                WebElement btnDelete = selUtility.findElementbyXpath(siteTab);
                if ( !(null == btnDelete) )
                {
                    return true;
                }
            }
        }
        return false;
    }

    // return the number of department loaded on dept tab
    public int getNoOfDisplayedDept()
            throws IOException, InterruptedException
    {
        List<WebElement> siteList = selUtility.findElements("dept_from_depts_tab");
        if ( siteList.size() == 0 )
        {
            Thread.sleep(9000);
            siteList = selUtility.findElements("dept_from_depts_tab");
        }
        return siteList.size();
    }

    // get text of Add a site dropdown
    public String getAddSiteDropdownText()
            throws IOException
    {
        return selUtility.get_text("add_site");
    }

    // get list of all sites from Add a site dropdown
    public List<String> getAllSites()
            throws IOException, InterruptedException
    {
        List<WebElement> SiteList = selUtility.findElements("site_dropdown");
        List<String> SiteNameList = new ArrayList<String>();
        for (int i = 0; i < SiteList.size(); i++)
        {
            if ( !("".equals(SiteList.get(i).getText().trim())) )
            {
                SiteNameList.add(SiteList.get(i).getText().trim());
            }
        }

        return SiteNameList;
    }

    // verify search button enabled or not
    public String verifySerchButtonEnabled()
            throws IOException, InterruptedException
    {
        String bFound = "false";
        List<WebElement> searchButtonEnabled = selUtility.findElements("search_button");
        try
        {
            bFound = searchButtonEnabled.get(0).getAttribute("disabled");
        }
        catch (Exception e)
        {
            logger.error("Exception in com.ge.hac.pl.bdd.functions.Site.verifySerchButtonEnabled()", e);
        }
        return bFound;
    }

    public boolean verifyResetSortButton()
            throws IOException, InterruptedException
    {

        return selUtility.elementDisplayedByXpath("resetDefaultSort");

    }

    // click on from or to date label
    public void ClickOnDateLabel(String dateControl)
            throws IOException
    {
        switch (dateControl)
        {
            case "fromLabel":
                selUtility.elementClick("fromDateLabel");
                break;
            case "toLabel":
                selUtility.elementClick("toDateLabel");
                break;
        }

    }

    // verify date picker open or not
    public boolean verifyCalendarOpen()
            throws IOException, InterruptedException
    {

        return selUtility.elementDisplayedByXpath("calendarmonthyear");

    }

    // departments should be display in alphabetically order
    public void verifyDepartmentOrder()
            throws IOException, InterruptedException

    {
        // Create the sorted set
        SortedSet<String> deptSortedSet = new TreeSet<>();
        openDepartmentDropDown();
        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");
        // read department and sort it
        for (int i = 0; i < deptList.size(); i++)
        {
            deptSortedSet.add(deptList.get(i).getText());

        }
        // verify order in set and on UI
        Iterator<String> dept = deptSortedSet.iterator();
        int j = 0;
        while (dept.hasNext())
        {
            // Get element
            Object sortedDept = dept.next();
            Assert.assertEquals("Verify deprtment odrder", sortedDept.toString(), deptList.get(j).getText());
            j++;
        }
        closeDepartmentDropDown();
    }

    public boolean verifyDepartmentDropDownIndication()
            throws IOException
    {
        WebElement DepartmentDropdownButton = selUtility.getElementByXPath("department_DropDown_button");
        return DepartmentDropdownButton.isDisplayed();
    }

    // verifyDepartmentInDropdown
    public boolean verifyDepartmentInDropdown(String DeptName)
            throws IOException, InterruptedException
    {
        boolean bFound = false;
        openDepartmentDropDown();
        List<WebElement> deptList = selUtility.findElements("department_DropDown");

        for (int i = 0; i < deptList.size(); i++)
        {
            // use trim to remove spaces
            if ( DeptName.equalsIgnoreCase(deptList.get(i).getText().trim()) )
            {
                bFound = true;
                // if department name is found then exit from for loop
                break;
            }
        }
        closeDepartmentDropDown();
        return bFound;
    }

    public boolean openDepartmentDropDown()
            throws IOException
    {
        boolean isDropDownOpened = false;
        WebElement DepartmentDropdownButton = selUtility.getElementByXPath("department_DropDown_button");

        if ( DepartmentDropdownButton.isDisplayed() )
        {
            WebElement DepartmentDropdown = selUtility.getElementByXPath("department_DropDown");
            if ( !DepartmentDropdown.isDisplayed() )
            {

                DepartmentDropdownButton.click();
            }
            isDropDownOpened = true;
        }
        return isDropDownOpened;
    }

    public boolean closeDepartmentDropDown()
            throws IOException
    {
        boolean isDropDownClosed = false;
        WebElement DepartmentDropdownButton = selUtility.getElementByXPath("department_DropDown_button");

        if ( DepartmentDropdownButton.isDisplayed() )
        {
            WebElement DepartmentDropdown = selUtility.getElementByXPath("department_DropDown");
            if ( DepartmentDropdown.isDisplayed() )
            {

                DepartmentDropdownButton.click();
            }
            isDropDownClosed = true;
        }
        return isDropDownClosed;
    }

    public String getSelectedSiteInDropDown()
            throws IOException, InterruptedException
    {

        return selUtility.get_text("selected_site_In_dropdown");

    }

    /**
     * @throws IOException
     * @throws InterruptedException
     * 
     */
    public String getDepartmentOrder()
            throws IOException, InterruptedException
    {

        openDepartmentDropDown();
        List<WebElement> deptList = selUtility.findElements("dept_from_depts_tab");
        String deptListOdr = deptList.get(0).getText().trim();
        for (int i = 1; i < deptList.size(); i++)
        {
            deptListOdr = deptListOdr + "," + deptList.get(i).getText().trim();

        }
        closeDepartmentDropDown();
        return deptListOdr;

    }

    public String geToggleViewButtonIconName()
            throws IOException

    {
        return selUtility.getElementByXPath("ToggleViewIcon").getAttribute("class");
    }

    public void clickOnToggleViewButton()
            throws IOException
    {
        selUtility.elementClick("ToggleView");
    }

    public boolean isAllTabDisplayed()
            throws IOException, InterruptedException
    {
        return Site.getInstance().verifyDepartment(Constants.ALL_TAB_NAME);

    }

    public boolean isButtonDisplayed(String buttonName)
            throws IOException
    {
        return selUtility.elementDisplayedByXpath(buttonName);

    }

    public String getDetailsByRow(String xpath, int patientcaseno)
            throws IOException, InterruptedException
    {
        List<WebElement> patientsDataList = selUtility.findElements(xpath);
        String actualData = null;
        for (int i = 0; i < patientsDataList.size(); i++)
        {
            // use trim to remove spaces
            if ( i == patientcaseno )
            {
                actualData = patientsDataList.get(patientcaseno).getText().trim();
                logger.debug("Actual property displayed on cards details of Bed layout :" + actualData);
                // if data is found then exit from for loop
                break;
            }
        }

        return actualData;
    }

    public String getDetails(String data, String xpath)
            throws IOException, InterruptedException
    {
        List<WebElement> patientsDataList = selUtility.findElements(xpath);
        String actualData = null;
        for (int i = 0; i < patientsDataList.size(); i++)
        {
            // use trim to remove spaces
            if ( data.equalsIgnoreCase(patientsDataList.get(i).getText().trim()) )
            {
                actualData = patientsDataList.get(i).getText().trim();
                logger.debug("Actual property displayed on cards details of Bed layout :" + actualData);
                // if data is found then exit from for loop
                break;
            }
        }

        return actualData;
    }
	public boolean isDisplayed(String xpath, int patientcaseno) throws IOException, InterruptedException {
		List<WebElement> patientsDataList = selUtility.findElements(xpath);
		boolean display = false;
		for (int i = 0; i < patientsDataList.size(); i++)
		{
			if (i == patientcaseno && patientsDataList.get(patientcaseno) != null && patientsDataList.get(patientcaseno).isDisplayed()) 
				{
					display= true;
					break;
				} 
	
			}
		return display;
	}
	
	 public String getStaffIndicatorDetailsByRow(String xpath)
	            throws IOException, InterruptedException
	    {
		 List<WebElement> patientsDataList = selUtility.findElements(xpath);
	        String actualData = null;
	        if(patientsDataList.size()==0)
	        {
	        	return actualData = "";
	        }
	        else
	        {
	        for (int i = 0; i < patientsDataList.size(); i++)
	        {	           
	                actualData = PatientList.getInstance().getBackgroundColor(patientsDataList.get(i));
	                logger.debug("Actual property displayed on cards details of Bed layout :" + actualData);
	                
	        }
	        }

	        return actualData;
	    }
}
