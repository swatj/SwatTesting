/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.functions;

import com.ge.hac.pl.bdd.utility.PropertyFileHelper;

/**
 * @author pandharinathj
 *
 */
public class PopoverCard extends Bed
{

    public PopoverCard()
    {
        super();

        initializeBed(PropertyFileHelper.getObjectIdentifier("Bed_Popover"));
    }

}
