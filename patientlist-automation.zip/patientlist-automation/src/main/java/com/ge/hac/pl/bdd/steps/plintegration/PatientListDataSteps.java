/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

/**
 * @author pandharinathj
 * 
 */
public class PatientListDataSteps
{
    //TODO
    @Then("verify the patient's data in the Patient list")
    public void verifyPLData(@Named("Care phase") String carePhaseValue, @Named("OR") String ORValue,
            @Named("Patient ID") String patientIDValue, @Named("Patient") String patientValue,
            @Named("Sched time") String schedTimeValue, @Named("Visit ID") String visitIdValue,
            @Named("Surgeon") String surgeonValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.CARE_PHASE_COLUMN);
        headerNames.add(Constants.OR_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        headerNames.add(Constants.VISIT_ID_COLUMN);
        headerNames.add(Constants.SURGEON_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);

        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            PatientListData.getInstance().verifyOR(patientIDRowNumber, headerNames, ORValue);
            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
            PatientListData.getInstance().verifyCarePhase(patientIDRowNumber, headerNames, carePhaseValue);
            PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);
            PatientListData.getInstance().verifyVisitID(patientIDRowNumber, headerNames, visitIdValue);
            PatientListData.getInstance().verifySurgeon(patientIDRowNumber, headerNames, surgeonValue);
        }

    }

}
