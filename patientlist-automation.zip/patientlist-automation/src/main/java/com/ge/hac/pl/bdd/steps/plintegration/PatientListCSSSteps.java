/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.steps.plintegration;

import java.io.IOException;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.Site;
import com.ge.hac.pl.bdd.utility.Constants;

public class PatientListCSSSteps
{

    @Then("selected site background should be light blue and text should be in white color")
    public void verifySelectedSiteBGandTextColor()
            throws IOException, InterruptedException
    {
        // light blue color is #15b0ef
        Assert.assertEquals("verify Selected site background color", Constants.LIGHTBLUE_COLOR,
                PatientList.getInstance().getBackgroundColorOfActiveSite());

    }

    @Then("Site dropdown,From date,To date field ,search button, department tab, column resize button and column configuration button should be in one container with gray background")
    public void verifyContainerAndColor()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Verify Site dropdown is present in specified container",
                Constants.SITE_DEPARTMENT_CONTAINER, PatientList.getInstance().getContainer("add_site", 1));

        Assert.assertEquals("Verify from date textbox is present in specified container",
                Constants.DATE_SEARCH_CONTAINER, PatientList.getInstance().getContainer("fromDateTextbox", 1));

        Assert.assertEquals("Verify from date calendar is present in specified container",
                Constants.DATE_SEARCH_CONTAINER, PatientList.getInstance().getContainer("icon_fromdate", 1));

        Assert.assertEquals("Verify to date textbox is present in specified container", Constants.DATE_SEARCH_CONTAINER,
                PatientList.getInstance().getContainer("toDateTextbox", 1));

        Assert.assertEquals("Verify to date calendar is present in specified container",
                Constants.DATE_SEARCH_CONTAINER, PatientList.getInstance().getContainer("icon_todate", 1));

        Assert.assertEquals("Verify search button is present in specified container", Constants.DATE_SEARCH_CONTAINER,
                PatientList.getInstance().getContainer("search_button", 0));

        Assert.assertEquals("Verify Department tab is present in specified container",
                Constants.SITE_DEPARTMENT_CONTAINER, PatientList.getInstance().getContainer("dept_from_depts_tab", 3));

        Assert.assertEquals("Verify column resize button is present in specified container", Constants.BUTTON_CONTAINER,
                PatientList.getInstance().getContainer("reorderbutton", 2));

        Assert.assertEquals("Verify column configuration button is present in specified container",
                Constants.BUTTON_CONTAINER, PatientList.getInstance().getContainer("togglebutton", 3));

        // container with white background
        Assert.assertEquals("Verify container with gray background", Constants.GRAY_COLOR,
                PatientList.getInstance().getBackgroundColorOfHeaderContainer());

    }

    @Then("the patient list grid should be in different container with white background")
    public void verifyDeptAndPatListInSameContainer()
            throws IOException, InterruptedException
    {
        Assert.assertEquals("Verify PatientList grid is present in specified container", Constants.DEPARTMENT_CONTAINER,
                PatientList.getInstance().getContainer("patientListTable", 2));
        // container with white background
        Assert.assertEquals("Verify container with white background", Constants.WHITE_COLOR,
                PatientList.getInstance().getBGColorOfDeptPatListContainer());

    }

    @Then("department tab should be of same minimum width=100 and with text aligned center")
    public void verifyDepartmentTabWidth()
            throws IOException, InterruptedException
    {
        PatientList.getInstance().verifyDepartmentWidthAndText(Constants.DEPARTMENT_WIDTH,
                Constants.DEPARTMENT_TEXTALIGN);
    }

    @Then("logged in user name should display with GE Sans font and  with color #D7D7D7 ,user context button should display with  #595959 color")
    public void verifyUserContextButtonColor()
            throws IOException, InterruptedException
    {

        Assert.assertEquals("logged in user name should display with color #D7D7D7", "#d7d7d7",
                PatientList.getInstance().getTextColorOfLoggedInUserName());
        Assert.assertEquals("user context button should display with  #595959 color", "#595959",
                PatientList.getInstance().getBackgroundColorOfLoggedInUserName());
        Assert.assertEquals("logged in user name should display with GE Sans font", "GE Sans",
                PatientList.getInstance().getFontOfLoggedInUserName());
    }
    
    @Then("the color indicator for departments")
    public void colorIndicator(@Named("deptType") String deptType)
            throws Exception
    {
    	PatientList.getInstance().verifyDeptColor(deptType);
    }
}
