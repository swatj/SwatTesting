/*
 * Copyright (c) 2015 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.steps.plintegration;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

import com.ge.hac.pl.bdd.functions.Filter;
import com.ge.hac.pl.bdd.functions.PatientList;
import com.ge.hac.pl.bdd.functions.PatientListData;
import com.ge.hac.pl.bdd.utility.Constants;

/**
 * @author pandharinathj
 * 
 */
public class NewColumnsSteps
{
    @Then("verify the patient's below data in the Patient list data")
    public void verifyPLData(@Named("OR") String ORValue, @Named("Patient ID") String patientIDValue,
            @Named("Patient") String patientValue, @Named("Sched time") String schedTimeValue,
            @Named("Surgeon") String surgeonValue, @Named("Postop") String postopValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.OR_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        headerNames.add(Constants.SCHED_TIME_COLUMN);
        headerNames.add(Constants.SURGEON_COLUMN);
        headerNames.add(Constants.POST_OP_COLUMN);

        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().clearAllFilter();
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            PatientListData.getInstance().verifyOR(patientIDRowNumber, headerNames, ORValue);
            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);
            PatientListData.getInstance().verifySchedTime(patientIDRowNumber, headerNames, schedTimeValue);
            PatientListData.getInstance().verifySurgeon(patientIDRowNumber, headerNames, surgeonValue);
            PatientListData.getInstance().verifyPostop(patientIDRowNumber, headerNames, postopValue);

        }

    }

    @When("user <select> DOB and Gender from column pool")
    public void AddRemoveDOBAndGenderColumn(@Named("select") String isColumnSelected)
            throws Exception
    {
        if ( "true".equalsIgnoreCase(isColumnSelected) )
        {
            PatientList.getInstance().addColumnToColumnList(Constants.DOB_COLUMN);
            PatientList.getInstance().addColumnToColumnList(Constants.GENDER_COLUMN);
        }
        else
        {
            PatientList.getInstance().removeColumnFromColumnList(Constants.DOB_COLUMN);
            PatientList.getInstance().removeColumnFromColumnList(Constants.GENDER_COLUMN);
        }
    }

    @Then("verify the patient column show DOB and Gender for patient When DOB and Gender column selected and vice versa")
    public void verifyDOBAndGender(@Named("Patient ID") String patientIDValue, @Named("Patient") String patientValue)
            throws Exception
    {
        List<String> headerNames = new ArrayList<String>();
        headerNames.add(Constants.PATIENT_ID_COLUMN);
        headerNames.add(Constants.PATIENT_COLUMN);
        // make required column visible
        PatientListData.getInstance().makeColumnVisible(headerNames);
        Filter.getInstance().setFilter(Constants.PATIENT_ID_COLUMN, patientIDValue);
        int patientIDRowNumber = PatientListData.getInstance().getPatientIDRow(headerNames, patientIDValue);

        if ( patientIDRowNumber == 0 )
        {
            Filter.getInstance().clearAllFilter();
            Assert.fail("Verify Patient ID=" + patientIDValue + " is not displayed on patient list");

        }
        else
        {
            PatientListData.getInstance().verifyPatient(patientIDRowNumber, headerNames, patientValue);

        }
        Filter.getInstance().clearAllFilter();
    }

}
