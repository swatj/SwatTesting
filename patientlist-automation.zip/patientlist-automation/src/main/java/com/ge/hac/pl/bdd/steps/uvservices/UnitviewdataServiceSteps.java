package com.ge.hac.pl.bdd.steps.uvservices;

import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.junit.Assert;

import com.ge.hac.ca.web.resourceview.model.CareCaseInfo;
import com.ge.hac.ca.web.resourceview.model.UnitViewData;
import com.ge.hac.pl.bdd.utility.CommonUtility;
import com.ge.hac.pl.bdd.utility.RestParams;
import com.ge.hac.pl.bdd.utility.ServiceHandler;

/**
 * @author 502391213
 *        
 */
public class UnitviewdataServiceSteps {
	 private static Logger                        logger = Logger.getLogger(ConfigurationServiceSteps.class);
	    private static int                           getServiceResponse;
	    private static String                        getResponseString;
	    private static UnitViewData                  getResponseEntity;

	    private static int                           postServiceResponse;

	    @When("the service.unitViewData url is invoked: $dataTable")
	    public static void invokeGetRestEndpoint(ExamplesTable dataTable)
	    {
	        RestParams restParams = ServiceHandler.extractRestParamsFromTable(dataTable);

	        Response response = ServiceHandler.invokeAndGetResponse(restParams.getRequestType(),
	                restParams.getRestEndpoint(), restParams.getQueryParams(), restParams.getPostEntity());

	        UnitviewdataServiceSteps.getResponseString = response.readEntity(String.class);
	        UnitviewdataServiceSteps.getServiceResponse = response.getStatus();

	        Assert.assertEquals("Response is OK", HttpResponseCodes.SC_OK, UnitviewdataServiceSteps.getServiceResponse);
	    }

	    @Then("the service.unitViewData returns $casesCount Cases")
	    public static void verifyDepartmentCount(String departmentCount)
	    {
	        /*
	         * Populate the response entity of type DepartmentLayoutConfiguration.
	         * This can be used by other methods here too.
	         */
	    	UnitviewdataServiceSteps.getResponseEntity = (UnitViewData) CommonUtility.getObjectFromJson(
	                CommonUtility.getMapperObject(), getResponseString, UnitViewData.class);

	        Assert.assertEquals("No Of Arriving list Cases matches", Integer.parseInt(departmentCount), getResponseEntity
	                .getArrivingList().size());

	    }

	    @Then("verify that service.unitViewData returns Cases Details: $dataTable")
	    public static void verifyDeaprtmentAttributes(ExamplesTable dataTable)
	    {
	        int iter = 0;
	        UnitViewData d = UnitviewdataServiceSteps.getResponseEntity;
	        for (Map<String, String> row : dataTable.getRows())
	        {

	        	CareCaseInfo dl = d.getArrivingList().get(iter);
	            String frstname = row.get("FName");
	            String lstname = row.get("LName");
	            String sex = row.get("Sex");
            
	            Assert.assertTrue("Patient First Name", frstname.equalsIgnoreCase(dl.getPatient().getFirstname()));
	            Assert.assertTrue("Patient Last Name", lstname.equalsIgnoreCase(dl.getPatient().getLastname()));
	            Assert.assertTrue("Patient Sex", sex.equalsIgnoreCase(dl.getPatient().getGender()));
	            iter++;
	        }
	    }



}
