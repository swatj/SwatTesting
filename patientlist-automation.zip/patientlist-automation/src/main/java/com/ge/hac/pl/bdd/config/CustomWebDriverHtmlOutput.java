/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Pandharinath     17-Mar-2015         
 */
package com.ge.hac.pl.bdd.config;

import java.io.PrintStream;
import java.util.Properties;

import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.reporters.FilePrintStreamFactory;
import org.jbehave.core.reporters.HtmlOutput;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;

public class CustomWebDriverHtmlOutput extends HtmlOutput
{

    public static final org.jbehave.core.reporters.Format MY_WEB_DRIVER_HTML = new WebDriverHtmlFormat();
    public static PrintStream                             HTMLWriter         = null;

    public CustomWebDriverHtmlOutput(PrintStream output, Keywords keywords)
    {

        super(output, failedPatternProperties(), keywords, true);
        CustomWebDriverHtmlOutput.HTMLWriter = output;

    }

    /**
     * 
     */

    private static Properties failedPatternProperties()
    {
        Properties properties = new Properties();

        return properties;
    }

    private static class WebDriverHtmlFormat extends org.jbehave.core.reporters.Format
    {

        public WebDriverHtmlFormat()
        {
            super("HTML");

        }

        @Override
        public StoryReporter createStoryReporter(FilePrintStreamFactory factory,
                StoryReporterBuilder storyReporterBuilder)
        {

            factory.useConfiguration(storyReporterBuilder.fileConfiguration("html"));
            return new CustomWebDriverHtmlOutput(factory.createPrintStream(), storyReporterBuilder.keywords());

        }
    }

}
