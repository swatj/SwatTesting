/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Manjunatha.H     22-April-2016         
 */

package com.ge.hac.pl.bdd.steps.uvintegration;

import java.io.IOException;
import java.util.Map;

import org.junit.Assert;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.model.ExamplesTable;
import org.openqa.selenium.WebDriverException;

import com.ge.hac.pl.bdd.functions.Card;
import com.ge.hac.pl.bdd.functions.GridPanel;
import com.ge.hac.pl.bdd.functions.Site;

public class GridPanelSteps

{

	public String bedNameXpath = "BedLayout_BedName";
	public String patientNameXpath = "BedLayout_PatientName";
	public String patientIdXpath = "BedLayout_PatientId";
	public String patientSexXpath = "BedLayout_PateintSex";
	public String patientDOBXpath = "BedLayout_PatientDOB";
	public String patientAgeXpath = "BedLayout_PatientAge";
	public String patientProcedureXpath = "BedLayout_PatientProcedure";
	public String patientAdmissionReasonXpath = "BedLayout_PatientAdmissionReason";
	public String patientAcuityInformationXpath = "BedLayout_PatientAcuityInformation";
	public String patientSurgeonXpath = "BedLayout_PatientSurgeon";
	public String patientIntensivistsXpath = "BedLayout_PatientIntensivists";
	public String patientNurseXpath = "BedLayout_PatientNurse";

	@Then("the grid panel should display grid size configured by using configurator")
	public void verifyGridPanelSize(
			@Named("gridSizeByNoOfRows") String gridSizeByNoOfRows,
			@Named("gridSizeByNoOfCols") String gridSizeByNoOfCols)
			throws Exception {
		int noOfRows = GridPanel.getInstance().getGridSizeByNoOfRows();		
		int noOfCells = GridPanel.getInstance().getGridSizeByNoOfCells();
		int noColumns = noOfCells / noOfRows;

		Assert.assertEquals("Verification failed:No of expected rows '"	+ gridSizeByNoOfRows+ "' configured is not equal to actual rows '" + noOfRows,noOfRows, Integer.parseInt(gridSizeByNoOfRows));
		Assert.assertEquals("Verification failed:No of expected columns '"+ gridSizeByNoOfCols+ "' configured is not equal to actual rows '" + noColumns,noColumns, Integer.parseInt(gridSizeByNoOfCols));

	}
	

	@Then("the grid panel should display card content in beds layout:$dataTable")
	public void verifyCardContentOnBedLayout(ExamplesTable dataTable)
			throws IOException, InterruptedException

	{
		for (Map<String, String> row : dataTable.getRows()) {
			String patientName = row.get("patientName");
			String actualPatientName = Site.getInstance().getDetails(patientName, patientNameXpath);

			String patientID = row.get("patientID");
			String actualPatientID = Site.getInstance().getDetails(patientID, patientIdXpath);

			String patientSex = row.get("sex");
			String actualPatientSex = Site.getInstance().getDetails(patientSex,	patientSexXpath);

			String patientDOB = row.get("dob");
			String actualPatientDOB = Site.getInstance().getDetails(patientDOB,	patientDOBXpath);

			String patientAge = row.get("age");
			String actualPatientAge = Site.getInstance().getDetails(patientAge, patientAgeXpath);

			String procedure = row.get("procedure");
			String actualProcedure = Site.getInstance().getDetails(procedure, patientProcedureXpath);

			String admissionReason = row.get("admissionReason");
			String actualAdmissionReason = Site.getInstance().getDetails(admissionReason, patientAdmissionReasonXpath);
			
			String acuityInformation = row.get("acuityInformation");
			String actualAcuityInformation = Site.getInstance().getDetails(	acuityInformation, patientAcuityInformationXpath);

			String patientSurgeon = row.get("surgeon");
			String actualpatientSurgeon = Site.getInstance().getDetails(patientSurgeon, patientSurgeonXpath);

			String patientIntensivists = row.get("intensivists");
			String actualPatientIntensivists = Site.getInstance().getDetails(patientIntensivists, patientIntensivistsXpath);

			String patientNurse = row.get("nurse");
			String actualPatientNurse = Site.getInstance().getDetails(patientNurse, patientNurseXpath);	
			

			Assert.assertTrue("Verification Failed: expected ='" + patientName+ "' and actual ='" + actualPatientName + "' are not same",patientName.equalsIgnoreCase(actualPatientName));
			Assert.assertTrue("Verification Failed: expected ='" + patientID+ "' and actual ='" + actualPatientID + "' are not same",patientID.equalsIgnoreCase(actualPatientID));
			Assert.assertTrue("Verification Failed: expected ='" + patientSex+ "' and actual ='" + actualPatientSex + "' are not same",	patientSex.equalsIgnoreCase(actualPatientSex));
			Assert.assertTrue("Verification Failed: expected ='" + patientDOB+ "' and actual ='" + actualPatientDOB + "' are not same",	patientDOB.equalsIgnoreCase(actualPatientDOB));
			Assert.assertTrue("Verification Failed: expected ='" + patientAge+ "' and actual ='" + actualPatientAge + "' are not same",	patientAge.equalsIgnoreCase(actualPatientAge));
			Assert.assertTrue("Verification Failed: expected ='" + procedure+ "' and actual ='" + actualProcedure + "' are not same",procedure.equalsIgnoreCase(actualProcedure));
			Assert.assertTrue("Verification Failed: expected ='"+ admissionReason + "' and actual ='"+ actualAdmissionReason + "' are not same",admissionReason.equalsIgnoreCase(actualAdmissionReason));
			Assert.assertTrue("Verification Failed: expected ='"+ acuityInformation + "' and actual ='"	+ actualAcuityInformation + "' are not same",acuityInformation.equalsIgnoreCase(actualAcuityInformation));
			Assert.assertTrue("Verification Failed: expected ='"+ patientSurgeon + "' and actual ='" + actualpatientSurgeon	+ "' are not same",	patientSurgeon.equalsIgnoreCase(actualpatientSurgeon));
			Assert.assertTrue("Verification Failed: expected ='"+ patientIntensivists + "' and actual ='"+ actualPatientIntensivists + "' are not same",patientIntensivists.equalsIgnoreCase(actualPatientIntensivists));
			Assert.assertTrue("Verification Failed: expected ='"+ patientNurse + "' and actual ='"+ actualPatientNurse + "' are not same",patientNurse.equalsIgnoreCase(actualPatientNurse));
			Assert.assertTrue("Verification Failed: expected ='"+ patientNurse + "' and actual ='"+ actualPatientNurse + "' are not same",patientNurse.equalsIgnoreCase(actualPatientNurse));

		}

	}

	@Then("the grid panel should display the no. of occupied beds and free spaces")
	public void verifyFreeCellsAvailable(
			@Named("OccupiedBedNos") String occupiedBedNos,
			@Named("UnoccupiedFreeCells") String unoccupiedFreeCells,@Named("departmentType") String departmentType)
			throws Exception, IOException, InterruptedException, Exception

	{
		if(departmentType.equals("ICU")){
			int noOfOccupiedBedsICU = GridPanel.getInstance().getOccupiedBedNos("OccupiedBedNosICU");
			int noOfOccupiedBedWithPatientsICU = GridPanel.getInstance().getOccupiedBedNosWithPatient("OccupiedBedNosWithPatientsICU");
			int actualoccupiedBedNosICU = (noOfOccupiedBedsICU + noOfOccupiedBedWithPatientsICU);
			int noOfUnoccupiedCells = GridPanel.getInstance()
					.getUnoccupiedCellNos("UnoccupiedFreeCellsICU");

		Assert.assertEquals("Verification failed:No of expected bed nos: '"+ occupiedBedNos+ "' configured is not equal to actual bed nos '"	+ actualoccupiedBedNosICU, Integer.parseInt(occupiedBedNos),actualoccupiedBedNosICU);
		Assert.assertEquals("Verification failed:No of expected bed UnOccupiedCell Nos '"+ unoccupiedFreeCells+ "' configured is not equal to actual nos '"	+ noOfUnoccupiedCells, Integer.parseInt(unoccupiedFreeCells),noOfUnoccupiedCells);

		}
		else if(departmentType.equals("PACU")){
			int noOfOccupiedBedsPACU = GridPanel.getInstance().getOccupiedBedNos("OccupiedBedNosPACU");
			int noOfOccupiedBedWithPatientsPACU = GridPanel.getInstance().getOccupiedBedNosWithPatient("OccupiedBedNosWithPatientsPACU");
			int actualoccupiedBedNosPACU = (noOfOccupiedBedsPACU + noOfOccupiedBedWithPatientsPACU);
			int noOfUnoccupiedCellsPACU = GridPanel.getInstance()
					.getUnoccupiedCellNos("UnoccupiedFreeCellsPACU");
			
			Assert.assertEquals("Verification failed:No of expected bed nos: '"+ occupiedBedNos+ "' configured is not equal to actual bed nos '"	+ actualoccupiedBedNosPACU, Integer.parseInt(occupiedBedNos),actualoccupiedBedNosPACU);
			Assert.assertEquals("Verification failed:No of expected bed UnOccupiedCell Nos '"+ unoccupiedFreeCells+ "' configured is not equal to actual nos '"	+ noOfUnoccupiedCellsPACU, Integer.parseInt(unoccupiedFreeCells),noOfUnoccupiedCellsPACU);
		}
	}
	
	@Then("the grid panel should display similar patient icon for multiple patients share the same name")
	public void verifyDuplicateIcon(@Named("patientName") String patientName) throws WebDriverException, IOException, InterruptedException, Exception
	{
		Assert.assertTrue("Duplicate patient image icon is not displayed", GridPanel.getInstance().isDuplicateIconPresent(patientName));
	}
	
	@Then("the grid panel should display the beds grouped under a defined room")
    public void VerifyBedPosition(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("bedname") String Bedname)
                    throws IOException
    {
		Card Bed = new Card(RowNumber, ColumnNumber);
        String actBedname = Bed.getBedName();
        Assert.assertTrue("Verify bed name on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + Bedname + "; actual=" + actBedname, actBedname.equalsIgnoreCase(Bedname));
    }
	
	@Then("the color indicator displayed for logged in staff user on present list")
    public void verifyColorIndicatorForPresentStaffDetails(@Named("RowNumber") int RowNumber, @Named("ColumnNumber") int ColumnNumber,
            @Named("Staff_Role") String Staff_Role,@Named("StaffIndicatorColorFormat") String StaffIndicatorColorFormat)
                    throws IOException
    {
		Card Bed = new Card(RowNumber, ColumnNumber);
        String actStaffColor = Bed.getStaffColor();        
        Assert.assertTrue("Verify staff color indicator on card at row=" + RowNumber + " and column=" + ColumnNumber + " expected="
                + StaffIndicatorColorFormat + "; actual=" + actStaffColor, actStaffColor.equalsIgnoreCase(StaffIndicatorColorFormat));
    }
    

}
