/*
 * Copyright (c) 2014 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * Author           Date                Comments
 * Prithy       30 May 2014         Contains all the Constants
 * Pandharinath       17-Mar-2015   waitTextToBePresentInElement and captureScreenShot function aded
 */

package com.ge.hac.pl.bdd.utility;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumUtility
{
    private static Logger          logger   = Logger.getLogger(SeleniumUtility.class);
    private WebDriver              driver   = null;
    private static SeleniumUtility instance = null;

    private SeleniumUtility() throws UnreachableBrowserException, WebDriverException
    {
        try
        {
            this.driver = CommonUtility.getDriver(PropertyFileHelper.getProjectProperty("BrowserType"));
            if ( this.driver != null )
            {
                this.driver.manage().window().maximize();
            }
        }
        catch (Exception e)
        {
            logger.error("Error initializing driver for SeleniumUtility: ", e);
        }
    }

    public static SeleniumUtility getInstance()
            throws org.openqa.selenium.remote.UnreachableBrowserException, org.openqa.selenium.WebDriverException

    {
        if ( instance == null )
        {

            instance = new SeleniumUtility();
        }
        return instance;
    }

    public static void closeInstance()
            throws Exception
    {
        instance = null;

        isProcessRunningThenkill(Constants.CHROME_DRIVER_PROCESS_NAME);
        isProcessRunningThenkill(Constants.IE_DRIVER_PROCESS_NAME);

    }

    public void deleteBrowserAllCookies()
            throws Exception
    {
        driver.manage().deleteAllCookies();

    }

    /**
     * Set Content For any editable fields
     * 
     * @param objectID
     * @param text
     * @throws IOException
     */

    public void sendKeysByID(String objectID, String text)
            throws IOException
    {
        waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        driver.findElement(By.id(ID)).clear();
        driver.findElement(By.id(ID)).sendKeys(text);

    }

    public void sendKeys(String objectID, String text)
            throws IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        this.findElementbyXpath(ID).clear();
        this.findElementbyXpath(ID).sendKeys(text);
        waitForPageToLoad();
    }

    public void sendKeysWithWait(String xpathKey, String text)
            throws IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(xpathKey);

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ID)));
        this.findElementbyXpath(ID).clear();
        this.findElementbyXpath(ID).sendKeys(text);
        waitForPageToLoad();
    }

    public WebElement findElementbyXpath(String xpath)
    {
        waitForPageToLoad();
        WebElement element = null;
        try
        {
            element = driver.findElement(By.xpath(xpath));
        }
        catch (StaleElementReferenceException e)
        {
            logger.error("StaleException occured in findElement() - xpath: " + xpath, e);
            findElementbyXpath(xpath);
        }
        return element;
    }

    /**
     * Get element by XPath
     * 
     * @param XPath
     * @throws IOException
     */
    public WebElement getElementByXPath(String xpath)
            throws IOException
    {
        waitForPageToLoad();
        String xPath = PropertyFileHelper.getObjectIdentifier(xpath);
        return driver.findElement(By.xpath(xPath));
    }
    /* To Look if xpath is available in the page or not */

    public boolean iSelementPresentXpath(String xpath)
            throws IOException, InterruptedException
    {
        boolean bFound = false;
        waitForPageToLoad();
        String xPath = PropertyFileHelper.getObjectIdentifier(xpath);
        try
        {
            bFound = driver.findElement(By.xpath(xPath)).isDisplayed();
        }
        catch (Exception e)
        {
            logger.error("Error pop up xpath is not available", e);
        }
        return bFound;
    }

    public List<WebElement> getElementsByXPath(String xpath)
            throws IOException
    {
        waitForPageToLoad();
        String xPath = PropertyFileHelper.getObjectIdentifier(xpath);
        return driver.findElements(By.xpath(xPath));
    }

    /**
     * Click action on any GUI Element
     * 
     * @param objectID
     * @throws IOException
     */

    public void elementClick(String objectID)
            throws IOException
    {
        waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        WebElement ele = this.findElementbyXpath(ID);
        Actions action = new Actions(this.driver);
        action.moveToElement(ele).click().perform();
        waitForPageToLoad();
    }

    /**
     * Get element
     * 
     * @param objectID
     * @throws IOException
     */

    public WebElement getElement(String objectID)
            throws IOException
    {
        waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        return driver.findElement(By.id(ID));
    }

    /**
     * Click action on any GUI Element using RegularExpression
     * 
     * @param objectID
     * @param path
     * @throws IOException
     */

    public void elementClickUsingPath(String objectID, String path)
            throws IOException
    {
        String regularExpression = PropertyFileHelper.getObjectIdentifier(objectID);
        regularExpression = regularExpression + path;
        driver.findElement(By.id(regularExpression)).click();
        waitForPageToLoad();
    }

    /**
     * Click action on any GUI Element using RegularExpression dyncamically
     * 
     * @param objectID
     * @param path
     * @throws IOException
     */

    public void elementClickUsingDynamicPath(String objectID1, String objectID2, String path)
            throws IOException
    {
        waitForPageToLoad();
        String regularExpression1 = PropertyFileHelper.getObjectIdentifier(objectID1);
        regularExpression1 = regularExpression1 + path;
        String regularExpression2 = PropertyFileHelper.getObjectIdentifier(objectID2);
        String regularExpression3 = regularExpression1 + regularExpression2;
        WebElement element = driver.findElement(By.id(regularExpression3));
        element.findElement(By.className("x10r")).click();
        waitForPageToLoad();
    }

    /**
     * GetTextUsingDynamicPath
     * 
     * @param objectID
     * @param path
     * @throws IOException
     */

    public String GetTextUsingDynamicPath(String objectID1, String objectID2, String path)
            throws IOException
    {
        String regularExpression1 = PropertyFileHelper.getObjectIdentifier(objectID1);
        regularExpression1 = regularExpression1 + path;
        String regularExpression2 = PropertyFileHelper.getObjectIdentifier(objectID2);
        String regularExpression3 = regularExpression1 + regularExpression2;
        String text = driver.findElement(By.id(regularExpression3)).getText();
        return text;

    }

    /**
     * GetAttributeUsingDynamicPath
     * 
     * @param objectID
     * @param path
     * @throws IOException
     */

    public String GetAttributeUsingDynamicPath(String objectID1, String objectID2, String path, String attribute)
            throws IOException
    {
        String regularExpression1 = PropertyFileHelper.getObjectIdentifier(objectID1);
        regularExpression1 = regularExpression1 + path;
        String regularExpression2 = PropertyFileHelper.getObjectIdentifier(objectID2);
        String regularExpression3 = regularExpression1 + regularExpression2;
        WebElement element1 = driver.findElement(By.id(regularExpression3));
        WebElement element2 = element1.findElement(By.className("x10q"));
        WebElement element3 = element2.findElement(By.tagName("img"));
        String value = element3.getAttribute(attribute);
        return value;

    }

    /**
     * Click action using XPath
     * 
     * @param xpath
     * @throws IOException
     */

    public void elementClickUsingXPath(String xpath)
            throws IOException
    {
        WebElement object = driver.findElement(By.xpath(xpath));
        object.click();
        waitForPageToLoad();
    }

    /**
     * Selecting the Element in the Combo box
     * 
     * @param objectID
     * @param elementTobeSelected
     * @throws IOException
     */

    public void listSelect(String objectID, String elementTobeSelected)
            throws IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        WebElement mye = driver.findElement(By.id(ID));
        List<WebElement> myl = mye.findElements(By.tagName("options"));
        System.out.println("Number of elements in the list is " + myl.size());
        for (int i = 0; i < myl.size(); i++)
        {
            myl.get(i).getText();
            if ( myl.get(i).equals(elementTobeSelected) )
            {
                myl.get(i).click();
            }
            else
            {
                System.out.println("Specified text not present in the list");
            }
        }
    }

    /**
     * Navigate to URL
     * 
     * @param propertyName
     * @throws IOException
     */

    public void navigateTo(String propertyName)
            throws IOException
    {
        String URL = PropertyFileHelper.getProjectProperty(propertyName);
        driver.get(URL);
        waitForPageToLoad();
    }

    /**
     * Getting text from any field
     * 
     * @param objectName
     * @return
     * @throws IOException
     */

    public String get_text(String objectName)
            throws IOException
    {
        waitForPageToLoad();
        String xpathExpression = PropertyFileHelper.getObjectIdentifier(objectName);
        return (driver.findElement(By.xpath(xpathExpression)).getText());

    }

    /**
     * Wait for title to appear in GUI
     * 
     * @param expectedTitle
     * @param timeOut
     * @return
     */

    public boolean waitForTitle(String expectedTitle, int timeOut)
    {
        return new WebDriverWait(driver, timeOut).until(ExpectedConditions.titleIs(expectedTitle));
    }

    /**
     * Get the attribute of any GUI object
     * 
     * @param objectID
     * @param attributeName
     * @return
     * @throws IOException
     */

    public String get_attribute(String objectID, String attributeName)
            throws IOException
    {
        waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        return (driver.findElement(By.id(ID)).getAttribute(attributeName));
    }

    /**
     * Wait for Element to be appeared
     * 
     * @param objectID
     * @param timeOut
     * @throws IOException
     */

    public void waitForElementTo(String objectID, int timeOut)
            throws IOException
    {
        waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        new WebDriverWait(driver, timeOut).until(ExpectedConditions.presenceOfElementLocated(By.id(ID)));

    }

    /**
     * Wait for alert message to appear
     * 
     * @param timeOut
     */

    public void waitForAlertIsDisplayed(int timeOut)
    {
        try
        {
            (new WebDriverWait(driver, timeOut)).until(ExpectedConditions.alertIsPresent());
        }
        catch (Exception e)
        {
            logger.error("Exception occured while displaying alert dialog box ", e);
        }
    }

    /**
     * Method move the scroll bar to specified location
     * 
     * @param objectName
     * @param x
     *            (x axis)
     * @param y
     *            (y-axis)
     * @throws IOException
     */
    public void moveScrollBar(String objectName, int x, int y)
            throws IOException
    {
        // Identify WebElement
        String ID = PropertyFileHelper.getObjectIdentifier(objectName);
        WebElement slider = driver.findElement(By.id(ID));

        // Using Action Class
        Actions move = new Actions(driver);
        Action action = move.dragAndDropBy(slider, x, y).build();
        action.perform();

    }

    /**
     * Check Element Presence
     * 
     * @param objectName
     * @return
     * @throws IOException
     */

    public boolean elementPresent(String objectName)
            throws IOException
    {
        try
        {

            String ID = PropertyFileHelper.getObjectIdentifier(objectName);
            return driver.findElement(By.id(ID)).isDisplayed();
        }
        catch (NoSuchElementException e)
        {
            logger.error("NoSuchElementException in com.ge.hac.pl.bdd.utility.SeleniumUtility.elementPresent()", e);
            return false;
        }
    }

    /**
     * Typing from Keyboard
     * 
     * @param objectName
     * @param key
     * @throws IOException
     */
    public void sendKeysFromKeyboard(String objectName, Keys key)
            throws IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectName);
        driver.findElement(By.id(ID)).sendKeys(key);

    }

    /**
     * Checking Element Presence Dynamically
     * 
     * @param objectName
     * @param path
     * @return
     * @throws IOException
     */
    public boolean elementPresentUsingPath(String objectName, String path)
            throws IOException
    {
        try
        {
            waitForPageToLoad();
            String ID = PropertyFileHelper.getObjectIdentifier(objectName);
            ID = ID + path;
            return driver.findElement(By.id(ID)).isDisplayed();
        }
        catch (NoSuchElementException e)
        {
            logger.error("NoSuchElementException in com.ge.hac.pl.bdd.utility.SeleniumUtility.elementPresent()", e);
            return false;
        }
    }

    /**
     * Checking Element Presence Dynamically
     * 
     * @param objectName
     * @param path
     * @return
     * @throws IOException
     */
    public boolean elementPresentUsingDynamically(String objectID1, String ObjectID2, String path)
            throws IOException
    {
        try
        {
            waitForPageToLoad();
            String ID = PropertyFileHelper.getObjectIdentifier(objectID1);
            ID = ID + path;
            ID = ID + PropertyFileHelper.getObjectIdentifier(ObjectID2);
            return driver.findElement(By.id(ID)).isDisplayed();
        }
        catch (NoSuchElementException e)
        {
            logger.error("NoSuchElementException in com.ge.hac.pl.bdd.utility.SeleniumUtility.elementPresent()", e);
            return false;
        }
    }

    /**
     * Wait for Element to be Clickable
     * 
     * @param objectID
     * @param timeOut
     * @throws IOException
     */
    public void waitForElementToBeClicked(String objectID, int timeOut)
            throws IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectID);
        new WebDriverWait(driver, timeOut).until(ExpectedConditions.elementToBeClickable(By.id(ID)));
    }

    /**
     * Wait ffor text to appear on screen
     * 
     * @param objectName
     * @param waitTime
     * @param message
     * @throws InterruptedException
     * @throws IOException
     */
    public void waitForTextToBeAppeared(String objectName, int waitTime, String message)
            throws InterruptedException, IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectName);
        String text = driver.findElement(By.id(ID)).getText();
        for (int i = 0; i < waitTime; i++)
        {
            if ( text.contains(message) )
            {
                break;
            }
            else
            {
                Thread.sleep(1000);
            }

        }
    }

    /**
     * Utility for Element to to Disappear after it is closed
     * 
     * @param objectName
     * @param waitTime
     * @throws IOException
     * @throws InterruptedException
     */
    public void waitForElementToDisAppear(String objectName, int waitTime)
            throws IOException, InterruptedException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectName);
        for (int i = 0; i < waitTime; i++)
        {
            try
            {
                if ( !elementPresent(ID) )
                {
                    break;
                }
                else
                {
                    Thread.sleep(1000);
                }

            }
            catch (Exception e)
            {
                logger.error("Exception in SeleniumUtility.waitForElementToDisAppear() - sleeping.", e);
                Thread.sleep(1000);
            }
        }
    }

    /**
     * Utility to Quit the Browser
     */
    public void closeBrowser()
    {
        if ( !(driver == null) )
        {
            waitForPageToLoad();
            driver.quit();
            driver = null;
        }
    }

    /**
     * Wait for the Element to be appeared
     * 
     * @param waitTime
     * @param id
     * @throws InterruptedException
     */

    public void waitForObjectToAppear(int waitTime, String objectName)
            throws InterruptedException, IOException
    {
        String ID = PropertyFileHelper.getObjectIdentifier(objectName);
        for (int i = 0; i < waitTime; i++)
        {
            try
            {
                WebElement element = driver.findElement(By.id(ID));
                if ( null != element )
                {
                    break;
                }
                else
                {
                    Thread.sleep(1000);
                }
            }
            catch (Exception e)
            {
                logger.error("Exception in SeleniumUtility.waitForObjectToAppear - sleeping.", e);
                Thread.sleep(1000);
            }
        }
    }

    /**
     * Wait for the Element to be appeared
     * 
     * @param waitTime
     * @param id
     * @throws InterruptedException
     */

    public void waitForObjectToAppearDynamically(int waitTime, String objectName, String path)
            throws InterruptedException, IOException
    {
        for (int i = 0; i < waitTime; i++)
        {
            try
            {
                String ID = PropertyFileHelper.getObjectIdentifier(objectName);
                ID = ID + path;
                WebElement element = driver.findElement(By.id(ID));
                if ( null != element )
                {
                    break;
                }
                else
                {
                    Thread.sleep(1000);
                }
            }
            catch (Exception e)
            {
                logger.error("Exception in SeleniumUtility.waitForObjectToAppearDynamically - sleeping.", e);
                Thread.sleep(1000);
            }
        }
    }

    public WebElement getElementUsingIterator(String objectName1, String objectName2, String iterator)
            throws IOException
    {
        String ID1 = PropertyFileHelper.getObjectIdentifier(objectName1);
        String ID2 = PropertyFileHelper.getObjectIdentifier(objectName2);
        String ID = ID1 + iterator + ID2;
        return driver.findElement(By.id(ID));
    }

    /**
     * GetTextUsingDynamicPath
     * 
     * @param objectID
     * @param path
     * @throws IOException
     */

    public void waitForElementUsingDynamicPath(String objectID1, String objectID2, String path)
            throws IOException
    {
        String regularExpression1 = PropertyFileHelper.getObjectIdentifier(objectID1);
        regularExpression1 = regularExpression1 + path;
        String regularExpression2 = PropertyFileHelper.getObjectIdentifier(objectID2);
        String regularExpression3 = regularExpression1 + regularExpression2;
        new WebDriverWait(driver, 10).until(ExpectedConditions.presenceOfElementLocated(By.id(regularExpression3)));

    }

    public List<WebElement> findElements(String objectID1)
            throws IOException, InterruptedException
    {
        waitForPageToLoad();
        String regularExpression1 = PropertyFileHelper.getObjectIdentifier(objectID1);
        List<WebElement> temp = driver.findElements(By.xpath(regularExpression1));

        return temp;
    }

    public boolean waitTextToBePresentInElement(String xpath, String textTobePresent, int timeout)
            throws IOException
    {
        String xPath = PropertyFileHelper.getObjectIdentifier(xpath);
        new WebDriverWait(driver, Constants.HIGH_TIMEOUT)
                .until(ExpectedConditions.presenceOfElementLocated(By.xpath(xPath)));
        Boolean bFound = new WebDriverWait(driver, timeout)
                .until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(xPath), textTobePresent));

        return bFound;
    }

    public String getTextOfElementWithWait(String xpathKey, String expectedMessage)
    {
        // waitForPageToLoad();
        String ID = PropertyFileHelper.getObjectIdentifier(xpathKey);

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ID)));
        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(xpathKey), expectedMessage));
        return this.findElementbyXpath(ID).getText().trim();
    }

    public String captureScreenShot(String userDir, String fileName)
            throws IOException
    {
        File files = new File(userDir);
        if ( !files.exists() )
        {
            files.mkdirs();
        }
        String filePath = userDir + "\\" + fileName + ".jpg";
        TakeScreenshot(filePath);
        return filePath;
    }

    public String getAlertText()
    {
        return driver.switchTo().alert().getText();

    }

    public void performActionOnAlert(String actionToPerform)
    {
        Alert alert = driver.switchTo().alert();
        switch (actionToPerform.toLowerCase())
        {
            case "ok":
                // Will Click on OK button.
                alert.accept();
                break;
            case "cancel":
                // Will click on Cancel button.
                alert.dismiss();

        }

    }

    public List<WebElement> findElementsUsingDynamicPath(String Xpath, String XpathToAppend)
            throws IOException
    {
        String baseXpath = PropertyFileHelper.getObjectIdentifier(Xpath);
        String newXpath = baseXpath + XpathToAppend;
        return driver.findElements(By.xpath(newXpath));
    }

    public String getBrowserTitle()
    {
        return this.driver.getTitle();
    }

    public void openUrl(String url)
    {
        this.driver.get(url);
    }

    public Object executeJavaScript(String command)
    {
        waitForPageToLoad();
        if ( this.driver instanceof JavascriptExecutor )
        {
            return ((JavascriptExecutor) this.driver).executeScript(command);
        }
        return null;
    }

    public void browserRefresh()
    {
        driver.navigate().refresh();

    }

    // this function should return true/fasle if element is not displayed or not loaded
    public boolean elementDisplayedByXpath(String eleXpath)
            throws IOException
    {
        try
        {
            String xpath = PropertyFileHelper.getObjectIdentifier(eleXpath);
            return driver.findElement(By.xpath(xpath)).isDisplayed();
        }
        catch (NoSuchElementException e)

        {
            return false;

        }
    }

    public void waitForPageToLoad()
    {
        String browserType = PropertyFileHelper.getProjectProperty("BrowserType");
        if ( browserType.equalsIgnoreCase("chrome") )
        {
            WebDriver driver = this.driver;
            ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>()
            {
                public Boolean apply(WebDriver driver)
                {
                    return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
                }
            };
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(pageLoadCondition);
        }
    }

    private static boolean isProcessRunningThenkill(String serviceName)
            throws Exception
    {

        Process p = Runtime.getRuntime().exec(Constants.TASKLIST);
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null)
        {
            if ( line.contains(serviceName) )
            {
                killProcess(serviceName);
            }
        }

        return false;

    }

    private static void killProcess(String serviceName)
            throws Exception
    {

        Runtime.getRuntime().exec(Constants.KILL + serviceName);

    }

    public void TakeScreenshot(String filePath)
    {

        try
        {
            String browserTyep = PropertyFileHelper.getProjectProperty("BrowserType");
            if ( browserTyep.equalsIgnoreCase("chrome") )
            {
                if ( driver != null )
                {
                    File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

                    FileUtils.copyFile(scrFile, new File(filePath));
                }

            }
            else
            {

                BufferedImage image = new Robot()
                        .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

                ImageIO.write(image, "png", new File(filePath));
            }

        }
        catch (Exception e)
        {
            logger.error("Exception in SeleniumUtility.TakeScreenshot()", e);
        }

    }

    /**
     * @param xPath
     * @return webelements
     */
    public List<WebElement> findElementsByXpath(String xPath)
    {
        return driver.findElements(By.xpath(xPath));
    }

    /**
     * @param xPathforCssSelector
     * @return webelements
     */
    public List<WebElement> findElementsByCSSSelector(String xPathforCssSelector)
    {
        String xPathForCSS = PropertyFileHelper.getObjectIdentifier(xPathforCssSelector);
        return driver.findElements(By.cssSelector(xPathForCSS));
    }

    // this function will resize application window by 50% of existing size and then maximize it again
    public void resizeWindow()
    {
        Dimension windowDim = driver.manage().window().getSize();
        Dimension targetSize = new Dimension(windowDim.getHeight() / 2, windowDim.getWidth() / 2);
        driver.manage().window().setSize(targetSize);
        driver.manage().window().maximize();

    }
}
