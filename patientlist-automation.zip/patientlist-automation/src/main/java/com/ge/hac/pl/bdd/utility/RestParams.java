/*
 * Copyright (c) 2016 GE Healthcare. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Healthcare. The software may be used and/or copied only
 * with the written permission of GE Healthcare or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.hac.pl.bdd.utility;

/**
 * @author 305014106
 *
 */
public class RestParams
{
    String requestType;
    String queryParams;
    String postEntity;
    String restEndpoint;

    
    /**
     * 
     */
    public RestParams()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param requestType
     * @param queryParams
     * @param postEntity
     * @param restEndpoint
     */
    public RestParams(String requestType, String queryParams, String postEntity, String restEndpoint)
    {
        super();
        this.requestType = requestType;
        this.queryParams = queryParams;
        this.postEntity = postEntity;
        this.restEndpoint = restEndpoint;
    }

    /**
     * @return the requestType
     */
    public String getRequestType()
    {
        return this.requestType;
    }

    /**
     * @param requestType the requestType to set
     */
    public void setRequestType(String requestType)
    {
        this.requestType = requestType;
    }

    /**
     * @return the queryParams
     */
    public String getQueryParams()
    {
        return this.queryParams;
    }

    /**
     * @param queryParams the queryParams to set
     */
    public void setQueryParams(String queryParams)
    {
        this.queryParams = queryParams;
    }

    /**
     * @return the postEntity
     */
    public String getPostEntity()
    {
        return this.postEntity;
    }

    /**
     * @param postEntity the postEntity to set
     */
    public void setPostEntity(String postEntity)
    {
        this.postEntity = postEntity;
    }

    /**
     * @return the restEndpoint
     */
    public String getRestEndpoint()
    {
        return this.restEndpoint;
    }

    /**
     * @param restEndpoint the restEndpoint to set
     */
    public void setRestEndpoint(String restEndpoint)
    {
        this.restEndpoint = restEndpoint;
    }

}
